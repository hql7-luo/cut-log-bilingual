# Muse sleep sync

The private deployment imports nightly Apple Health summaries and Muse reports. The public demo uses synthetic data and works without an account. Sleep never changes the food budget or the training log.

## Connect a private account

1. In the existing Supabase project, apply `supabase/sleep.sql` after `schema.sql` and `agent.sql`.
2. Deploy the app with its current account settings and `FITNESS_AGENT_ENABLED=1`.
3. In the signed-in app, open Settings and create a Muse sleep sync key. Paste it into Muse’s secure credential prompt. Treat the key like a password. It expires after 180 days and can be revoked in Settings.
4. Add a separate Muse connector using `public/sleep-sync.openapi.json`. Set the server to the private site origin. Keep the existing food connector and weekly Muse chat report in place.

## Send sleep and reports

POST JSON to `/api/v1/sleep-sync` with the sleep Bearer key. Begin with an empty batch to verify credentials. Read up to the last 30 wake dates for the first import. For a daily run, recheck three wake dates with a single batch. Widen the batch if the cadence falls to every two or three days or weekly.

Send one main sleep window per wake date in Pacific Time. Put sleep duration excluding awakenings in `asleep_minutes`. Keep an unknown stage blank and omit a night with no sample. Resting heart rate is in bpm. HRV is in milliseconds. Only include these values if Apple Health provides a reliable sample for that date.

Set `observed_at` once per snapshot, using the date and time the data was read. Reuse it on a network retry. A newer read can update the same wake date. A repeated or older read leaves the current version in place. A missing night does not delete a recorded night.

A daily report uses the sleep wake date. A weekly report uses the date it was written. When the existing Muse chat report can be accessed from the sync task, send its summary and suggestion. Otherwise send a separately generated summary of the same date range. Give the actual number of covered nights and a 30-day trend only when the data supports it. Keep suggestions practical and use sleep stage estimates for tracking. No other logs are sent to Muse by the sleep integration.
