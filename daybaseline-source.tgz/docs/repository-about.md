# GitHub repository description

DayBaseline is a bilingual, mobile-first sleep, food, workout, and weight tracker with a synthetic public demo.
