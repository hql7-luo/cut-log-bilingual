# 日衡 · DayBaseline

DayBaseline is a mobile-first sleep, food, workout, and weight tracker in English and Simplified Chinese. Type a meal in your own words, review the portions, and see your nutrition and training alongside your weight trend.

## Try it

Install Node.js 22 or newer and run the commands below.

```sh
npm install
npm run dev
```

Open [English](http://localhost:3000/?lang=en) or [简体中文](http://localhost:3000/?lang=zh). On mobile, the language switch is at the top. On desktop, it is in the sidebar. Your choice stays on the device, and the two interfaces share the same records.

Try **Log Food** with “For lunch I had 200 g of rice and two eggs.” Choose **Parse and preview**, check the amounts, and save the meal. To start with an empty journal, open **Settings → Clear demo data and start logging**. Use **Settings → Profile** and **Nutrition and Weight Goals** to enter your own information and targets.

For a standalone browser demo, run `npm run build:demo` and open `demo.html`. Local logging works without a cloud account.

## What you can track

- **Sleep.** Review the night, sleep stage estimates, and 7- or 30-day trends. The public demo uses synthetic data. A private account can connect Muse.

- **Meals.** Parse English or Chinese text, adjust portions, search the built-in food list, or enter a package label. Save frequent foods for reuse. Dictation is available when the browser supports it.
- **Workouts.** Log a quick session or add sets with individual weights and reps. Favorite exercises, copy previous sets, see both lb and kg, and review personal records by equipment setup. Performance, volume, and frequency views support 30 days, 90 days, and all time.
- **Daily energy.** Check logged intake at any time. When you finish logging a day, mark it complete to save its nutrition goal and compare intake with estimated expenditure. The burn breakdown shows how recorded activity and planned durations affect the estimate.
- **Health and progress.** Review weight, sleep, meals, and training over 1, 7, or 30 days, with the dates and record coverage for each observation. Settings offers an optional sleep goal and CSV export.

Food portions and energy expenditure are estimates. Log dates currently use Pacific Time. The initial nutrition and training targets are examples.

## Optional cloud setup

Set `NEXT_PUBLIC_DAYBASELINE_DEMO=1` when deploying a public demo to disable all cloud APIs and use the sample records.

To host DayBaseline, deploy the source as a Next.js project. Set environment variables from [.env.example](.env.example) in your host's settings, or copy the file to `.env.local` for local development.

| Feature | Setup |
| --- | --- |
| Muse sleep sync | Follow the [sleep sync guide](docs/sleep-sync.md) to install the migration and issue a sleep-only key. |
| Email accounts and device sync | Run [supabase/schema.sql](supabase/schema.sql) in your Supabase project. Set `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`. Set the app URL and allowed redirects in Supabase Authentication. |
| Online USDA FoodData Central search | Configure sync and set `USDA_API_KEY` on the server. |
| Online text parsing | Configure sync and set `AI_API_KEY`, `AI_MODEL`, and optionally `AI_BASE_URL` for a compatible HTTPS provider. |
| Meal photo analysis | Configure sync and set `AI_API_KEY` and `AI_VISION_MODEL`. The configured vision provider receives the photo. |
| Meal and workout API | Follow the [API and connector guide](docs/agent-api.md) to enable the service and issue a scoped credential. |

Each signed-in account has its own cloud records. Guest records stay in their browser. Images sent for analysis become editable meal drafts. Saving a meal writes the confirmed food data. Keep provider and connector keys in server or connector settings.

For an existing cloud installation, rerun `supabase/schema.sql` and `supabase/sleep.sql` before deploying this release. Existing connector credentials and automation schedules continue to work.

## Checks

```sh
npm run check
npm test
npm run build
```
