import assert from "node:assert/strict";
import test from "node:test";
import { recordsCsv } from "../src/lib/export.ts";
import { recordsOf } from "../src/lib/model.ts";
import { initialSnapshot, visibleRows } from "../src/lib/persistence.ts";
import { compareStrength, dualWeight, sameLoad, sessionVolume, setKg, strengthDirection, strengthEntries,
  toKg, topSet, workoutStrength } from "../src/lib/strength.ts";

const press = { exerciseId: "press", name: "哑铃卧推", muscle: "chest", mode: "dumbbell", variant: "平板", dumbbells: 2 };
const sets = (definition, weight, unit, reps) => ({ ...definition, sets: [{ weight, unit, reps }] });
const workout = (strengthDetails, day = "2026-11-22") => ({ kind: "workout", id: day, revision: 1, cursor: 1, payload:
  { kind: "strength", day, exercises: [], strengthDetails, minutes: 45, time: 1, note: "" } });

test("paired dumbbells use the original per-hand input and compare across units", () => {
  const before = sets(press, 60, "lb", 8);
  const after = sets(press, 27.2, "kg", 9);
  assert.equal(dualWeight(60, "lb"), "60 lb (27.2 kg)");
  assert.equal(dualWeight(30, "kg"), "30 kg (66.1 lb)");
  assert.ok(sameLoad(toKg(60, "lb"), 27.2));
  assert.equal(sessionVolume(before), toKg(60, "lb") * 16);
  assert.deepEqual(compareStrength(after, before), { direction: "up", metric: "reps", delta: 1 });
  assert.equal(compareStrength({ ...after, variant: "上斜" }, before).direction, "unknown");
  assert.equal(compareStrength({ ...after, dumbbells: 1 }, before).direction, "unknown");
  assert.equal(before.sets[0].unit, "lb");
});

test("load conventions handle bars, assistance, bodyweight and warm-ups separately", () => {
  const plates = { ...press, mode: "plates", bar: { weight: 20, unit: "kg" } };
  const loaded = sets(plates, 80, "kg", 5);
  assert.equal(setKg(plates, loaded.sets[0]), 100);
  assert.equal(sessionVolume({ ...loaded, bar: null }), null);
  const support = { ...press, mode: "assisted" };
  assert.equal(compareStrength(sets(support, 65, "lb", 6), sets(support, 75, "lb", 6)).direction, "up");
  const body = sets({ ...press, mode: "bodyweight" }, null, "kg", 10);
  assert.equal(compareStrength(body, { ...body, sets: [{ ...body.sets[0], reps: 8 }] }).direction, "up");
  assert.equal(sessionVolume(body), null);
  assert.equal(topSet({ ...loaded, sets: [...loaded.sets, { weight: 110, unit: "kg", reps: 3, warmup: true }] }).kg, 100);
});

test("repeat matches establish direction and duplicate IDs preserve variant separation", () => {
  const entries = strengthEntries([workout([sets(press, 60, "lb", 6)]),
    workout([sets(press, 27.2, "kg", 8)], "2026-11-23"),
    workout([sets(press, 60, "lb", 10)], "2026-11-24")]);
  assert.equal(strengthDirection(entries), "up");
  assert.equal(strengthDirection(entries.slice(0, 2)), "unknown");
  assert.equal(strengthEntries([workout([entries[0].move, { ...entries[0].move, variant: "上斜" }])]).length, 2);
  assert.equal(workoutStrength({ kind: "strength",
    exercises: [{ name: "历史动作", muscle: "back", weight: 0, unit: "lb", reps: 10, sets: 2 }] })[0].sets[0].weight, null);
});

test("CSV exports original weights per set, session duration once, and no demonstration history", () => {
  const day = "2026-11-22";
  const local = initialSnapshot("guest", day);
  assert.equal(recordsOf(visibleRows(local), "profile").length, 1);
  assert.equal(visibleRows(initialSnapshot("signed-in", day)).length, 0);
  assert.equal(recordsCsv(visibleRows(local)).split("\r\n").length, 1);
  const move = { ...press, sets: [{ weight: 55, unit: "lb", reps: 8 }, { weight: 24.9, unit: "kg", reps: 7, note: "=1+1" }] };
  const lines = recordsCsv([workout([move])]).split("\r\n");
  assert.equal(lines.length, 4);
  const cells = (line) => line.slice(1, -1).split('","');
  assert.deepEqual(lines.slice(1).map((line) => cells(line)[12]), ["45", "", ""]);
  assert.deepEqual(lines.slice(2).map((line) => cells(line).slice(14, 16)), [["55", "lb"], ["24.9", "kg"]]);
  assert.equal(cells(lines[3])[19], "'=1+1");
});
