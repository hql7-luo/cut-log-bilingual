import test from "node:test";
import assert from "node:assert/strict";
import { DEFAULT_PROFILE } from "../src/lib/model.ts";
import { loggedContext, sampleSleep, sleepSyncFreshness, sleepTrend } from "../src/lib/sleep.ts";

test("sleep charts preserve missing nights and compute bedtime correctly across midnight", () => {
  const nights = [
    { day: "2026-01-10", start_at: "2026-01-09T23:40:00-08:00", end_at: "2026-01-10T07:10:00-08:00", asleep_minutes: 440 },
    { day: "2026-01-12", start_at: "2026-01-12T00:10:00-08:00", end_at: "2026-01-12T07:40:00-08:00", asleep_minutes: 420 },
  ];
  const trend = sleepTrend(nights, "2026-01-12", 7);
  assert.equal(trend.count, 2);
  assert.equal(trend.average, 430);
  assert.deepEqual(trend.bedtime, { typical: "23:55", spread: 30 });
  assert.deepEqual(trend.wake, { typical: "07:25", spread: 30 });
  assert.equal(trend.slots.at(-2).night, undefined);
  assert.equal(sleepTrend(nights, "2026-01-09", 7).average, null);
});

test("demo sleep has gaps and recomputes dates without account data", () => {
  const demo = sampleSleep("2026-01-15");
  assert.equal(demo.nights.length, 27);
  assert.equal(demo.nights.at(-1).day, "2026-01-15");
  for (const night of demo.nights) {
    assert.equal(night.core_minutes + night.deep_minutes + night.rem_minutes, night.asleep_minutes);
  }
});

test("sleep freshness distinguishes imported, legacy, empty, and recently delivered older nights", () => {
  const today = "2026-01-12";
  const now = Date.parse("2026-01-12T17:00:00Z");
  const legacy = {
    latest_received_at: null, latest_observed_at: "2026-01-12T16:00:00Z",
    latest_wake_day: "2026-01-12", coverage_7: 1, coverage_30: 1,
  };
  const recent = { ...legacy, latest_received_at: "2026-01-12T16:05:00Z" };
  assert.equal(sleepSyncFreshness(legacy, today, now), "legacy");
  assert.equal(sleepSyncFreshness(recent, today, now), "recent");
  assert.equal(sleepSyncFreshness({ ...legacy, latest_wake_day: null, latest_observed_at: null }, today, now), "empty");
  assert.equal(sleepSyncFreshness({ ...recent, latest_wake_day: "2026-01-09" }, today, now), "stale");
});

test("health context excludes future dates and counts distinct manually logged training days", () => {
  const weights = [["2026-01-10", 70], ["2026-01-12", 72], ["2026-01-13", 200]];
  const workouts = ["2026-01-12", "2026-01-12", "2026-01-13"];
  const rows = [
    ...weights.map(([day, kg]) => ({ kind: "weight", payload: { day, kg } })),
    ...workouts.map((day) => ({ kind: "workout", payload: { day, kind: "basketball" } })),
  ];
  const context = loggedContext(rows, DEFAULT_PROFILE, "2026-01-12");
  assert.equal(context.averageKg, 71);
  assert.equal(context.weighedDays, 2);
  assert.equal(context.trainingDays, 1);
  assert.equal(context.trained, true);
});

test("sleep endpoint refuses missing credentials and serves private no-store responses", async (t) => {
  process.env.NEXT_PUBLIC_SUPABASE_URL = "https://supabase.test";
  process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY = "public-test-key";
  process.env.FITNESS_AGENT_ENABLED = "1";
  const { POST } = await import("../src/app/api/v1/sleep-sync/route.ts");
  const url = "https://private.test/api/v1/sleep-sync";
  const bearer = "sleep_" + "9".repeat(64);
  const payload = { observed_at: "2026-01-12T16:00:00Z", nights: [], reports: [] };
  t.mock.method(globalThis, "fetch", async (endpoint, options) => {
    assert.equal(endpoint, "https://supabase.test/rest/v1/rpc/daybaseline_sync_sleep");
    assert.deepEqual(JSON.parse(options.body), { p_token: bearer, p_payload: payload });
    assert.equal(options.cache, "no-store");
    return Response.json({ status: 200, nights_saved: 0, reports_saved: 0 });
  });
  function request(token) {
    return new Request(url, { method: "POST", body: JSON.stringify(payload), headers: token ? { Authorization: `Bearer ${token}` } : {} });
  }
  assert.equal((await POST(request())).status, 401);
  assert.equal((await POST(request("cut_" + "a".repeat(43)))).status, 401);
  const response = await POST(request(bearer));
  assert.equal(response.headers.get("cache-control"), "no-store");
  assert.deepEqual(await response.json(), { nights_saved: 0, reports_saved: 0 });
  assert.equal(fetch.mock.calls.length, 1);
});

test("account sleep status uses an authenticated read independent of the selected date window", async (t) => {
  process.env.NEXT_PUBLIC_SUPABASE_URL = "https://supabase.test";
  process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY = "public-test-key";
  const { pullSleep, pullSleepStatus } = await import("../src/lib/supabase.ts");
  const summary = {
    latest_received_at: "2026-01-12T16:05:00Z", latest_observed_at: "2026-01-12T16:00:00Z",
    latest_wake_day: "2026-01-12", coverage_7: 5, coverage_30: 20,
  };
  t.mock.method(globalThis, "fetch", async (endpoint, options) => {
    const url = new URL(endpoint);
    assert.equal(url.origin, "https://supabase.test");
    assert.equal(options.method, "GET");
    assert.equal(options.headers.Authorization, "Bearer account-token");
    if (url.pathname.endsWith("/daybaseline_sleep_status")) {
      assert.equal(url.search, "");
      return Response.json([summary]);
    }
    assert.equal(url.searchParams.get("and"), "(day.gte.2025-01-01,day.lte.2025-01-30)");
    if (url.pathname.endsWith("/daybaseline_sleep")) return new Response(null, { status: 503 });
    return Response.json([]);
  });
  const controller = new AbortController();
  assert.deepEqual(await pullSleepStatus("account-token", controller.signal), summary);
  await assert.rejects(pullSleep("account-token", "2025-01-01", "2025-01-30"), { status: 503 });
  controller.abort();
  assert.equal(fetch.mock.calls[0].arguments[1].signal.aborted, true);
});

test("sleep export pages all dates and preserves both report kinds on one date", async (t) => {
  process.env.NEXT_PUBLIC_SUPABASE_URL = "https://supabase.test";
  process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY = "public-test-key";
  const { pullSleepExport } = await import("../src/lib/supabase.ts");
  const nights = [{ day: "2025-01-01" }, { day: "2026-01-12" }];
  const reports = [{ day: "2025-01-01", kind: "daily" }, { day: "2025-01-01", kind: "weekly" }];
  t.mock.method(globalThis, "fetch", async (endpoint, options) => {
    const url = new URL(endpoint);
    const query = url.searchParams;
    assert.equal(options.headers.Authorization, "Bearer account-token");
    assert.equal(query.get("limit"), "300");
    assert.equal(query.has("and"), false);
    if (url.pathname.endsWith("/daybaseline_sleep")) {
      assert.equal(query.get("order"), "day.asc");
      const after = query.get("day");
      if (!after) return Response.json([nights[0]]);
      if (after === "gt.2025-01-01") return Response.json([nights[1]]);
      assert.equal(after, "gt.2026-01-12");
      return Response.json([]);
    }
    assert.equal(url.pathname, "/rest/v1/daybaseline_reports");
    assert.equal(query.get("order"), "day.asc,kind.asc");
    const after = query.get("or");
    if (!after) return Response.json([reports[0]]);
    if (after === "(day.gt.2025-01-01,and(day.eq.2025-01-01,kind.gt.daily))") return Response.json([reports[1]]);
    assert.equal(after, "(day.gt.2025-01-01,and(day.eq.2025-01-01,kind.gt.weekly))");
    return Response.json([]);
  });
  assert.deepEqual(await pullSleepExport("account-token"), { nights, reports });
});
