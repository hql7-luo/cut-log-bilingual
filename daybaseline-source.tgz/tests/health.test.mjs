import assert from "node:assert/strict";
import test from "node:test";
import { shiftDay } from "../src/lib/dates.ts";
import { healthSummary } from "../src/lib/health.ts";
import { DEFAULT_PROFILE, energyEstimate } from "../src/lib/model.ts";
import { nutrition } from "../src/lib/nutrition.ts";
import { parseLocal } from "../src/lib/parse-food.ts";
import { sampleSleep } from "../src/lib/sleep.ts";

const day = "2026-11-28";
const profile = { ...DEFAULT_PROFILE, age: 25 };
const summarize = (overrides) => healthSummary({ rows: [], nights: [], profile, day, today: day, window: 7, ...overrides });
const row = (kind, payload, id, cursor = 0) => ({ id, kind, payload, cursor, revision: 0 });
const marker = (date) => row("food_day", { day: date, target: nutrition(2000, 150, 210, 62) }, date);

test("health advice keeps absent observations null and separates local records from examples", () => {
  const empty = summarize({});
  assert.equal(empty.food.intake, null);
  assert.equal(empty.food.estimatedBalance, null);
  assert.equal(empty.weight.current.average, null);
  assert.equal(empty.training.workingSets, null);
  assert.equal(empty.sleep.duration.value, null);
  assert.equal(empty.positive, null);

  const examples = sampleSleep(day);
  const sampleWeight = { ...row("weight", { day, kg: 123 }, "sample"), sample: true };
  const personalWeight = row("weight", { day, kg: 76 }, "personal");
  const practice = summarize({ rows: [sampleWeight], nights: examples.nights, demoSleep: true });
  assert.equal(practice.example, true);
  assert.ok(practice.sleep.count > 0);
  const personal = summarize({ rows: [sampleWeight, personalWeight], nights: examples.nights, demoSleep: true });
  assert.equal(personal.example, false);
  assert.equal(personal.weight.current.average, 76);
  assert.equal(personal.sleep.count, 0);
});

test("diet metrics keep incomplete food intake separate from the estimated calorie balance", () => {
  const timed = shiftDay(day, -1);
  const untimed = shiftDay(day, -2);
  const unknown = shiftDay(day, -3);
  const eat = (date, grams) => row("food", { ...parseLocal(`${grams}g 米饭`)[0], day: date, meal: "lunch", time: 1 }, date);
  const rows = [eat(day, 50), eat(timed, 200), marker(timed), eat(untimed, 100), marker(untimed), marker(unknown),
    row("workout", { day: untimed, kind: "strength", exercises: [], minutes: null, note: "", time: 1 }, "untimed"),
    row("food", { ...eat(unknown, 100).payload, spec: null }, "unknown"),
  ];
  const { food } = summarize({ rows });
  assert.equal(food.recorded, 3);
  assert.equal(food.marked, 3);
  assert.equal(food.complete, 2);
  assert.equal(food.uncomputedEntries, 1);
  assert.equal(food.comparable, 1);
  assert.equal(food.intake.kcal, 195);
  assert.equal(food.target.protein, 150);
  assert.equal(food.estimatedBalance, energyEstimate({ ...profile, level: "low" }).tdee - 260);
  const open = summarize({ rows, window: 1 });
  assert.equal(open.priority, "finish-food");
  assert.equal(open.food.intake.kcal, 65);
  assert.equal(open.food.estimatedBalance, null);
});

test("working sets compare repeated actual performance on distinct dates with the same setup", () => {
  const strength = (date, id, reps, variant = "rack 1", kind = "strength") => row("workout", {
    day: date, kind, exercises: [], minutes: 40, note: "", time: 1,
    strengthDetails: [{ exerciseId: "bench", name: "Bench press", muscle: "chest", mode: "barbell", variant,
      sets: [{ weight: 70, unit: "kg", reps }, { weight: 95, unit: "kg", reps: 15, warmup: true }] }],
  }, id);
  const before = shiftDay(day, -3);
  const earlier = shiftDay(day, -8);
  const rows = [strength(day, "latest", 8), strength(before, "before", 9), strength(earlier, "earlier", 10),
    strength(day, "different-setup", 11, "rack 2"), strength(day, "basketball", 2, "rack 1", "basketball")];
  const result = summarize({ rows });
  assert.equal(result.priority, "strength-down");
  assert.equal(result.training.days, 2);
  assert.equal(result.training.sessions, 3);
  assert.equal(result.training.workingSets, 3);
  assert.equal(result.training.volume, 70 * (8 + 9 + 11));
  assert.deepEqual(result.training.patterns[0].dates, [earlier, before, day]);
  assert.equal(result.training.patterns[0].example.difference.delta, -1);
  assert.equal(summarize({ rows: rows.filter(({ id }) => id !== "earlier") }).training.patterns.length, 0);
});

function night(date, minutes, vitals = {}) {
  return { day: date, start_at: date + "T07:30:00Z", end_at: date + "T15:30:00Z", observed_at: date + "T16:00:00Z",
    asleep_minutes: minutes, core_minutes: null, deep_minutes: null, rem_minutes: null, awake_minutes: null,
    resting_hr: null, hrv_ms: null, ...vitals };
}

test("personal sleep comparisons require enough nights in each half for each metric", () => {
  const nights = Array.from({ length: 30 }, (_, index) => {
    const earlier = index < 15;
    return night(shiftDay(day, index - 29), earlier ? 480 : 418, {
      resting_hr: earlier ? 60 : 62,
      hrv_ms: index < 4 || !earlier ? 48 : null,
      rem_minutes: index > 22 ? 90 : null,
    });
  });
  const result = summarize({ nights, window: 30 });
  assert.equal(result.sleep.duration.comparison.delta, -62);
  assert.equal(result.sleep.resting.comparison.delta, 2);
  assert.equal(result.sleep.hrv.count, 19);
  assert.equal(result.sleep.hrv.comparison.delta, null);
  assert.deepEqual(result.sleep.stages.rem, { value: 90, count: 7 });
  assert.equal(result.priority, "sleep-shorter");

  const uneven = summarize({ nights: nights.filter((_, index) => index < 4 || index >= 15), window: 30 });
  assert.equal(uneven.sleep.count, 19);
  assert.equal(uneven.sleep.covered, false);
  assert.equal(uneven.sleep.duration.comparison.delta, null);
  assert.equal(uneven.priority, "record-food");
});

test("weight pace uses repeated covered weeks and ignores duplicated or future measurements", () => {
  const rows = Array.from({ length: 21 }, (_, index) => row("weight", {
    day: shiftDay(day, index - 20), kg: 80 - index * 0.07,
  }, `weight-${index}`, index + 1));
  rows.push(row("weight", { day, kg: 180 }, "old-duplicate"));
  rows.push(row("weight", { day: shiftDay(day, 1), kg: 200 }, "future", 22));
  const { weight } = summarize({ rows });
  assert.equal(weight.current.count, 7);
  assert.equal(weight.latest.kg, 78.6);
  assert.equal(weight.pattern, "at-goal");
  assert.equal(weight.patternWindows.length, 3);
  const singleComparison = summarize({ rows: rows.slice(7) });
  assert.ok(singleComparison.weight.comparison.rate !== null);
  assert.equal(singleComparison.weight.pattern, null);
});
