// Only the Supabase public project address and client key are embedded in the browser.
const localDemo = process.env.NEXT_PUBLIC_DAYBASELINE_DEMO === "1";
export const SUPABASE_URL = localDemo ? "" : (process.env.NEXT_PUBLIC_SUPABASE_URL ?? "").trim().replace(/\/$/, "");
export const SUPABASE_KEY = localDemo ? "" : (process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY ?? "").trim();
const configured = /^https:\/\/[^\s/]+$/.test(SUPABASE_URL) && SUPABASE_KEY.length > 0;
// Public builds stay offline even if a deployment inherits cloud environment variables.
export const DEMO_EDITION = !configured;
export const CLOUD_ENABLED = !DEMO_EDITION;
