import { calendarStats, type CalendarDayStats } from "./calendar.ts";
import { dayIndex, shiftDay } from "./dates.ts";
import { recordsOf, type Nutrition, type Profile, type Row } from "./model.ts";
import { scale, sum } from "./nutrition.ts";
import { sleepClock, sleepTrend, type Night } from "./sleep.ts";
import { compareStrength, definitionKey, documentedStrength, sessionVolume, strengthDirection, workingSets,
  type StrengthEntry } from "./strength.ts";
import { trend as weightTrend, type WeighIn } from "./trends.ts";

export const HEALTH_WINDOWS = [1, 7, 30] as const;
export type HealthWindow = typeof HEALTH_WINDOWS[number];
const priorities = [
  "intake-review", "weight-fast", "recovery", "sleep-goal", "sleep-shorter", "strength-down", "protein", "weight-slow",
  "wake-time", "confirm-food", "finish-food", "strength-details", "record-food", "record-weight", "continue",
] as const;

const mean = (values: number[]) => values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : null;
const minimumSamples = (days: HealthWindow) => days === 30 ? 14 : days === 7 ? 4 : 1;
const inRange = (day: string, start: string, end: string) => day >= start && day <= end;

// Check the distribution as well as the count before using a month of records for advice.
function coversWindow(records: { day: string }[], end: string, days: HealthWindow) {
  if (records.length < minimumSamples(days)) return false;
  if (days !== 30) return true;
  const earlier = records.filter(({ day }) => day <= shiftDay(end, -15)).length;
  return earlier >= 5 && records.length - earlier >= 5;
}

// Complete days and comparable calorie balance come from the same rules as the calendar.
function summarizeFood(rows: Row[], days: CalendarDayStats[], end: string, window: HealthWindow) {
  const logged = days.filter(({ nutritionIntake }) => nutritionIntake !== null);
  const complete = logged.filter(({ foodComplete }) => foodComplete);
  const shown = complete.length ? complete : logged;
  const comparable = days.filter(({ shortfall }) => shortfall !== null);
  const saved = complete.filter(({ targetSaved }) => targetSaved);
  const proteinMet = saved.filter(({ nutritionIntake, nutritionTarget }) => nutritionIntake!.protein >= nutritionTarget.protein).length;
  const proteinBelow = saved.filter(({ nutritionIntake, nutritionTarget }) => nutritionIntake!.protein + 5 <= nutritionTarget.protein).length;
  const estimatedEntries = recordsOf(rows, "food").filter(({ payload }) => inRange(payload.day, days[0].day, end)
    && payload.spec && (payload.estimatedPortion || payload.photoRange || payload.spec.source === "estimate")).length;
  const average = (select: (day: CalendarDayStats) => Nutrition) => shown.length
    ? scale(sum(shown.map(select)), 1 / shown.length) : null;
  const proteinCovered = coversWindow(saved, end, window);

  return {
    recorded: logged.length, complete: complete.length, marked: days.filter(({ foodMarked }) => foodMarked).length,
    coverage: shown.length, intake: average(({ nutritionIntake }) => nutritionIntake!),
    target: window === 1 ? days[0].nutritionTarget : shown.every(({ targetSaved }) => targetSaved) ? average(({ nutritionTarget }) => nutritionTarget) : null,
    savedTargets: days.filter(({ targetSaved }) => targetSaved).length, proteinMet, proteinCompared: saved.length, proteinCovered,
    proteinPattern: proteinCovered && proteinBelow * 2 > saved.length,
    comparable: comparable.length, estimatedBalance: mean(comparable.map(({ shortfall }) => shortfall!)),
    uncomputedEntries: days.reduce((total, { uncomputedFood }) => total + uncomputedFood, 0), estimatedEntries,
    selected: days.at(-1)!,
  };
}

// Give each date at most one weigh-in, including when older records are imported twice.
function distinctWeights(rows: Row[], end: string): WeighIn[] {
  const dates = new Map<string, WeighIn>();
  const weighIns = recordsOf(rows, "weight").sort((a, b) => b.cursor - a.cursor || b.revision - a.revision);
  for (const { payload } of weighIns) {
    if (payload.day <= end && Number.isFinite(payload.kg) && payload.kg > 0 && !dates.has(payload.day)) dates.set(payload.day, payload);
  }
  return [...dates.values()];
}

type WeightWindow = { start: string; end: string; count: number; average: number | null; center: number | null };
function weightWindow(weights: WeighIn[], start: string, end: string): WeightWindow {
  const recorded = weights.filter(({ day }) => inRange(day, start, end));
  return { start, end, count: recorded.length, average: mean(recorded.map(({ kg }) => kg)), center: mean(recorded.map(({ day }) => dayIndex(day))) };
}

function summarizeWeight(rows: Row[], profile: Profile, start: string, end: string, days: HealthWindow) {
  const weights = distinctWeights(rows, end);
  const weekly = (to: string) => {
    const recent = weightWindow(weights, shiftDay(to, -6), to);
    const earlier = weightWindow(weights, shiftDay(to, -13), shiftDay(to, -7));
    const rate = recent.count >= 4 && earlier.count >= 4 ? weightTrend(weights, to, profile).rate : null;
    return { recent, earlier, rate };
  };
  const month = () => {
    const earlier = weightWindow(weights, start, shiftDay(end, -15));
    const recent = weightWindow(weights, shiftDay(end, -14), end);
    const covered = earlier.count >= 5 && recent.count >= 5 && earlier.count + recent.count >= 14;
    const rate = covered ? (earlier.average! - recent.average!) * 7 / (recent.center! - earlier.center!) : null;
    return { earlier, recent, rate };
  };
  const trailing = weekly(end);
  const preceding = weekly(shiftDay(end, -7));
  const comparison = days === 30 ? month() : trailing;
  const current = weightWindow(weights, start, end);
  const latest = weights.sort((a, b) => b.day.localeCompare(a.day))[0];
  const pace = (rate: number | null) => {
    if (!latest || latest.kg <= profile.goalWeight || rate === null || !(profile.paceMax >= profile.paceMin && profile.paceMin > 0)) return null;
    if (rate > profile.paceMax + 0.1) return "fast";
    if (rate < profile.paceMin - 0.1) return "slow";
    if (rate >= profile.paceMin && rate <= profile.paceMax) return "at-goal";
    return null;
  };
  const recentPace = pace(trailing.rate);
  const pattern = recentPace === pace(preceding.rate) && recentPace === pace(comparison.rate) ? recentPace : null;
  return { current, latest, comparison, pattern,
    patternWindows: pattern ? [preceding.earlier, trailing.earlier, trailing.recent] : [] };
}

// Compare one movement and equipment setup across distinct dates using working sets.
function strengthPatterns(history: StrengthEntry[], start: string) {
  const groups = new Map<string, StrengthEntry[]>();
  for (const entry of history) {
    const key = JSON.stringify([entry.move.exerciseId, definitionKey(entry.move)]);
    const entries = groups.get(key) ?? [];
    if (!entries.some(({ day }) => day === entry.day)) entries.push(entry);
    groups.set(key, entries);
  }
  const patterns = [...groups.values()].flatMap((entries) => {
    const recent = entries.slice(0, 4);
    if (recent.length < 3 || recent[0].day < start) return [];
    const direction = strengthDirection(recent);
    if (direction === "unknown") return [];
    const comparisons = recent.slice(0, -1).map((entry, index) => ({
      day: entry.day, earlier: recent[index + 1].day, difference: compareStrength(entry.move, recent[index + 1].move),
    }));
    return [{ name: recent[0].move.name, mode: recent[0].move.mode, dates: recent.map(({ day }) => day).reverse(), direction,
      example: comparisons.find(({ difference }) => difference.direction === direction) ?? comparisons[0] } as const];
  });
  const order = { down: 0, up: 1, steady: 2 };
  return patterns.sort((a, b) => order[a.direction] - order[b.direction]);
}

function summarizeTraining(rows: Row[], start: string, end: string, window: HealthWindow) {
  const workouts = recordsOf(rows, "workout").filter(({ payload }) => inRange(payload.day, start, end));
  const strength = workouts.filter(({ payload }) => payload.kind === "strength");
  const historyStart = window === 30 ? start : shiftDay(end, -13);
  const history = documentedStrength(rows, end).filter(({ day }) => day >= historyStart);
  const detailed = history.filter(({ day, move }) => day >= start && move.sets.length > 0);
  const volumes = detailed.map(({ move }) => sessionVolume(move)).filter((value): value is number => value !== null);
  return { loggedDays: new Set(workouts.map(({ payload }) => payload.day)).size,
    days: new Set(strength.map(({ payload }) => payload.day)).size, sessions: strength.length,
    detailedSessions: new Set(detailed.map(({ workoutId }) => workoutId)).size,
    workingSets: detailed.length ? detailed.reduce((total, { move }) => total + workingSets(move).length, 0) : null,
    volume: volumes.length ? volumes.reduce((total, value) => total + value, 0) : null, volumeEntries: volumes.length,
    legacySets: detailed.some(({ move }) => move.mode === "unknown" && move.exerciseId.startsWith("legacy:")),
    patterns: strengthPatterns(history, start),
  };
}

type SleepMetric = "asleep_minutes" | "core_minutes" | "deep_minutes" | "rem_minutes" | "awake_minutes" | "resting_hr" | "hrv_ms";
type MetricWindow = { start: string; end: string; nights: Night[] };

function sleepMetric(nights: Night[], metric: SleepMetric) {
  const minimum = metric === "asleep_minutes" || metric === "resting_hr" || metric === "hrv_ms" ? 1 : 0;
  const values = nights.flatMap((night) => {
    const value = night[metric];
    return value !== null && Number.isFinite(value) && value >= minimum ? [value] : [];
  });
  return { value: mean(values), count: values.length };
}

function sleepComparison(metric: SleepMetric, earlier: MetricWindow, recent: MetricWindow, days: HealthWindow) {
  const a = sleepMetric(earlier.nights, metric);
  const b = sleepMetric(recent.nights, metric);
  const minimumEarlier = days === 30 ? 5 : 4;
  const minimumRecent = days === 30 ? 5 : minimumSamples(days);
  const covered = a.count >= minimumEarlier && b.count >= minimumRecent && (days !== 30 || a.count + b.count >= 14);
  return { earlier: { start: earlier.start, end: earlier.end, ...a }, recent: { start: recent.start, end: recent.end, ...b },
    delta: covered ? b.value! - a.value! : null };
}

function timeInMinutes(time: string) {
  const [hours, minutes] = time.split(":").map(Number);
  return hours * 60 + minutes;
}

// Require several wake times on both sides of a range so a single outlier cannot trigger a pattern.
function wakeSpread(nights: Night[], typical: string, trim: number) {
  const center = timeInMinutes(typical);
  const offsets = nights.map(({ end_at }) => (timeInMinutes(sleepClock(end_at)) - center + 2160) % 1440 - 720).sort((a, b) => a - b);
  return offsets.length > trim * 2 ? offsets[offsets.length - 1 - trim] - offsets[trim] : null;
}

function summarizeSleep(nights: Night[], profile: Profile, start: string, end: string, window: HealthWindow) {
  const usable = nights.filter(({ asleep_minutes, start_at, end_at }) => Number.isFinite(asleep_minutes) && asleep_minutes > 0
    && Number.isFinite(Date.parse(start_at)) && Number.isFinite(Date.parse(end_at)));
  const series = sleepTrend(usable, end, window);
  const recorded = series.slots.flatMap(({ night }) => night ? [night] : []);
  const earlierEnd = shiftDay(end, window === 30 ? -15 : -window);
  const earlierStart = window === 30 ? start : shiftDay(earlierEnd, -6);
  const previous = sleepTrend(usable, earlierEnd, window === 30 ? 15 : 7);
  const earlier = { start: earlierStart, end: earlierEnd, nights: previous.slots.flatMap(({ night }) => night ? [night] : []) };
  const recentStart = window === 30 ? shiftDay(earlierEnd, 1) : start;
  const recent = { start: recentStart, end, nights: recorded.filter(({ day }) => day >= recentStart) };
  const comparison = (metric: SleepMetric) => ({ ...sleepMetric(recorded, metric), comparison: sleepComparison(metric, earlier, recent, window) });
  const goalMinutes = profile.sleepGoalMinutes;
  const goal = goalMinutes && Number.isFinite(goalMinutes) && goalMinutes > 0 ? { minutes: goalMinutes,
    met: recorded.filter(({ asleep_minutes }) => asleep_minutes >= goalMinutes).length } : null;
  const covered = coversWindow(recorded, end, window);
  const belowGoal = goal !== null && covered
    && recorded.filter(({ asleep_minutes }) => asleep_minutes + 30 <= goal.minutes).length * 2 > recorded.length;
  let reducedWakeSpread: number | null = null;
  if (window === 30 && covered && previous.wake) {
    const currentWake = sleepTrend(usable, end, 15).wake;
    const previousSpread = wakeSpread(earlier.nights, previous.wake.typical, 1);
    const currentSpread = currentWake && wakeSpread(recent.nights, currentWake.typical, 1);
    if (previousSpread !== null && currentSpread !== null && previousSpread - currentSpread >= 30) {
      reducedWakeSpread = previousSpread - currentSpread;
    }
  }
  return { count: recorded.length, bedtime: series.bedtime, wake: series.wake,
    duration: comparison("asleep_minutes"), goal, covered, belowGoal, reducedWakeSpread,
    timingVaries: window !== 1 && covered && series.wake !== null && (wakeSpread(recorded, series.wake.typical, window === 30 ? 2 : 1) ?? 0) >= 75,
    stages: { core: sleepMetric(recorded, "core_minutes"), deep: sleepMetric(recorded, "deep_minutes"),
      rem: sleepMetric(recorded, "rem_minutes"), awake: sleepMetric(recorded, "awake_minutes") },
    resting: comparison("resting_hr"), hrv: comparison("hrv_ms"),
  };
}

// Build a dated summary from local records, with example and personal data in separate views.
export function healthSummary({ rows, profile, nights, day, today, window, demoSleep = false, sleepCurrent = true }: {
  rows: Row[]; profile: Profile; nights: Night[]; day: string; today: string; window: HealthWindow;
  demoSleep?: boolean; sleepCurrent?: boolean;
}) {
  const end = day <= today ? day : today;
  const start = shiftDay(end, 1 - window);
  const hasIntakeOrActivity = ({ kind, payload }: Row) => payload !== null && (
    kind === "food" || kind === "food_day" || kind === "workout" || kind === "weight" || kind === "activity");
  const personal = rows.some((row) => !row.sample && hasIntakeOrActivity(row));
  const exampleRows = !personal && rows.some((row) => row.sample && hasIntakeOrActivity(row));
  const exampleSleep = demoSleep && !personal;
  const sameSource = rows.filter((row) => Boolean(row.sample) === exampleRows);
  const food = summarizeFood(sameSource, calendarStats(sameSource, profile, start, end, today).days, end, window);
  const weight = summarizeWeight(sameSource, profile, start, end, window);
  const training = summarizeTraining(sameSource, start, end, window);
  const sameSleepSource = demoSleep ? exampleSleep : !exampleRows;
  const sleep = summarizeSleep(sameSleepSource ? nights : [], profile, start, end, window);

  // Pick one small next step. Numeric changes are descriptive and never change a saved goal.
  const weaker = training.patterns.some(({ direction }) => direction === "down");
  const shorterSleep = sleepCurrent && (sleep.belowGoal || (sleep.duration.comparison.delta ?? 0) <= -45);
  function priority(): typeof priorities[number] {
    if (weight.pattern === "fast" && weaker && food.comparable >= 3 && (food.estimatedBalance ?? 0) > 0) return "intake-review";
    if (weight.pattern === "fast") return "weight-fast";
    if (window === 7 && shorterSleep && training.days >= 4) return "recovery";
    if (sleepCurrent && sleep.belowGoal) return "sleep-goal";
    if (sleepCurrent && (sleep.duration.comparison.delta ?? 0) <= -45) return "sleep-shorter";
    if (weaker) return "strength-down";
    if (food.proteinPattern) return "protein";
    if (weight.pattern === "slow") return "weight-slow";
    if (sleepCurrent && sleep.timingVaries) return "wake-time";
    if (food.uncomputedEntries) return "confirm-food";
    if (window === 1 && food.recorded && !food.marked) return "finish-food";
    if (training.detailedSessions < training.sessions) return "strength-details";
    if (food.complete < minimumSamples(window)) return "record-food";
    if (weight.current.count < minimumSamples(window)) return "record-weight";
    return "continue";
  }

  function positive() {
    if (training.patterns.some(({ direction }) => direction === "up")) return "strength-up";
    if (weight.pattern === "at-goal" && !weaker && training.patterns.some(({ direction }) => direction === "steady")) return "cut-strength";
    if (sleepCurrent && sleep.reducedWakeSpread !== null) return "wake-improved";
    if (weight.pattern === "at-goal") return "weight-goal";
    if (sleepCurrent && sleep.covered && sleep.goal && sleep.goal.met * 2 >= sleep.count) return "sleep-goal";
    if (food.proteinCovered && food.proteinMet * 2 >= food.proteinCompared) return "protein-goal";
    if (food.complete >= minimumSamples(window)) return "food-complete";
    if (training.workingSets) return "strength-recorded";
    return null;
  }

  return { window, start, end, food, weight, training, sleep, example: exampleRows || exampleSleep,
    personal, priority: priority(), positive: positive() };
}

export type HealthSummary = ReturnType<typeof healthSummary>;

// Pick the strongest covered pattern. Daily tasks win when the evidence is otherwise equal.
export function focusHealth(daily: HealthSummary, week: HealthSummary, month: HealthSummary) {
  return [week, month].reduce((best, next) => {
    const rank = priorities.indexOf(next.priority);
    const current = priorities.indexOf(best.priority);
    return rank < current || (rank === current && best.window === 1 && rank <= priorities.indexOf("wake-time")) ? next : best;
  }, daily);
}
