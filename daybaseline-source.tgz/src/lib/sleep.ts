import { shiftDay, TZ } from "./dates.ts";
import { recordsOf, type Profile, type Row } from "./model.ts";
import { foodTotals } from "./nutrition.ts";

export type Night = {
  day: string;
  start_at: string;
  end_at: string;
  asleep_minutes: number;
  core_minutes: number | null;
  deep_minutes: number | null;
  rem_minutes: number | null;
  awake_minutes: number | null;
  resting_hr: number | null;
  hrv_ms: number | null;
  observed_at: string;
};

export type SleepReport = {
  kind: "daily" | "weekly";
  day: string;
  summary: string;
  advice: string;
  trend_30: string | null;
  coverage_days: number | null;
  observed_at: string;
};

export type SleepData = { nights: Night[]; reports: SleepReport[] };
export const EMPTY_SLEEP: SleepData = { nights: [], reports: [] };

export type SleepSyncSummary = {
  latest_received_at: string | null;
  latest_observed_at: string | null;
  latest_wake_day: string | null;
  coverage_7: number;
  coverage_30: number;
};

// A new upload of older nights can leave the latest wake date stale.
export function sleepSyncFreshness(summary: SleepSyncSummary, today: string, now = Date.now()) {
  if (!summary.latest_wake_day) return "empty";
  const lastUpdate = summary.latest_received_at ?? summary.latest_observed_at;
  if (summary.latest_wake_day < shiftDay(today, -2) ||
    (lastUpdate && now - Date.parse(lastUpdate) >= 72 * 60 * 60_000)) return "stale";
  return summary.latest_received_at ? "recent" : "legacy";
}

const clock = new Intl.DateTimeFormat("en-GB", {
  timeZone: TZ, hour: "2-digit", minute: "2-digit", hourCycle: "h23",
});
const localStamp = new Intl.DateTimeFormat("en-CA", {
  timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23",
});

export function sleepClock(timestamp: string) {
  return clock.format(new Date(timestamp));
}

export function sleepStamp(timestamp: string) {
  return localStamp.format(new Date(timestamp));
}

export function sleepDuration(minutes: number, english: boolean) {
  const hours = Math.floor(minutes / 60);
  const remainder = minutes % 60;
  if (english) return hours > 0 ? `${hours}h ${remainder}m` : `${remainder}m`;
  return hours > 0 ? `${hours} 小时 ${remainder} 分` : `${remainder} 分`;
}

// Use a 24-hour clock across midnight. Rotate the clock at the largest gap.
function clockPattern(stamps: string[]) {
  if (!stamps.length) return null;
  const times = stamps.map((stamp) => {
    const [hours, minutes] = sleepClock(stamp).split(":").map(Number);
    return hours * 60 + minutes;
  }).sort((a, b) => a - b);
  let gap = -1;
  let start = 0;
  for (let i = 0; i < times.length; i++) {
    const next = (i + 1) % times.length;
    const distance = times[next] + (next === 0 ? 1440 : 0) - times[i];
    if (distance > gap) { gap = distance; start = next; }
  }
  const center = Math.round(times.reduce((sum, value) => sum + value + (value < times[start] ? 1440 : 0), 0) / times.length) % 1440;
  const typical = `${String(Math.floor(center / 60)).padStart(2, "0")}:${String(center % 60).padStart(2, "0")}`;
  return { typical, spread: 1440 - gap };
}

// Missing nights occupy the timeline but never count as zero in averages.
export function sleepTrend(nights: Night[], endDay: string, days: number) {
  const byDay = new Map(nights.map((night) => [night.day, night]));
  const slots = Array.from({ length: days }, (_, offset) => {
    const day = shiftDay(endDay, offset + 1 - days);
    return { day, night: byDay.get(day) };
  });
  const recorded = slots.flatMap(({ night }) => night ? [night] : []);
  return {
    slots,
    count: recorded.length,
    average: recorded.length ? Math.round(recorded.reduce((sum, night) => sum + night.asleep_minutes, 0) / recorded.length) : null,
    bedtime: clockPattern(recorded.map(({ start_at }) => start_at)),
    wake: clockPattern(recorded.map(({ end_at }) => end_at)),
  };
}

// Keep recommendations tied to logged days. The advice never writes nutrition targets.
export function loggedContext(rows: Row[], profile: Profile, day: string) {
  const start = shiftDay(day, -6);
  const inWeek = (value: string) => value >= start && value <= day;
  const protein = new Map<string, number>();
  for (const { payload } of recordsOf(rows, "food")) {
    if (!inWeek(payload.day)) continue;
    const total = foodTotals(payload)?.total;
    if (total) protein.set(payload.day, (protein.get(payload.day) ?? 0) + total.protein);
  }
  const training = new Set(recordsOf(rows, "workout").filter(({ payload }) => inWeek(payload.day)).map(({ payload }) => payload.day));
  const weights = recordsOf(rows, "weight").filter(({ payload }) => inWeek(payload.day)).map(({ payload }) => payload.kg);
  const foodDays = protein.size;
  const proteinTargetDays = [...protein.values()].filter((grams) => grams >= profile.protein).length;
  return {
    foodDays, proteinTargetDays,
    trainingDays: training.size,
    weighedDays: weights.length,
    averageKg: weights.length ? weights.reduce((sum, kg) => sum + kg, 0) / weights.length : null,
    trained: training.has(day),
  };
}

// Synthetic examples are independent of all account data and never enter the sync API.
export function sampleSleep(today: string): SleepData {
  const nights: Night[] = [];
  for (let i = 29; i >= 0; i--) {
    if (i === 5 || i === 14 || i === 23) continue;
    const day = shiftDay(today, -i);
    const end = new Date(day + "T15:10:00Z");
    end.setUTCMinutes(end.getUTCMinutes() + (i * 17) % 94);
    const minutes = 405 + (i * 37) % 108;
    const start = new Date(end.getTime() - (minutes + 16) * 60_000);
    const deep = 55 + (i * 11) % 29;
    const rem = 84 + (i * 7) % 40;
    nights.push({
      day, start_at: start.toISOString(), end_at: end.toISOString(), asleep_minutes: minutes,
      core_minutes: minutes - deep - rem, deep_minutes: deep, rem_minutes: rem, awake_minutes: 16,
      resting_hr: 58 + i % 6, hrv_ms: 36 + (i * 2) % 15,
      observed_at: new Date(end.getTime() + 45 * 60_000).toISOString(),
    });
  }
  return { nights, reports: [] };
}
