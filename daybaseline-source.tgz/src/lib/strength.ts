import { recordsOf, type LoadMode, type LogRow, type Row, type StrengthDefinition, type StrengthFavorite,
  type StrengthMove, type StrengthSet, type WeightUnit, type Workout } from "./model.ts";
import { normalize } from "./nutrition.ts";

export const LB_IN_KG = 0.45359237;
export const LOAD_TOLERANCE_KG = 0.075;
const prettyWeight = new Intl.NumberFormat("en-US", { maximumFractionDigits: 1 });

export const loadNames: Record<LoadMode, [string, string]> = {
  dumbbell: ["哑铃 · 单只重量", "Dumbbell · per hand"],
  barbell: ["杠铃 · 含杆总重", "Barbell · total"],
  plates: ["杠铃 · 仅片重", "Barbell · plates only"],
  machine: ["器械", "Machine"],
  bodyweight: ["自重", "Bodyweight"],
  assisted: ["辅助重量", "Assistance"],
  other: ["其他负重", "Other loaded"],
  unknown: ["旧记录 · 口径未知", "Legacy · setup unknown"],
};

export function toKg(weight: number, unit: WeightUnit) {
  return unit === "lb" ? weight * LB_IN_KG : weight;
}

export function dualWeight(weight: number | null, unit: WeightUnit) {
  if (weight === null) return "—";
  const converted = unit === "lb" ? toKg(weight, unit) : weight / LB_IN_KG;
  return `${weight} ${unit} (${prettyWeight.format(converted)} ${unit === "lb" ? "kg" : "lb"})`;
}

// Normalize comparing values without altering any historical input.
export function setKg(move: StrengthDefinition, set: StrengthSet): number | null {
  if (set.weight === null || !Number.isFinite(set.weight) || set.weight < 0
    || move.mode === "bodyweight" || move.mode === "unknown") return null;
  const kg = toKg(set.weight, set.unit);
  if (move.mode !== "plates") return kg;
  return move.bar ? kg + toKg(move.bar.weight, move.bar.unit) : null;
}

export function sameLoad(a: number, b: number) {
  return Math.abs(a - b) <= LOAD_TOLERANCE_KG;
}

// Names, implements and setups can differ even when they train the same muscle.
export function definitionKey(move: Omit<StrengthDefinition, "exerciseId">) {
  const mode = move.mode === "plates" ? "barbell" : move.mode;
  return JSON.stringify([normalize(move.name), move.muscle, mode, normalize(move.variant),
    mode === "dumbbell" ? move.dumbbells ?? 2 : 0]);
}

export function workoutStrength(workout: Pick<Workout, "kind" | "exercises" | "strengthDetails">): StrengthMove[] {
  if (workout.kind !== "strength") return [];
  if (Array.isArray(workout.strengthDetails)) return workout.strengthDetails;
  return (workout.exercises ?? []).flatMap((move) => {
    if (!move.name || !Number.isInteger(move.sets) || move.sets < 1 || move.sets > 100
      || !Number.isInteger(move.reps) || move.reps < 1 || move.reps > 300) return [];
    const definition = { name: move.name, muscle: move.muscle, mode: "unknown", variant: "" } as const;
    const weight = Number.isFinite(move.weight) && move.weight > 0 ? move.weight : null;
    return [{ ...definition, exerciseId: "legacy:" + definitionKey(definition),
      sets: Array.from({ length: move.sets }, () => ({ weight, unit: move.unit, reps: move.reps })) }];
  });
}

export type StrengthEntry = { id: string; workoutId: string; day: string; time: number; move: StrengthMove };

export function strengthEntries(workouts: LogRow<"workout">[], through?: string): StrengthEntry[] {
  return workouts.filter(({ payload }) => through === undefined || payload.day <= through).flatMap(({ id, payload }) => {
    // Count an exercise once per workout, even if a returning set was noted separately.
    const byExercise = new Map<string, StrengthEntry>();
    for (const move of workoutStrength(payload)) {
      const earlier = byExercise.get(move.exerciseId);
      if (earlier && definitionKey(earlier.move) === definitionKey(move) && earlier.move.mode === move.mode
        && JSON.stringify(earlier.move.bar ?? null) === JSON.stringify(move.bar ?? null)) {
        earlier.move = { ...earlier.move, sets: [...earlier.move.sets, ...move.sets] };
      } else {
        const key = earlier ? move.exerciseId + ":" + byExercise.size : move.exerciseId;
        byExercise.set(key, { id: id + ":" + key, workoutId: id, day: payload.day, time: payload.time, move });
      }
    }
    return [...byExercise.values()];
  }).sort((a, b) => b.day.localeCompare(a.day) || b.time - a.time || a.id.localeCompare(b.id));
}

export function strengthCatalog(history: StrengthEntry[], favorites: LogRow<"strength_exercise">[]) {
  const choices = new Map<string, StrengthFavorite>();
  for (const { move } of history) {
    if (!choices.has(move.exerciseId)) {
      const { sets, ...definition } = move;
      choices.set(move.exerciseId, { ...definition, unit: sets.at(-1)?.unit ?? "lb" });
    }
  }
  for (const { payload } of favorites) choices.set(payload.exerciseId, payload);
  return [...choices.values()];
}

export function previousStrength(history: StrengthEntry[], move: StrengthDefinition,
  day: string, editing?: { id: string; time: number }) {
  return history.find((entry) => entry.move.exerciseId === move.exerciseId
    && entry.workoutId !== editing?.id
    && (entry.day < day || (entry.day === day && (!editing || entry.time < editing.time))));
}

export function workingSets(move: StrengthMove) {
  return move.sets.filter((set) => !set.warmup);
}

export function sessionVolume(move: StrengthMove): number | null {
  if (move.mode === "assisted" || move.mode === "bodyweight" || move.mode === "unknown") return null;
  const sets = workingSets(move);
  const multiplier = move.mode === "dumbbell" ? move.dumbbells ?? 2 : 1;
  let volume = 0;
  for (const set of sets) {
    const kg = setKg(move, set);
    if (kg === null) return null;
    volume += kg * multiplier * set.reps;
  }
  return sets.length ? volume : null;
}

export type PerformanceSet = { set: StrengthSet; kg: number | null };

export function topSet(move: StrengthMove): PerformanceSet | null {
  const sets = workingSets(move).map((set) => ({ set, kg: setKg(move, set) }));
  if (move.mode === "bodyweight") return sets.sort((a, b) => b.set.reps - a.set.reps)[0] ?? null;
  const sign = move.mode === "assisted" ? -1 : 1;
  return sets.filter((entry) => entry.kg !== null)
    .sort((a, b) => sign * (b.kg! - a.kg!) || b.set.reps - a.set.reps)[0] ?? null;
}

export type StrengthDifference = {
  direction: "up" | "down" | "steady" | "unknown";
  metric: "reps" | "load" | null;
  delta: number | null;
};
const difference = (delta: number, metric: NonNullable<StrengthDifference["metric"]>): StrengthDifference => ({
  direction: delta === 0 ? "steady" : delta > 0 ? "up" : "down", metric, delta,
});
const incomparable: StrengthDifference = { direction: "unknown", metric: null, delta: null };

// Compare like for like. Different rep targets and load with no common anchor are separate observations.
export function compareStrength(now: StrengthMove, before: StrengthMove): StrengthDifference {
  if (now.exerciseId !== before.exerciseId || definitionKey(now) !== definitionKey(before)) return incomparable;
  if (now.mode === "bodyweight") {
    const a = topSet(now);
    const b = topSet(before);
    return a && b ? difference(a.set.reps - b.set.reps, "reps") : incomparable;
  }
  const a = workingSets(now).flatMap((set) => {
    const kg = setKg(now, set);
    return kg === null ? [] : [{ kg, reps: set.reps }];
  });
  const b = workingSets(before).flatMap((set) => {
    const kg = setKg(before, set);
    return kg === null ? [] : [{ kg, reps: set.reps }];
  });
  const sign = now.mode === "assisted" ? -1 : 1;
  const anchors = a.filter((set) => b.some(({ kg }) => sameLoad(kg, set.kg)))
    .sort((x, y) => sign * (y.kg - x.kg));
  if (anchors.length) {
    const anchor = anchors[0].kg;
    const repsAt = (sets: typeof a) => Math.max(...sets.filter(({ kg }) => sameLoad(kg, anchor)).map(({ reps }) => reps));
    return difference(repsAt(a) - repsAt(b), "reps");
  }
  const matched = a.filter(({ reps }) => b.some((set) => reps === set.reps)).sort((x, y) => y.reps - x.reps);
  if (!matched.length) return incomparable;
  const bestAt = (sets: typeof a) => Math.max(...sets.filter(({ reps }) => reps === matched[0].reps).map(({ kg }) => sign * kg));
  const delta = bestAt(a) - bestAt(b);
  return difference(Math.abs(delta) <= LOAD_TOLERANCE_KG ? 0 : delta, "load");
}

export function strengthDirection(entries: StrengthEntry[]) {
  const days = new Map<string, StrengthEntry>();
  for (const entry of entries) if (!days.has(entry.day)) days.set(entry.day, entry);
  const recent = [...days.values()].sort((a, b) => b.day.localeCompare(a.day)).slice(0, 4);
  const changes = recent.slice(0, -1).map(({ move }, index) => compareStrength(move, recent[index + 1].move).direction);
  if (changes.length < 2 || changes.includes("unknown")) return "unknown";
  const up = changes.filter((change) => change === "up").length;
  const down = changes.filter((change) => change === "down").length;
  if (up >= 2 && down === 0) return "up";
  if (down >= 2 && up === 0) return "down";
  return changes.every((change) => change === "steady") ? "steady" : "unknown";
}

export function documentedStrength(rows: Row[], through: string) {
  return strengthEntries(recordsOf(rows, "workout"), through);
}
