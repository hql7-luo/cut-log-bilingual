"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { shiftDay } from "./dates";
import { DEMO_EDITION } from "./public-config";
import { EMPTY_SLEEP, sampleSleep, type SleepData, type SleepSyncSummary } from "./sleep";
import { pullSleep, pullSleepStatus } from "./supabase";
import type { useCloudAuth } from "./use-tracker";

type ReadStatus = "loading" | "error" | "ready";
type SleepRead<T> = { key: string; data: T | null; status: Exclude<ReadStatus, "loading"> };

export type SleepView = SleepData & {
  status: "demo" | "signed-out" | ReadStatus;
  sync?: { status: ReadStatus; summary: SleepSyncSummary | null };
};

// Keep each read scoped to its own account and date key, including cached results after a failed refresh.
function useSleepRead<T>(key: string | undefined, enabled: boolean, token: () => Promise<string>,
  read: (access: string, signal: AbortSignal) => Promise<T>) {
  const [result, setResult] = useState<SleepRead<T> | null>(null);

  useEffect(() => {
    if (!key || !enabled) return;
    const controller = new AbortController();
    const { signal } = controller;
    let running = false;
    async function refresh() {
      if (running || signal.aborted || document.visibilityState === "hidden" || !key) return;
      running = true;
      try {
        const access = await token();
        if (signal.aborted) return;
        const data = await read(access, signal);
        if (!signal.aborted) setResult({ key, data, status: "ready" });
      } catch {
        if (!signal.aborted) setResult((before) => ({ key, data: before?.key === key ? before.data : null, status: "error" }));
      } finally { running = false; }
    }
    void refresh();
    const interval = window.setInterval(refresh, 60_000);
    document.addEventListener("visibilitychange", refresh);
    window.addEventListener("online", refresh);
    return () => {
      controller.abort();
      window.clearInterval(interval);
      document.removeEventListener("visibilitychange", refresh);
      window.removeEventListener("online", refresh);
    };
  }, [enabled, key, read, token]);

  return result?.key === key ? result : null;
}

export function useSleep(auth: ReturnType<typeof useCloudAuth>, today: string, day: string, enabled: boolean): SleepView {
  const user = auth.session?.user.id;
  const examples = useMemo(() => DEMO_EDITION ? sampleSleep(today) : EMPTY_SLEEP, [today]);
  const readWindow = useCallback((access: string, signal: AbortSignal) =>
    pullSleep(access, shiftDay(day, -29), day, signal), [day]);
  const windowRead = useSleepRead(user ? user + ":" + day : undefined, enabled && !DEMO_EDITION, auth.token, readWindow);
  const syncRead = useSleepRead(user, enabled && !DEMO_EDITION, auth.token, pullSleepStatus);
  if (DEMO_EDITION) return { ...examples, status: "demo" };
  if (!user) return { ...EMPTY_SLEEP, status: auth.ready ? "signed-out" : "loading" };
  return {
    ...(windowRead?.data ?? EMPTY_SLEEP),
    status: windowRead?.status ?? "loading",
    sync: { status: syncRead?.status ?? "loading", summary: syncRead?.data ?? null },
  };
}
