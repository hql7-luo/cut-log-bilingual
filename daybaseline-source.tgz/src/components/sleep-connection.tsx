"use client";

import { useEffect, useState } from "react";
import { sleepCredential } from "../lib/supabase";
import { sleepStamp } from "../lib/sleep";
import type { useCloudAuth } from "../lib/use-tracker";
import { useLanguage } from "./language";
import { Button, CardHead } from "./ui";

export function SleepConnection({ auth }: { auth: ReturnType<typeof useCloudAuth> }) {
  const { language } = useLanguage();
  const en = language === "en";
  const access = auth.token;
  const [expires, setExpires] = useState<string | null | undefined>();
  const [secret, setSecret] = useState("");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const unavailable = en ? "Could not update sleep connection." : "暂时无法管理睡眠连接。";

  useEffect(() => {
    let active = true;
    access().then((token) => sleepCredential(token, "status")).then((result) => {
      if (active) setExpires(result.expires_at);
    }).catch(() => { if (active) setNotice(unavailable); });
    return () => { active = false; };
  }, [access, unavailable]);

  async function update(action: "create" | "revoke") {
    setBusy(true);
    setNotice("");
    try {
      const result = await sleepCredential(await access(), action);
      setExpires(result.expires_at);
      setSecret(result.token ?? "");
    } catch { setNotice(unavailable); }
    finally { setBusy(false); }
  }

  return <section className="card padded form-stack">
    <CardHead title={en ? "Muse sleep sync" : "Muse 睡眠同步"} icon="moon"/>
    <p className="muted">{expires ? (en ? "Key expires " : "同步密钥有效期至 ") + sleepStamp(expires) + " PT" :
      (en ? "Connect Muse with a key that only imports sleep and reports." : "用专用密钥连接 Muse，导入睡眠和报告。")}</p>
    {secret && <>
      <input className="sleep-key" readOnly type="password" value={secret} aria-label={en ? "New sleep key" : "新睡眠密钥"}/>
      <div className="inline-actions wrap">
        <Button onClick={() => navigator.clipboard.writeText(secret).then(
          () => setNotice(en ? "Copied. Paste it in Muse’s secure credential field." : "已复制。请粘贴到 Muse 的安全凭据框。"),
          () => setNotice(en ? "Clipboard access failed. Select and copy the key field." : "无法复制，请选中密钥框后手动复制。"))}>
          {en ? "Copy key" : "复制密钥"}</Button>
        <Button variant="quiet" onClick={() => setSecret("")}>{en ? "Done" : "完成"}</Button>
      </div>
    </>}
    {expires !== undefined && <div className="inline-actions wrap">
      {expires ? <Button variant="quiet" disabled={busy} onClick={() => update("revoke")}>{en ? "Disconnect sync" : "断开同步"}</Button> :
        <Button disabled={busy} onClick={() => update("create")}>{en ? "Create sleep sync key" : "生成睡眠同步密钥"}</Button>}
    </div>}
    {notice && <p role="status" className="fine">{notice}</p>}
  </section>;
}
