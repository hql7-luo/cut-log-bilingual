"use client";

import { useState } from "react";
import { compactDay, dateTitle, isDay, shiftDay } from "../lib/dates";
import { sleepClock, sleepDuration, sleepStamp, sleepSyncFreshness, sleepTrend, type Night } from "../lib/sleep";
import type { Profile, Row } from "../lib/model";
import type { SleepView } from "../lib/use-sleep";
import { HealthAdvice } from "./health-advice";
import { useLanguage } from "./language";
import { CardHead, IconButton } from "./ui";

const names = {
  core: { zh: "核心", en: "Core" }, deep: { zh: "深睡", en: "Deep" },
  rem: { zh: "REM", en: "REM" }, awake: { zh: "清醒", en: "Awake" },
};

function SleepDetails({ night, stages }: { night: Night; stages: boolean }) {
  const { language } = useLanguage();
  const en = language === "en";
  const values = { core: night.core_minutes, deep: night.deep_minutes, rem: night.rem_minutes, awake: night.awake_minutes };
  return <>
    <div className="sleep-number">{sleepDuration(night.asleep_minutes, en)}</div>
    <dl className="sleep-details">
      <div><dt>{en ? "Asleep" : "入睡"}</dt><dd>{sleepClock(night.start_at)}</dd></div>
      <div><dt>{en ? "Wake" : "起床"}</dt><dd>{sleepClock(night.end_at)}</dd></div>
    </dl>
    {stages && <>
      <p className="sleep-caption">{en ? "Apple Watch estimates" : "Apple Watch 阶段估算"}</p>
      <div className="sleep-stages">
        {Object.entries(values).map(([key, minutes]) => <div key={key}>
          <i className={key} aria-hidden="true"/><span>{names[key as keyof typeof names][language]}</span>
          <strong>{minutes === null ? "—" : sleepDuration(minutes, en)}</strong>
        </div>)}
      </div>
      {(night.resting_hr !== null || night.hrv_ms !== null) && <dl className="sleep-details sleep-vitals">
        {night.resting_hr !== null && <div><dt>{en ? "Resting heart rate" : "静息心率"}</dt><dd>{night.resting_hr} bpm</dd></div>}
        {night.hrv_ms !== null && <div><dt>HRV</dt><dd>{night.hrv_ms} ms</dd></div>}
      </dl>}
    </>}
  </>;
}

function SleepEmpty({ status }: Pick<SleepView, "status">) {
  const { language } = useLanguage();
  const en = language === "en";
  if (status === "signed-out") return <a className="text-link" href="#settings">{en ? "Sign in to see your sleep" : "登录后查看睡眠"}</a>;
  return <p className="muted" role="status">{status === "loading" ? (en ? "Reading sleep…" : "正在读取睡眠…") :
    status === "error" ? (en ? "Could not read sleep for this date." : "暂时无法读取这一天的睡眠。") :
      (en ? "No synced sleep for this date yet." : "这一天暂无已同步睡眠。")}</p>;
}

export function SleepOverview({ view, day, today, rows, profile }: {
  view: SleepView; day: string; today: string; rows: Row[]; profile: Profile;
}) {
  const { language } = useLanguage();
  const en = language === "en";
  const night = view.nights.find((item) => item.day === day);
  return <div className="sleep-grid overview-health">
    <section className="card padded sleep-card">
      <CardHead title={day === today ? (en ? "Last night" : "昨夜睡眠") : (en ? "Sleep on this date" : "这一天的睡眠")} icon="moon">
        <a className="text-link" href="#sleep">{en ? "Sleep details" : "睡眠详情"}</a>
      </CardHead>
      {night ? <SleepDetails night={night} stages={false}/> : <SleepEmpty status={view.status}/>}
      {view.status === "demo" && <p className="sleep-caption">{en ? "Sample data" : "模拟数据"}</p>}
    </section>
    <HealthAdvice view={view} rows={rows} profile={profile} day={day} today={today}/>
  </div>;
}

function SleepSyncStatus({ sync, today }: { sync: NonNullable<SleepView["sync"]>; today: string }) {
  const { language } = useLanguage();
  const en = language === "en";
  const { summary } = sync;
  const messages = {
    recent: en ? "Recent sleep data received." : "近期有已接收的睡眠记录。",
    stale: en ? "The latest sleep data are out of date." : "最近的睡眠数据较旧。",
    legacy: en ? "Recent sleep source data are available." : "近期有来源睡眠记录。",
    empty: en ? "No sleep has been imported yet." : "尚无已导入的睡眠记录。",
  };
  let message = summary ? messages[sleepSyncFreshness(summary, today)] : "";
  if (sync.status === "loading") message = en ? "Reading sync status…" : "正在读取同步状态…";
  if (sync.status === "error") message = summary
    ? (en ? "Could not refresh sync status. Showing the previous result." : "暂时无法更新同步状态，以下为上次读取结果。")
    : (en ? "Could not read sync status." : "暂时无法读取同步状态。");

  return <section className="card padded sleep-report">
    <CardHead title={en ? "Sleep sync status" : "睡眠同步状态"} icon="cloud"/>
    <p className="sleep-caption" role="status">{message}</p>
    {summary && <dl className="sleep-metrics">
      <div><dt>{en ? "Last site receipt" : "网站接收时间"}</dt><dd>
        {summary.latest_received_at ? <time dateTime={summary.latest_received_at}>{sleepStamp(summary.latest_received_at)} PT</time> :
          summary.latest_observed_at ? (en ? "Unrecorded for older imports" : "历史导入未记录") : "—"}
      </dd></div>
      <div><dt>{en ? "Last source read" : "来源读取时间"}</dt><dd>
        {summary.latest_observed_at ? <time dateTime={summary.latest_observed_at}>{sleepStamp(summary.latest_observed_at)} PT</time> : "—"}
      </dd></div>
      <div><dt>{en ? "Latest wake date" : "最近醒来日期"}</dt><dd>
        {summary.latest_wake_day ? <time dateTime={summary.latest_wake_day}>{summary.latest_wake_day}</time> : "—"}
      </dd></div>
      <div><dt>{en ? "Last 7 / 30 days" : "近 7 / 30 天记录"}</dt><dd>{summary.coverage_7}/7 · {summary.coverage_30}/30</dd></div>
    </dl>}
  </section>;
}

export function SleepPage({ view, day, today, select, rows, profile }: {
  view: SleepView; day: string; today: string; select: (value: string) => void; rows: Row[]; profile: Profile;
}) {
  const { language } = useLanguage();
  const en = language === "en";
  const [windowDays, setWindowDays] = useState<7 | 30>(7);
  const trend = sleepTrend(view.nights, day, windowDays);
  const night = view.nights.find((item) => item.day === day);
  const daily = view.reports.find(({ kind, day: reportDay }) => kind === "daily" && reportDay === day);
  const weekly = view.reports.find(({ kind, day: reportDay }) => kind === "weekly" && reportDay <= day);
  const sampleWeek = sleepTrend(view.nights, day, 7);
  const sampleMonth = sleepTrend(view.nights, day, 30);
  const chartScale = Math.max(540, ...trend.slots.map(({ night: item }) => item?.asleep_minutes ?? 0));
  const previousDay = shiftDay(day, -1);
  const nextDay = shiftDay(day, 1);
  const readFailed = view.status === "error";
  const showMetrics = view.status === "ready" || view.status === "demo" || trend.count > 0;
  let gap = en ? "No record" : "暂无记录";
  let chartNote = en ? "Gaps indicate missing data. Averages use recorded nights." : "空白代表缺少记录，平均值按已记录晚数计算。";
  if (view.status === "loading") {
    gap = en ? "Reading…" : "正在读取…";
    chartNote = en ? "Reading the selected date range…" : "正在读取这段日期的睡眠…";
  }
  if (view.status === "signed-out") {
    gap = en ? "Sign in to view" : "登录后查看";
    chartNote = en ? "Sign in to see sleep trends." : "登录后查看睡眠趋势。";
  }
  if (readFailed) {
    gap = en ? "Data unavailable" : "暂时无法读取";
    chartNote = showMetrics ? (en ? "Could not refresh this range. Showing the previous result." : "暂时无法更新这段日期，当前显示上次读取结果。") :
      (en ? "Could not read sleep for this range." : "暂时无法读取这段日期的睡眠。");
  }
  return <div className="sleep-page">
    <div className="sleep-grid">
      <section className="card padded sleep-card">
        <CardHead title={en ? "Nightly sleep" : "当晚睡眠"} icon="moon">
          <input className="sleep-date" type="date" aria-label={en ? "Sleep wake date" : "睡眠醒来日期"}
            max={today} value={day} onChange={(event) => {
              const value = event.currentTarget.value;
              if (isDay(value) && value <= today) select(value);
            }}/>
        </CardHead>
        {night ? <SleepDetails night={night} stages/> : <SleepEmpty status={view.status}/>}
        {view.status === "demo" && <p className="sleep-caption">{en ? "Sample data" : "模拟数据"}</p>}
      </section>
      <HealthAdvice view={view} rows={rows} profile={profile} day={day} today={today} showMuse={false}/>
    </div>
    <section className="card padded sleep-trend">
      <CardHead title={en ? "Sleep trends" : "睡眠趋势"} icon="chart">
        <div className="sleep-period" role="group" aria-label={en ? "Trend range" : "趋势范围"}>
          {([7, 30] as const).map((days) => <button key={days} type="button" aria-pressed={days === windowDays}
            onClick={() => setWindowDays(days)}>{en ? `${days} days` : `${days} 天`}</button>)}
        </div>
      </CardHead>
      <dl className="sleep-metrics">
        <div><dt>{en ? "Average sleep" : "平均睡眠"}</dt><dd>{trend.average !== null ? sleepDuration(trend.average, en) : "—"}</dd></div>
        <div><dt>{en ? "Nights recorded" : "已记录晚数"}</dt><dd>{showMetrics ? `${trend.count}/${windowDays}` : "—"}</dd></div>
        <div><dt>{en ? "Typical sleep / wake" : "常见入睡 / 起床"}</dt><dd>{trend.bedtime && trend.wake ? `${trend.bedtime.typical} / ${trend.wake.typical}` : "—"}</dd></div>
        <div><dt>{en ? "Wake-time range" : "起床时间波动"}</dt><dd>{trend.wake && trend.count > 1 ? sleepDuration(trend.wake.spread, en) : "—"}</dd></div>
      </dl>
      <div className="inline-heading" role="group" aria-label={en ? "Browse sleep dates" : "浏览睡眠日期"}>
        <IconButton icon="arrow" className="date-step date-step-back" label={en ? "Previous day" : "前一天"}
          disabled={!isDay(previousDay)} onClick={() => select(previousDay)}/>
        <div style={{ textAlign: "center" }} aria-live="polite">
          <time dateTime={day}>{dateTitle(day, language)}</time>
          <p className="sleep-caption">{night ? sleepDuration(night.asleep_minutes, en) : gap}</p>
        </div>
        <IconButton icon="arrow" className="date-step" label={en ? "Next day" : "后一天"}
          disabled={day >= today} onClick={() => select(nextDay)}/>
      </div>
      <div className="sleep-bars" style={{ gridTemplateColumns: `repeat(${windowDays}, minmax(0, 1fr))` }}>
        {trend.slots.map(({ day: date, night: item }) => <button key={date} type="button" className={item ? "has-night" : "empty-night"}
          aria-label={dateTitle(date, language) + " · " + (item ? sleepDuration(item.asleep_minutes, en) : gap)}
          aria-current={date === day ? "date" : undefined} title={dateTitle(date, language) + " · " + (item ? sleepDuration(item.asleep_minutes, en) : gap)}
          onClick={() => select(date)}>
          <span style={{ height: item ? `${item.asleep_minutes * 100 / chartScale}%` : "3px" }}/>
        </button>)}
      </div>
      <div className="sleep-axis"><span>{compactDay(trend.slots[0].day)}</span><span>{compactDay(day)}</span></div>
      <p className="sleep-caption" role={readFailed ? "status" : undefined}>{chartNote}</p>
    </section>
    {view.sync && <SleepSyncStatus sync={view.sync} today={today}/>}
    {daily && <section className="card padded sleep-report">
      <CardHead title={en ? "Muse nightly analysis" : "Muse 当晚分析"} icon="sparkle"/>
      <p>{daily.summary}</p>
      <strong>{daily.advice}</strong>
    </section>}
    {(weekly || view.status === "demo") && <section className="card padded sleep-report">
      <CardHead title={en ? "Muse weekly report" : "Muse 睡眠周报"} icon="sparkle"/>
      {weekly ? <>
        <p className="sleep-caption">{dateTitle(weekly.day, language)}{weekly.coverage_days === null ? "" :
          (en ? ` · ${weekly.coverage_days}/7 nights` : ` · ${weekly.coverage_days}/7 晚`)}</p>
        <p>{weekly.summary}</p>
        {weekly.trend_30 && <p>{weekly.trend_30}</p>}
        <strong>{weekly.advice}</strong>
      </> : <>
        <p>{en ? `Sample report · ${sampleWeek.count}/7 nights recorded` : `示例周报 · 记录 ${sampleWeek.count}/7 晚`}</p>
        {sampleMonth.average !== null && <p>{en ? "30-day average" : "30 天平均睡眠"} · {sleepDuration(sampleMonth.average, en)}</p>}
        <strong>{en ? "Try a consistent wake-up time." : "下一周可以先尝试固定一个起床时间。"}</strong>
      </>}
    </section>}
    {view.status === "ready" && !weekly && <p className="sleep-caption">
      {en ? "Muse weekly reports will appear here after the first upload." : "Muse 周报会在首次上传后显示在这里。"}
    </p>}
    <p className="sleep-caption">{en ? "Wearable estimates and suggestions are for routine tracking." : "穿戴设备的估算和建议仅用于日常作息参考。"}</p>
  </div>;
}
