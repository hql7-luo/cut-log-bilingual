"use client";

import { useMemo, useRef, useState, type KeyboardEvent, type MouseEvent } from "react";
import { compactDay, dayIndex, shiftDay, weekStart } from "../lib/dates";
import { MUSCLES, MUSCLE_LABELS, workoutMuscles, type LogRow, type Muscle, type StrengthDefinition,
  type StrengthMove, type StrengthSet } from "../lib/model";
import { number as formatNumber } from "../lib/nutrition";
import { LB_IN_KG, definitionKey, dualWeight, loadNames, sameLoad, sessionVolume, setKg,
  strengthEntries, workingSets, type StrengthEntry } from "../lib/strength";
import { useLanguage } from "./language";
import { Button, CardHead, Empty, Field, Icon, IconButton } from "./ui";

const ranges = [30, 90, "all"] as const;
type Range = typeof ranges[number];
type View = "performance" | "volume" | "frequency";
type Window = { start: string; end: string };
type LoggedSet = { move: StrengthMove; set: StrengthSet; kg: number | null };
type Session = { id: string; day: string; entries: StrengthEntry[]; sets: LoggedSet[] };
type PlotPoint = { id: string; day: string; value: number; label: string; through?: string; detail?: string };

// Keep each equipment setup independent, including records imported with a reused ID.
function exerciseKey(move: StrengthDefinition) {
  return JSON.stringify([move.mode === "unknown" ? "unknown" : move.exerciseId, definitionKey(move)]);
}

function workoutSessions(entries: StrengthEntry[]): Session[] {
  const sessions = new Map<string, Session>();
  for (const entry of entries) {
    const { workoutId, day, move } = entry;
    let session = sessions.get(workoutId);
    if (!session) {
      session = { id: workoutId, day, entries: [], sets: [] };
      sessions.set(workoutId, session);
    }
    session.entries.push(entry);
    for (const set of workingSets(move)) session.sets.push({ move, set, kg: setKg(move, set) });
  }
  return [...sessions.values()];
}

// Select a working set by the plotted measure. Fewer pounds of assistance is the stronger set.
function bestSet(sets: LoggedSet[], byReps: boolean) {
  let best: LoggedSet | undefined;
  for (const entry of sets) {
    if (byReps) {
      if (!best || entry.set.reps > best.set.reps) best = entry;
      continue;
    }
    if (entry.kg === null) continue;
    const prior = best?.kg ?? null;
    const tied = prior !== null && sameLoad(entry.kg, prior);
    const moreChallenging = prior !== null && (entry.move.mode === "assisted" ? entry.kg < prior : entry.kg > prior);
    if (!best || (tied ? entry.set.reps > best.set.reps : moreChallenging)) best = entry;
  }
  return best;
}

function atLoad(sets: LoggedSet[], kg: number) {
  return sets.filter((entry) => entry.kg !== null && sameLoad(entry.kg, kg));
}

// Match the latest session to the most recent session with a common load or rep count.
function matchingSession(latest: Session, earlier: Session[], bodyweight: boolean) {
  for (const session of earlier) {
    if (bodyweight) {
      const current = bestSet(latest.sets, true);
      const previous = bestSet(session.sets, true);
      if (current && previous) return { session, current, previous, basis: "bodyweight" as const };
      continue;
    }
    const sharedLoad = bestSet(latest.sets.filter(({ kg }) => kg !== null &&
      session.sets.some(({ kg: previous }) => previous !== null && sameLoad(previous, kg))), false)?.kg;
    if (sharedLoad != null) {
      const candidates = atLoad(latest.sets, sharedLoad).filter(({ kg }) => kg !== null && atLoad(session.sets, kg).length > 0);
      const current = bestSet(candidates, true);
      const previous = current?.kg == null ? undefined : bestSet(atLoad(session.sets, current.kg), true);
      if (current && previous) return { session, current, previous, basis: "load" as const };
    }
    const recordedReps = new Set(session.sets.filter(({ kg }) => kg !== null).map(({ set }) => set.reps));
    const reps = Math.max(0, ...latest.sets.filter(({ kg, set }) => kg !== null && recordedReps.has(set.reps)).map(({ set }) => set.reps));
    if (!reps) continue;
    const current = bestSet(latest.sets.filter(({ set }) => set.reps === reps), false);
    const previous = bestSet(session.sets.filter(({ set }) => set.reps === reps), false);
    if (current && previous) return { session, current, previous, basis: "reps" as const };
  }
}

function setLabel({ move, set, kg }: LoggedSet, en: boolean, total = false) {
  const reps = `${set.reps} ${en ? "reps" : "次"}`;
  if (move.mode === "bodyweight") return reps;
  if (set.weight === null) return `${en ? "Load unrecorded" : "未记重量"} · ${reps}`;
  let weight = dualWeight(set.weight, set.unit);
  if (move.mode === "plates") {
    if (total && kg !== null) {
      const converted = set.unit === "kg" ? kg : kg / LB_IN_KG;
      weight = `${dualWeight(Math.round(converted * 100) / 100, set.unit)} ${en ? "total" : "总重"}`;
    } else weight += en ? " plates" : " 片重";
  } else if (move.mode === "assisted") weight += en ? " assist" : " 辅助";
  return `${weight} × ${reps}`;
}

// Give points a true calendar position and retain a full date for inspection.
function pointDate(point: PlotPoint) {
  return point.through && point.through !== point.day ? `${point.day} – ${point.through}` : point.day;
}

function PlotData({ points, en }: { points: PlotPoint[]; en: boolean }) {
  const [limit, show] = useState(16);
  return <details className="strength-disclosure">
    <summary>{en ? "Chart data" : "图表数据"} <small>{points.length}</small></summary>
    <ul className="strength-data-list">{points.slice(-limit).reverse().map((point) => <li key={point.id}>
      <span>{pointDate(point)}</span><strong>{point.label}</strong>
      {point.detail && <small>{point.detail}</small>}
    </li>)}</ul>
    {points.length > limit && <Button className="strength-more" variant="quiet" onClick={() => show(limit + 20)}>
      {en ? "Show more" : "显示更多"}
    </Button>}
  </details>;
}

function MetricPlot({ label, unit, points, window, en, bars = false, integer = false, dataList = true }: {
  label: string; unit: string; points: PlotPoint[]; window: Window; en: boolean;
  bars?: boolean; integer?: boolean; dataList?: boolean;
}) {
  const track = useRef<HTMLDivElement>(null);
  const [selection, select] = useState("");
  const active = points.find((point) => point.id === selection) ?? points.at(-1);
  if (!active) return null;
  const activeIndex = points.indexOf(active);
  const minimum = points.reduce((value, point) => Math.min(value, point.value), active.value);
  const maximum = points.reduce((value, point) => Math.max(value, point.value), active.value);
  const margin = Math.max(integer ? 1 : 0.5, (maximum - minimum) * 0.1);
  const lower = bars ? 0 : Math.max(0, minimum - margin);
  const upper = bars ? maximum : maximum + margin;
  const step = Math.max(integer ? 1 : 0.1, (upper - lower) / 2);
  const n = Math.pow(10, Math.floor(Math.log10(step)));
  const roundedStep = Math.ceil(step / n) * n;
  const base = bars ? 0 : Math.max(0, Math.floor(lower / roundedStep) * roundedStep);
  const ceiling = Math.max(base + roundedStep * 2, Math.ceil(upper / roundedStep) * roundedStep);
  const middle = (ceiling + base) / 2;
  const ticks = [ceiling, integer ? Math.round(middle) : middle, base];
  const tickWidth = Math.max(...ticks.map((value) => formatNumber.format(value).length));
  const days = dayIndex(window.end) - dayIndex(window.start);
  const x = (day: string) => days ? 100 * (dayIndex(day) - dayIndex(window.start)) / days : 50;
  const y = (value: number) => 100 * (ceiling - value) / (ceiling - base);
  const dates = days > 1 ? [window.start, shiftDay(window.start, Math.floor(days / 2)), window.end]
    : days ? [window.start, window.end] : [window.end];
  const multiYear = window.start.slice(0, 4) !== window.end.slice(0, 4);

  function showPoint(index: number, focus = false) {
    const point = points[index];
    if (!point) return;
    select(point.id);
    if (focus) track.current?.querySelector<HTMLButtonElement>(`button[data-index="${index}"]`)?.focus({ preventScroll: true });
  }

  function movePoint(event: KeyboardEvent<HTMLButtonElement>, index: number) {
    const next = { ArrowLeft: index - 1, ArrowRight: index + 1, Home: 0, End: points.length - 1 }[event.key];
    if (next === undefined) return;
    event.preventDefault();
    showPoint(Math.max(0, Math.min(points.length - 1, next)), true);
  }

  // A tap selects the nearest mark even when 44px hit targets overlap.
  function tapPoint(event: MouseEvent<HTMLDivElement>) {
    if (!event.detail || !track.current) return;
    const rect = track.current.getBoundingClientRect();
    let nearest = 0;
    let distance = Infinity;
    for (const [index, point] of points.entries()) {
      const dx = rect.left + rect.width * x(point.day) / 100 - event.clientX;
      const top = rect.top + rect.height * y(point.value) / 100;
      const closestY = bars ? Math.max(top, Math.min(rect.bottom, event.clientY)) : top;
      const dy = closestY - event.clientY;
      const at = dx ** 2 + dy ** 2;
      if (at < distance || (at === distance && index === activeIndex)) { nearest = index; distance = at; }
    }
    showPoint(nearest, true);
  }

  return <div className="strength-figure">
    <div className="strength-figure-head"><h3>{label}</h3><small>{unit}</small></div>
    <div className="strength-plot-grid">
      <div className="strength-plot-y" style={{ minWidth: `${tickWidth}ch` }} aria-hidden="true">{ticks.map((value) =>
        <span key={value} style={{ top: `${y(value)}%` }}>{formatNumber.format(value)}</span>)}</div>
      <div ref={track} className="strength-plot-track" role="group" aria-label={label} onClick={tapPoint}>
        {ticks.map((value) => <span key={value} className="strength-plot-guide" aria-hidden="true" style={{ top: `${y(value)}%` }}/>) }
        {bars && points.map((point) => <span key={point.id} className="strength-plot-bar" aria-hidden="true"
          data-active={point.id === active.id} style={{ left: `${x(point.day)}%`, height: `${100 - y(point.value)}%`,
            width: `${Math.max(2, Math.min(12, 160 / points.length))}px` }}/>) }
        {points.map((point, index) => <button key={point.id} data-index={index} type="button"
          className={`strength-plot-point${bars ? " strength-bar-point" : ""}`}
          style={{ left: `${x(point.day)}%`, top: `${y(point.value)}%` }}
          aria-current={point.id === active.id ? "true" : undefined} tabIndex={point.id === active.id ? 0 : -1}
          aria-label={`${pointDate(point)}, ${point.label}`} onKeyDown={(event) => movePoint(event, index)}
          onFocus={() => select(point.id)} onClick={(event) => { if (!event.detail) select(point.id); }}><span/></button>)}
      </div>
      <div className={`strength-plot-dates${multiYear ? " strength-plot-years" : ""}`} aria-hidden="true">
        {dates.map((date, index) => <span key={date} data-align={!days ? "middle" : index === 0 ? "start" : date === window.end ? "end" : "middle"}
          style={{ left: `${x(date)}%` }}>{multiYear ? date : compactDay(date)}</span>)}
      </div>
    </div>
    <div className="strength-readout" data-multiple={points.length > 1}>
      {points.length > 1 && <IconButton className="strength-step strength-back" icon="arrow"
        label={en ? "Previous data point" : "上一个数据点"} disabled={activeIndex === 0} onClick={() => showPoint(activeIndex - 1)}/>}
      <div aria-live="polite"><span>{pointDate(active)}</span><strong>{active.label}</strong>{active.detail && <small>{active.detail}</small>}</div>
      {points.length > 1 && <IconButton className="strength-step" icon="arrow"
        label={en ? "Next data point" : "下一个数据点"} disabled={activeIndex === points.length - 1} onClick={() => showPoint(activeIndex + 1)}/>}
    </div>
    {dataList && <PlotData points={points} en={en}/>}
  </div>;
}

// Preserve original units, warm-ups, equipment details and set notes in the history.
function SetList({ session, en }: { session: Session; en: boolean }) {
  return <div className="strength-set-list">{session.entries.map(({ id, move }) => <div key={id}>
    {move.mode === "plates" && move.bar && <p className="fine">{en ? "Bar" : "杠铃杆"} {dualWeight(move.bar.weight, move.bar.unit)}</p>}
    <ol>{move.sets.map((set, index) => <li key={index}>
      <strong>{setLabel({ move, set, kg: null }, en)}</strong>
      {set.warmup && <small>{en ? "Warm-up" : "热身"}</small>}{set.note && <p>{set.note}</p>}
    </li>)}</ol>
  </div>)}</div>;
}

function SessionHistory({ sessions, summaries, fixed, open, en }: {
  sessions: Session[]; summaries: Map<string, LoggedSet>; fixed: boolean; open: boolean; en: boolean;
}) {
  const [limit, show] = useState(12);
  return <details className="strength-disclosure" open={open || undefined}>
    <summary>{en ? "Training history" : "训练历史"} <small>{sessions.length}</small></summary>
    <div className="strength-session-list">{sessions.slice(0, limit).map((session) => {
      const sample = summaries.get(session.id);
      const unplotted = fixed ? (en ? "No set at this load" : "未记此重量") : session.sets.length
        ? `${session.sets.length} ${en ? (session.sets.length === 1 ? "work set" : "work sets") : "个工作组"}`
        : (en ? "No work sets" : "未记录工作组");
      return <details key={session.id}>
        <summary><time dateTime={session.day}>{session.day}</time>
          <span>{sample ? setLabel(sample, en, true) : unplotted}</span>
        </summary>
        <SetList session={session} en={en}/>
      </details>;
    })}</div>
    {sessions.length > limit && <Button className="strength-more" variant="quiet" onClick={() => show(limit + 20)}>
      {en ? "Show more" : "显示更多"}
    </Button>}
  </details>;
}

function Comparison({ sessions, bodyweight, assisted, en }: { sessions: Session[]; bodyweight: boolean; assisted: boolean; en: boolean }) {
  const [latest, ...earlier] = sessions;
  if (!latest) return null;
  const match = matchingSession(latest, earlier, bodyweight);
  const current = match?.current ?? bestSet(latest.sets, bodyweight) ?? latest.sets[0];
  const basis = match?.basis === "bodyweight" ? (en ? "Best bodyweight sets" : "自重最佳组")
    : match?.basis === "load" ? (assisted ? (en ? "Same assistance" : "同辅助重量") : (en ? "Same load" : "同重量"))
      : match?.basis === "reps" ? (en ? "Same reps" : "同次数") : null;
  return <div className="strength-compare">
    <dl>
      <div><dt>{en ? "Latest session" : "最近一次"}</dt>
        <dd><time dateTime={latest.day}>{latest.day}</time></dd>
        <dd className="strength-compare-value">{current ? setLabel(current, en, true) : (en ? "No work sets" : "未记录工作组")}</dd></div>
      <div><dt>{en ? "Previous match" : "上次可比训练"}</dt>
        {match ? <><dd><time dateTime={match.session.day}>{match.session.day}</time></dd>
          <dd className="strength-compare-value">{setLabel(match.previous, en, true)}</dd></>
          : <dd>{en ? "None in this range" : "此范围内暂无"}</dd>}</div>
    </dl>
    {basis && <p className="fine">{basis}</p>}
    {match && <details className="strength-disclosure strength-paired">
      <summary>{en ? "Sets from both sessions" : "查看两次的逐组记录"}</summary>
      <div className="strength-pair-lists">
        <div><p className="fine">{en ? "Latest session" : "最近一次"}</p><SetList session={latest} en={en}/></div>
        <div><p className="fine">{en ? "Previous match" : "上次可比训练"}</p><SetList session={match.session} en={en}/></div>
      </div>
    </details>}
  </div>;
}

function Performance({ choice, sessions, window, openHistory, en }: {
  choice: StrengthDefinition; sessions: Session[]; window: Window; openHistory: boolean; en: boolean;
}) {
  const [metric, setMetric] = useState<"load" | "reps">("load");
  const [selectedLoad, setLoad] = useState("");
  const bodyweight = choice.mode === "bodyweight";
  const assisted = choice.mode === "assisted";
  const legacy = choice.mode === "unknown";
  const loadChoices: LoggedSet[] = [];
  for (const session of sessions) {
    for (const sample of session.sets) {
      const kg = sample.kg;
      if (kg !== null && !loadChoices.some((option) => sameLoad(option.kg!, kg))) loadChoices.push(sample);
    }
  }
  const fixed = metric === "reps" && !bodyweight && loadChoices.length > 0;
  const fixedLoad = loadChoices.find(({ kg }) => String(kg) === selectedLoad) ?? loadChoices[0];
  const bestBySession = new Map<string, LoggedSet>();
  const points: PlotPoint[] = [];
  let record: { sample: LoggedSet; day: string } | undefined;
  const reps = bodyweight || fixed;
  const visible = sessions.filter(({ day }) => day >= window.start);
  for (const session of [...sessions].reverse()) {
    const samples = fixed && fixedLoad?.kg != null ? atLoad(session.sets, fixedLoad.kg) : session.sets;
    const sample = bestSet(samples, reps);
    if (!sample) continue;
    bestBySession.set(session.id, sample);
    if (!record || bestSet([record.sample, sample], reps) === sample) record = { sample, day: session.day };
    if (session.day < window.start) continue;
    const value = reps ? sample.set.reps : sample.kg;
    if (value !== null) points.push({ id: session.id, day: session.day, value, label: setLabel(sample, en, true),
      detail: sample.move.mode === "plates" ? setLabel(sample, en) : undefined });
  }
  const title = reps ? (en ? "Best reps in a set" : "单组最高次数")
    : assisted ? (en ? "Lowest assistance" : "最少辅助重量") : (en ? "Heaviest work set" : "最重工作组");
  const plotUnit = reps ? (en ? "reps" : "次") : "kg";

  return <>
    {!bodyweight && !legacy && loadChoices.length > 0 && <div className="strength-metrics">
      <div className="segments" role="group" aria-label={en ? "Performance metric" : "表现指标"}>
        <button type="button" aria-pressed={!fixed} onClick={() => setMetric("load")}>
          {assisted ? (en ? "Assistance" : "辅助重量") : (en ? "Load" : "负重")}</button>
        <button type="button" aria-pressed={fixed} onClick={() => setMetric("reps")}>
          {en ? "Fixed-load reps" : "固定重量次数"}</button>
      </div>
      {fixed && <Field label={assisted ? (en ? "Assistance load" : "选择辅助重量") : (en ? "Fixed load" : "选择固定重量")}>
        <select value={String(fixedLoad.kg)} onChange={(event) => setLoad(event.target.value)}>
          {loadChoices.sort((a, b) => a.kg! - b.kg!).map(({ move, set, kg }) => {
            const load = move.mode === "plates" && kg !== null ? dualWeight(Math.round(kg * 100) / 100, "kg") : dualWeight(set.weight, set.unit);
            return <option key={kg} value={String(kg)}>{load}</option>;
          })}
        </select>
      </Field>}
    </div>}
    <Comparison sessions={visible} bodyweight={bodyweight} assisted={assisted} en={en}/>
    {points.length ? <MetricPlot key={fixed ? `reps:${fixedLoad?.kg}` : "main"} label={title} unit={plotUnit} points={points}
      window={window} integer={reps} en={en} dataList={false}/> :
      <p className="strength-empty">{legacy ? (en ? "This older log has no equipment setup. Its sets are available in training history." : "旧记录的器械口径未知。可在训练历史查看每组数据。")
        : (en ? "No comparable work sets in this date range." : "这段时间暂无可比工作组。")}</p>}
    {record && <div className="strength-record"><Icon name="star" size={17}/><div>
      <span>{en ? "All-time best" : "历史最佳"}</span><strong>{setLabel(record.sample, en, true)}</strong>
    </div><time dateTime={record.day}>{record.day}</time></div>}
    {visible.length > 0 && <SessionHistory sessions={visible} summaries={bestBySession} fixed={fixed} open={openHistory} en={en}/>}
  </>;
}

function weekPeriod(day: string, window: Window) {
  const first = weekStart(day);
  const last = shiftDay(first, 6);
  return { day: first < window.start ? window.start : first, through: last > window.end ? window.end : last };
}

function Volume({ rows, history, window, en }: { rows: LogRow<"workout">[]; history: StrengthEntry[]; window: Window; en: boolean }) {
  const [weekly, setWeekly] = useState(false);
  const datedHistory = history.filter(({ day }) => day >= window.start);
  const sessions = workoutSessions(datedHistory);
  const byWorkout = new Map(sessions.map((session) => [session.id, session]));
  const withSets = datedHistory.filter(({ move }) => workingSets(move).length > 0);
  const fingerprints = new Set(withSets.map(({ move }) => exerciseKey(move)));
  const loadVolume = fingerprints.size === 1 && withSets.some(({ move }) => sessionVolume(move) !== null);
  const unit = loadVolume ? (en ? "kg × reps" : "kg × 次") : (en ? "work sets" : "个工作组");
  const groups = new Map<string, PlotPoint>();
  const unknownWeeks = new Set<string>();
  let missing = 0;
  for (const { id, payload } of rows) {
    if (payload.day < window.start) continue;
    const session = byWorkout.get(id);
    const dates = weekly ? weekPeriod(payload.day, window) : { day: payload.day };
    const key = weekly ? dates.day : id;
    const loads = loadVolume ? session?.entries.filter(({ move }) => workingSets(move).length > 0).map(({ move }) => sessionVolume(move)) : undefined;
    const value = loadVolume ? (loads?.length && loads.every((load) => load !== null) ? loads.reduce((sum, load) => sum + load, 0) : null)
      : session?.sets.length || null;
    if (value === null) {
      missing += 1;
      if (weekly && loadVolume) unknownWeeks.add(key);
      continue;
    }
    const sum = (groups.get(key)?.value ?? 0) + value;
    groups.set(key, { id: key, ...dates, value: sum, label: `${formatNumber.format(sum)} ${unit}` });
  }
  const points = [...groups.values()].filter(({ id }) => !unknownWeeks.has(id)).reverse();
  const title = loadVolume ? (en ? "Load volume" : "负重训练量") : (en ? "Recorded work sets" : "已记录工作组");
  return <>
    <div className="segments" role="group" aria-label={en ? "Volume interval" : "训练量统计周期"}>
      <button type="button" aria-pressed={!weekly} onClick={() => setWeekly(false)}>{en ? "Per session" : "按次"}</button>
      <button type="button" aria-pressed={weekly} onClick={() => setWeekly(true)}>{en ? "Per week" : "按周"}</button>
    </div>
    {points.length ? <MetricPlot key={weekly ? "weekly" : "session"} label={title} unit={unit} points={points} window={window}
      en={en} integer={!loadVolume} bars/> :
      <p className="strength-empty">{en ? "No measured volume in this date range." : "这段时间暂无可绘制的训练量。"}</p>}
    {weekly && <p className="fine">{en ? "Weeks start on Monday. Values cover the selected dates." : "以周一为每周起点，统计所选日期内的记录。"}</p>}
    {missing > 0 && <p className="fine">{en ? `${missing} ${missing === 1 ? "session has" : "sessions have"} no ${loadVolume ? "complete working loads" : "recorded work sets"}.`
      : `${missing} 次训练未记录${loadVolume ? "完整的工作组负重" : "工作组"}。`}
      {weekly && loadVolume && (en ? " Those weeks have gaps in the chart." : " 涉及的周在图中留空。")}</p>}
  </>;
}

function Frequency({ rows, muscle, window, en }: { rows: LogRow<"workout">[]; muscle: Muscle | ""; window: Window; en: boolean }) {
  const { t } = useLanguage();
  const daysByMuscle = new Map<Muscle, Set<string>>(MUSCLES.map((name) => [name, new Set<string>()]));
  const weeks = new Map<string, Set<string>>();
  for (const { payload } of rows) {
    if (payload.day < window.start) continue;
    const muscles = workoutMuscles(payload);
    for (const name of muscles) daysByMuscle.get(name)?.add(payload.day);
    if (muscle && !muscles.includes(muscle)) continue;
    const week = weekStart(payload.day);
    const days = weeks.get(week) ?? new Set<string>();
    days.add(payload.day);
    weeks.set(week, days);
  }
  const unit = en ? "days" : "天";
  const points = [...weeks.entries()].reverse().map(([week, days]) => ({ id: week, ...weekPeriod(week, window), value: days.size,
    label: `${days.size} ${en && days.size === 1 ? "day" : unit}`,
    detail: [...days].sort().map(compactDay).join(" · ") }));
  return <>
    <dl className="strength-frequency" data-single={Boolean(muscle)}>{(muscle ? [muscle] : MUSCLES).map((name) => {
      const count = daysByMuscle.get(name)?.size;
      return <div key={name}><dt>{t(MUSCLE_LABELS[name])}</dt>
        <dd>{count ? <>{count} <small>{en && count === 1 ? "day" : unit}</small></> : "—"}</dd></div>;
    })}</dl>
    {points.length ? <MetricPlot label={en ? "Weekly training days" : "每周训练天数"} unit={unit} points={points}
      window={window} integer bars en={en}/> :
      <p className="strength-empty">{en ? "No recorded training days in this date range." : "这段时间暂无训练日记录。"}</p>}
    <p className="fine">{en ? "Multiple workouts on the same date count as one day. Weeks start on Monday."
      : "同一日期的多次训练计为一天。每周从周一开始。"}</p>
  </>;
}

type InsightsProps = { rows: LogRow<"workout">[]; today: string; focus?: string; favorites: LogRow<"strength_exercise">[] };

function InsightsCard({ rows, today, focus, favorites }: InsightsProps) {
  const { language, t } = useLanguage();
  const en = language === "en";
  const [range, setRange] = useState<Range>(focus ? "all" : 30);
  const [muscle, setMuscle] = useState<Muscle | "">("");
  const [selected, select] = useState("");
  const [view, setView] = useState<View>();
  const [volumeAll, setVolumeAll] = useState(!focus);
  const workouts = useMemo(() => rows.filter(({ payload }) => payload.kind === "strength" && payload.day <= today)
    .sort((a, b) => b.payload.day.localeCompare(a.payload.day) || b.payload.time - a.payload.time), [rows, today]);
  const entries = useMemo(() => strengthEntries(workouts), [workouts]);
  const choices = useMemo(() => {
    const byKey = new Map<string, StrengthDefinition>();
    for (const { move } of entries) {
      const key = exerciseKey(move);
      if (!byKey.has(key)) byKey.set(key, move);
    }
    for (const { payload } of favorites) {
      const key = exerciseKey(payload);
      if (!byKey.has(key)) byKey.set(key, payload);
    }
    return [...byKey.entries()];
  }, [entries, favorites]);
  const comparable = useMemo(() => new Set(entries.filter(({ move }) => workingSets(move)
    .some((set) => (move.mode === "bodyweight" || setKg(move, set) !== null))).map(({ move }) => exerciseKey(move))), [entries]);
  const filtered = choices.filter(([, choice]) => !muscle || choice.muscle === muscle);
  const focusedMove = focus ? entries.find(({ move }) => move.exerciseId === focus)?.move : undefined;
  const focusedKey = focusedMove ? exerciseKey(focusedMove) : undefined;
  const selectedEntry = filtered.find(([key]) => key === selected)
    ?? (focus ? filtered.find(([key, choice]) => choice.exerciseId === focus || key === focusedKey) : undefined)
    ?? filtered.find(([key]) => comparable.has(key)) ?? filtered[0];
  const activeView = view ?? (choices.length ? "performance" : "frequency");
  const anyExercise = activeView === "volume" && (volumeAll || !selectedEntry);
  const scopedHistory = entries.filter(({ move }) => (!muscle || move.muscle === muscle) && (anyExercise || exerciseKey(move) === selectedEntry?.[0]));
  const scopedIds = new Set(scopedHistory.map(({ workoutId }) => workoutId));
  const scopedWorkouts = workouts.filter(({ id, payload }) => anyExercise
    ? !muscle || workoutMuscles(payload).includes(muscle) : scopedIds.has(id));
  const frequencyStart = workouts.findLast(({ payload }) => !muscle || workoutMuscles(payload).includes(muscle))?.payload.day;
  const oldest = activeView === "frequency" ? frequencyStart : scopedWorkouts.at(-1)?.payload.day;
  const window = { start: range === "all" ? oldest ?? today : shiftDay(today, 1 - range), end: today };
  const tabs = { performance: en ? "Performance" : "表现", volume: en ? "Volume" : "训练量", frequency: en ? "Frequency" : "频率" };
  const optionLabel = (choice: StrengthDefinition) => [t(choice.name), choice.variant, loadNames[choice.mode][en ? 1 : 0],
    choice.mode === "dumbbell" ? (choice.dumbbells === 1 ? (en ? "1 dumbbell" : "单只") : (en ? "2 dumbbells" : "双只")) : "",
    t(MUSCLE_LABELS[choice.muscle])].filter(Boolean).join(" · ");

  return <section id="strength-insights" className="card padded strength-insights">
    <CardHead title={en ? "Strength trends" : "力量趋势"} icon="chart"/>
    {!workouts.length && !choices.length ? <Empty icon="lift" title={en ? "Record a strength workout to see your trends." : "记录力量训练后，可查看表现、训练量和频率。"}/> : <>
      <div className="segments strength-tabs" role="group" aria-label={en ? "Strength trend view" : "力量趋势视图"}>
        {(Object.keys(tabs) as View[]).map((tab) => <button key={tab} type="button" aria-pressed={activeView === tab} onClick={() => setView(tab)}>{tabs[tab]}</button>)}
      </div>
      <div className="strength-filter-row">
        <Field label={en ? "Muscle group" : "肌群"}><select value={muscle} onChange={(event) => setMuscle(event.target.value as Muscle | "")}>
          <option value="">{en ? "All muscles" : "全部肌群"}</option>
          {MUSCLES.map((name) => <option key={name} value={name}>{t(MUSCLE_LABELS[name])}</option>)}
        </select></Field>
        {activeView !== "frequency" && <Field label={en ? "Exercise" : "动作"}>
          <select value={anyExercise ? "" : selectedEntry?.[0] ?? ""} disabled={activeView === "performance" && !filtered.length}
            title={!anyExercise && selectedEntry ? optionLabel(selectedEntry[1]) : undefined} onChange={(event) => {
              const value = event.target.value;
              setVolumeAll(!value);
              if (value) select(value);
            }}>
            {activeView === "volume" && <option value="">{en ? "All exercises" : "全部动作"}</option>}
            {activeView === "performance" && !filtered.length && <option value="">{en ? "No exercises" : "暂无动作"}</option>}
            {filtered.map(([key, choice]) => <option key={key} value={key}>{optionLabel(choice)}</option>)}
          </select>
        </Field>}
      </div>
      <div className="segments strength-ranges" role="group" aria-label={en ? "Date range" : "日期范围"}>
        {ranges.map((value) => <button key={value} type="button" aria-pressed={range === value} onClick={() => setRange(value)}>
          {value === "all" ? (en ? "All time" : "全部时间") : `${value} ${en ? "days" : "天"}`}</button>)}
      </div>
      <div className="strength-view">
        {activeView === "performance" && (selectedEntry ? <Performance key={selectedEntry[0]} choice={selectedEntry[1]}
          sessions={workoutSessions(scopedHistory)} window={window}
          openHistory={selectedEntry[1].exerciseId === focus || selectedEntry[0] === focusedKey} en={en}/> :
          <p className="strength-empty">{en ? "Exercises for this muscle group will appear here after you log them." : "记录这个肌群的动作后，可在这里查看表现。"}</p>)}
        {activeView === "volume" && <Volume rows={scopedWorkouts} history={scopedHistory} window={window} en={en}/>}
        {activeView === "frequency" && <Frequency rows={workouts} muscle={muscle} window={window} en={en}/>}
        {range !== "all" && oldest && oldest < window.start && <Button className="strength-more strength-all" variant="quiet" onClick={() => setRange("all")}>
          {en ? "View all dates" : "查看所有日期"}
        </Button>}
      </div>
    </>}
  </section>;
}

export function StrengthInsights(props: InsightsProps) {
  return <InsightsCard key={props.focus ?? ""} {...props}/>;
}
