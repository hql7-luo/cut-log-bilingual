"use client";

import { LanguageProvider, useLanguage } from "./language";
import { useEffect, useMemo, useRef, useState } from "react";
import { calendarStats, type CalendarDayStats } from "../lib/calendar";
import { compactDay, dateTitle, isDay, shiftDay } from "../lib/dates";
import { downloadCsv } from "../lib/export";
import { DEFAULT_PROFILE, makeId, recordsOf, type Activity, type Change,
  type FoodDraft, type LogRow, type Meal, type Profile, type Row } from "../lib/model";
import { foodTotals, normalize, sum, whole } from "../lib/nutrition";
import { CLOUD_ENABLED } from "../lib/public-config";
import { strengthEntries } from "../lib/strength";
import { pullSleepExport } from "../lib/supabase";
import { useCloudAuth, useToday, useTracker } from "../lib/use-tracker";
import { Dashboard, FoodList } from "./dashboard";
import { CalendarPage, MonthDatePicker } from "./calendar";
import { FoodModal, type Providers } from "./food-modal";
import { ProgressPage, WeightModal } from "./progress";
import { SettingsPage, type Theme } from "./settings";
import { SleepOverview, SleepPage } from "./sleep";
import { useSleep } from "../lib/use-sleep";
import { TrainingPage, WorkoutModal } from "./training";
import { Button, CardHead, Empty, Icon, IconButton, type IconName } from "./ui";

const nav = [
  { id: "today", label: "总览", title: "今日总览", icon: "home" },
  { id: "food", label: "饮食", title: "饮食记录", icon: "food" },
  { id: "sleep", label: "睡眠", title: "睡眠管理", icon: "moon" },
  { id: "training", label: "训练", title: "训练记录", icon: "lift" },
  { id: "progress", label: "进度", title: "减脂进度", icon: "chart" },
  { id: "calendar", label: "日历", title: "热量日历", icon: "calendar" },
  { id: "settings", label: "设置", title: "个人设置", icon: "settings" },
] as const satisfies { id: string; label: string; title: string; icon: IconName }[];
type Page = typeof nav[number]["id"];
const offline: Providers = { ai: false, usda: false, vision: false };

type FoodDialog = { kind: "food"; day: string; meal?: Meal; items?: FoodDraft[]; keepDay?: boolean; row?: LogRow<"food"> };
type Dialog = FoodDialog
  | { kind: "training"; day?: string; row?: LogRow<"workout"> }
  | { kind: "weight"; day?: string; row?: LogRow<"weight"> } | { kind: "date-picker" };

function mountName() {
  const hash = window.location.hash.slice(1);
  return nav.find(({ id }) => id === hash)?.id ?? "today";
}

function Brand() {
  return <a className="brand" href="#today" aria-label="日衡 · DayBaseline">
    <span className="brand-icon" aria-hidden="true"><i/></span><strong>日衡 <span>· DayBaseline</span></strong>
  </a>;
}

function LanguageSwitch() {
  const { language, setLanguage } = useLanguage();
  const next = language === "zh" ? "en" : "zh";
  return <button type="button" className="language-switch" aria-label={next === "en" ? "Switch to English" : "Switch to Chinese"}
    onClick={() => setLanguage(next)}><span lang={next === "en" ? "en" : "zh-CN"}>{next === "en" ? "English" : "中文"}</span></button>;
}

// Only the chosen day is rendered, regardless of how many dates have records.
function FoodHistory({ today, day, stats, onFoodComplete, rows, presets, open, edit, remove, copy, deletePreset, showToday }: {
  today: string; day: string; rows: LogRow<"food">[]; presets: LogRow<"food_preset">[];
  stats: CalendarDayStats; onFoodComplete: (complete: boolean) => void;
  open: (date: string) => void; edit: (row: LogRow<"food">) => void; remove: (row: LogRow<"food">) => void;
  copy: (meal: Meal, rows: LogRow<"food">[]) => void; deletePreset: (row: LogRow<"food_preset">) => void; showToday: () => void;
}) {
  const { language, t } = useLanguage();
  const label = day === today ? t("今天") : day === shiftDay(today, -1) ? t("昨天") : compactDay(day);
  const entries = rows.filter(({ payload }) => payload.day === day);
  const total = sum(entries.flatMap(({ payload }) => foodTotals(payload)?.total ?? []));
  return <div className="subpage-grid">
    <section className="card padded">
      <CardHead title={t`${label}的饮食`} icon="bowl">
        {day !== today && <button type="button" className="text-link return-today" onClick={showToday}>{t("回到今天")}</button>}
      </CardHead>
      {entries.length ? <>
        <div className="history-totals"><strong>{whole.format(total.kcal)} kcal</strong>
          <span>{t("蛋白质")} {whole.format(total.protein)} {t("g · 碳水")} {whole.format(total.carbs)} {t("g · 脂肪")} {whole.format(total.fat)} g</span></div>
        <div className="inline-actions wrap food-day-review">
          <span className="fine">{stats.foodComplete
            ? language === "en" ? "Day marked complete" : "全天饮食已记全"
            : language === "en" ? "Logged intake so far" : "仅统计已记录摄入"}</span>
          {(stats.foodMarked || (stats.kcal !== null && stats.uncomputedFood === 0)) &&
            <button type="button" className="text-link" onClick={() => onFoodComplete(!stats.foodMarked)}>
              {stats.foodMarked ? language === "en" ? "Reopen day" : "取消记全"
                : language === "en" ? "Mark day complete" : "确认全天记全"}
            </button>}
        </div>
        <FoodList rows={entries} onEdit={edit} onDelete={remove} onCopy={day === today ? undefined : copy}/>
      </> : <Empty title={t("这一天还没有记录。")} icon="bowl"/>}
      <Button icon="plus" onClick={() => open(day)}>{t`添加到${label}`}</Button>
    </section>
    <section className="card padded">
      <CardHead title={t("常吃食物")} icon="star"/>
      {presets.length ? presets.map((preset) => <div key={preset.id} className="history-row">
        <span>{t(preset.payload.spec.name)}</span>
        <IconButton icon="trash" label={t`删除常吃 ${t(preset.payload.spec.name)}`} onClick={() => deletePreset(preset)}/>
      </div>) : <p className="muted">{t("编辑食物时可保存为常吃，之后快速添加。")}</p>}
    </section>
  </div>;
}

export default function TrackerApp() {
  return <LanguageProvider><Tracker/></LanguageProvider>;
}

function Tracker() {
  const { language, t } = useLanguage();
  const today = useToday();
  const auth = useCloudAuth();
  const store = useTracker(today, auth);
  const [page, setPage] = useState<Page>("today");
  const [recordDay, setRecordDay] = useState<string | null>(null);
  const [theme, setTheme] = useState<Theme>("light");
  const [dialog, setDialog] = useState<Dialog | null>(null);
  const [toast, setToast] = useState<{ text: string; undo?: Change[] } | null>(null);
  const [providerFlags, setProviderFlags] = useState<Providers>(offline);
  const [trainingFocus, setTrainingFocus] = useState<string>();
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Use the same date selection for the overview and both record pages.
  const datePickerMode = page === "today" ? "balance" : page === "food" || page === "training" ? page : null;
  const viewedDay = recordDay ?? today;
  const sleep = useSleep(auth, today, viewedDay, page === "today" || page === "sleep");
  const historicalOverview = page === "today" && viewedDay !== today;
  const pageTitle = historicalOverview ? t`${compactDay(viewedDay)} 总览` : page === "sleep" && language === "en" ? "Sleep" : t(nav.find(({ id }) => id === page)!.title);
  const selectDay = (day: string) => setRecordDay(day);

  // Step through calendar days and resume the live overview on today's date.
  function stepOverviewDay(offset: -1 | 1) {
    setRecordDay((selected) => {
      const next = shiftDay(selected ?? today, offset);
      return next >= today ? null : next;
    });
  }

  useEffect(() => {
    const change = () => {
      const destination = mountName();
      setPage(destination);
      if (destination !== "sleep") setRecordDay(null);
      setDialog((current) => current?.kind === "date-picker" ? null : current);
      window.scrollTo({ top: 0 });
    };
    change();
    window.addEventListener("hashchange", change);
    let appearance: Theme = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
    try {
      const saved = localStorage.getItem("cut-log:theme");
      if (saved === "light" || saved === "dark") appearance = saved;
    } catch { /* The device appearance remains available. */ }
    document.documentElement.dataset.theme = appearance;
    setTheme(appearance);
    return () => window.removeEventListener("hashchange", change);
  }, []);

  useEffect(() => {
    if (auth.ready) setPage(mountName());
  }, [auth.ready]);

  useEffect(() => {
    if (!CLOUD_ENABLED || !auth.session?.user.id) return;
    let active = true;
    fetch("/api/providers", { cache: "no-store" }).then((response) => response.ok ? response.json() : offline)
      .then((value) => { if (active) setProviderFlags(value); }).catch(() => {});
    return () => { active = false; };
  }, [auth.session?.user.id]);

  const scope = auth.session?.user.id ?? "guest";
  useEffect(() => { setDialog(null); setToast(null); setRecordDay(null); setTrainingFocus(undefined); }, [scope]);

  const themeChange = (next: Theme) => {
    setTheme(next);
    document.documentElement.dataset.theme = next;
    try { localStorage.setItem("cut-log:theme", next); } catch { }
  };

  function notify(text: string, undo?: Change[]) {
    if (timer.current) clearTimeout(timer.current);
    setToast({ text, undo });
    timer.current = setTimeout(() => setToast(null), undo ? 12_000 : 4500);
  }

  const openFood = (day = today, options?: Pick<FoodDialog, "meal" | "items" | "keepDay">) =>
    setDialog({ kind: "food", day, ...options });
  const addFoodOnDate = (day: string) => openFood(day, { keepDay: true });
  const editFood = (row: LogRow<"food">) => setDialog({
    kind: "food", row, day: row.payload.day, meal: row.payload.meal, items: [row.payload],
  });
  const addWorkout = (day = today) => setDialog({ kind: "training", day });
  const addWeight = () => setDialog({ kind: "weight", day: viewedDay });
  const editWorkout = (row: LogRow<"workout">) => setDialog({ kind: "training", row });
  const editWeight = (row: LogRow<"weight">) => setDialog({ kind: "weight", row });
  const close = () => setDialog(null);

  async function remove(row: Row) {
    try {
      await store.save([{ kind: row.kind, id: row.id, payload: null }]);
      notify("已删除记录。", [row]);
    } catch (error) { notify((error as Error).message); }
  }

  async function saveProfile(profile: Profile) {
    await store.save([{ kind: "profile", id: "personal", payload: profile }]);
    notify("已保存设置。");
  }

  async function changeActivity(activity: Activity | null) {
    try { await store.save([{ kind: "activity", id: viewedDay, payload: activity ? { day: viewedDay, activity } : null }]); }
    catch (error) { notify((error as Error).message); }
  }

  const foods = useMemo(() => recordsOf(store.rows, "food").sort((a, b) => b.payload.day.localeCompare(a.payload.day) || b.payload.time - a.payload.time), [store.rows]);
  const workouts = useMemo(() => recordsOf(store.rows, "workout"), [store.rows]);
  const workoutHistory = useMemo(() => strengthEntries(workouts, today), [workouts, today]);
  const strengthFavorites = useMemo(() => recordsOf(store.rows, "strength_exercise"), [store.rows]);
  const weights = useMemo(() => recordsOf(store.rows, "weight"), [store.rows]);
  const presets = useMemo(() => recordsOf(store.rows, "food_preset"), [store.rows]);
  const workoutPresets = useMemo(() => recordsOf(store.rows, "workout_preset"), [store.rows]);
  const manual = recordsOf(store.rows, "activity").some(({ id }) => id === viewedDay);
  const latest = [...weights].filter((row) => !row.sample).sort((a, b) => b.payload.day.localeCompare(a.payload.day))[0]?.payload.kg;
  const exampleProfile = useMemo(() => ({ ...DEFAULT_PROFILE, height: 175, weight: 75, goalWeight: 70,
    calories: { rest: 1900, strength: 2050, basketball: 2200, both: 2350 },
    protein: 140, fat: 60, goalDay: shiftDay(today, 84) }), [today]);
  const profile = recordsOf(store.rows, "profile")[0]?.payload ?? (auth.session ? DEFAULT_PROFILE : exampleProfile);
  const dayStats = useMemo(() => calendarStats(store.rows, profile, viewedDay, viewedDay, today).days[0],
    [store.rows, profile, viewedDay, today]);
  const hasSamples = store.rows.some((row) => row.sample);
  const session = auth.session;
  const providers = session ? providerFlags : offline;
  const status = !store.ready ? "载入中" : session ? store.problem ? "同步暂停" :
    Object.keys(store.snapshot.conflicts).length ? "待处理冲突" : store.snapshot.pending.length ? "待同步" :
      store.snapshot.pulled ? "已同步" : "连接云端" : hasSamples ? "示例数据" : "本机记录";

  // Take a snapshot of the day's targets only after the user confirms their log.
  async function markFoodComplete(complete: boolean) {
    if (complete && (dayStats.kcal === null || dayStats.uncomputedFood > 0 || dayStats.foodMarked)) return;
    const previous = recordsOf(store.rows, "food_day").find(({ id }) => id === viewedDay);
    const dayFoods = foods.filter(({ payload }) => payload.day === viewedDay);
    const payload = complete ? { day: viewedDay, target: dayStats.nutritionTarget } : null;
    try {
      await store.save([{ kind: "food_day", id: viewedDay, payload,
        sample: !session && dayFoods.length > 0 && dayFoods.every(({ sample }) => sample) }]);
      const message = complete ? (language === "en" ? "Day marked complete." : "已确认全天饮食记全。")
        : (language === "en" ? "Day reopened." : "已取消记全。");
      notify(message, [previous ?? { kind: "food_day", id: viewedDay, payload: null }]);
    } catch (error) { notify((error as Error).message); }
  }

  async function exportRecords() {
    if (!session) { downloadCsv(store.rows, today, language); return; }
    try {
      const access = await auth.token();
      downloadCsv(store.rows, today, language, await pullSleepExport(access));
    } catch {
      downloadCsv(store.rows, today, language);
      notify(language === "en" ? "Sleep could not be read. Other records were exported." : "睡眠暂时无法读取，其余记录已导出。");
    }
  }

  function viewExerciseHistory(exerciseId: string) {
    setTrainingFocus(exerciseId);
    close();
    requestAnimationFrame(() => document.getElementById("strength-insights")?.scrollIntoView({ block: "start" }));
  }

  return <div className="app-shell">
    <a href="#main" className="skip" onClick={(event) => {
      event.preventDefault();
      document.getElementById("main")?.focus();
    }}>{t("跳到内容")}</a>
    <aside className="sidebar">
      <Brand/>
      <nav aria-label={t("主导航")}>{nav.map(({ id, label, icon }) =>
        <a href={`#${id}`} key={id} aria-current={page === id ? "page" : undefined}><Icon name={icon}/><span>{id === "sleep" && language === "en" ? "Sleep" : t(label)}</span></a>)}</nav>
      <div className="sidebar-bottom">
        <LanguageSwitch/>
        <button type="button" className="sidebar-theme" onClick={() => themeChange(theme === "dark" ? "light" : "dark")}>
          <Icon name={theme === "dark" ? "sun" : "moon"} size={18}/>{theme === "dark" ? t("浅色模式") : t("深色模式")}
        </button>
      </div>
    </aside>
    <header className="mobile-bar"><Brand/>
      <div className="inline-actions">
        <LanguageSwitch/>
        <button type="button" className="icon-button" aria-label={theme === "dark" ? t("切换浅色") : t("切换深色")}
          onClick={() => themeChange(theme === "dark" ? "light" : "dark")}><Icon name={theme === "dark" ? "sun" : "moon"}/></button>
      </div>
    </header>
    <main className="main" id="main" tabIndex={-1}>
      <div className="page-heading">
        <div>
          {datePickerMode && <div className="inline-actions wrap">
            <div className="inline-actions">
              {page === "today" && <IconButton icon="arrow" className="date-step date-step-back" label={t("前一天")}
                disabled={!store.ready} onClick={() => stepOverviewDay(-1)}/>}
              <button type="button" className="date-label" aria-label={t("选择日期")} aria-haspopup="dialog"
                disabled={!store.ready} onClick={() => setDialog({ kind: "date-picker" })}>
                <Icon name="calendar" size={17}/><span suppressHydrationWarning>{dateTitle(viewedDay, language)}</span><Icon name="down" size={15}/>
              </button>
              {page === "today" && <IconButton icon="arrow" className="date-step" label={t("后一天")}
                disabled={!store.ready || viewedDay >= today} onClick={() => stepOverviewDay(1)}/>}
            </div>
            {historicalOverview && <button type="button" className="text-link return-today" onClick={() => setRecordDay(null)}>{t("回到今天")}</button>}
          </div>}
          <div className="page-title"><h1>{pageTitle}</h1>
            <a className={`state-chip ${hasSamples ? "sample-chip" : ""}`} href="#settings"><span/>{t(status)}</a></div>
        </div>
        {page !== "settings" && <div className="page-actions">
          {(page === "today" || page === "food") && <Button variant="primary" icon="plus" disabled={!store.ready}
            onClick={() => openFood(viewedDay, { keepDay: Boolean(recordDay) })}>{t("记录饮食")}</Button>}
          {(page === "today" || page === "training") && <Button variant={page === "today" ? "secondary" : "primary"} icon="plus"
            disabled={!store.ready} onClick={() => addWorkout(viewedDay)}>{t("记录训练")}</Button>}
          {page === "progress" && <Button variant="primary" icon="plus" disabled={!store.ready} onClick={addWeight}>{t("记录体重")}</Button>}
        </div>}
      </div>
      {store.volatile && <p className="notice storage-notice">{t("浏览器仅允许临时保存。关闭页面前可在设置中导出 CSV。")}</p>}
      {!store.ready ? <div className="card loading-card" role="status">{t(store.problem || "正在载入记录…")}</div> : <>
        {page === "today" && <SleepOverview view={sleep} rows={store.rows} profile={profile} day={viewedDay} today={today}/>}
        {page === "sleep" && <SleepPage view={sleep} rows={store.rows} profile={profile} day={viewedDay} today={today} select={selectDay}/>}
        {page === "today" && <Dashboard today={today} profile={profile} dayStats={dayStats} manualActivity={manual}
          foods={foods} workouts={workouts} weights={weights} onActivity={changeActivity} onFoodComplete={markFoodComplete}
          onFood={() => openFood(viewedDay, { keepDay: Boolean(recordDay) })} onWeight={addWeight}
          onFoodEdit={editFood} onFoodDelete={remove} onWorkoutEdit={editWorkout} onWorkoutDelete={remove}/>}
        {page === "food" && <FoodHistory today={today} day={viewedDay} stats={dayStats} onFoodComplete={markFoodComplete} showToday={() => selectDay(today)}
          rows={foods} presets={presets} open={addFoodOnDate} edit={editFood} remove={remove}
          copy={(meal, items) => openFood(today, { meal, items: items.map(({ payload }) => payload), keepDay: true })} deletePreset={remove}/>}
        {page === "training" && <TrainingPage today={today} day={viewedDay} selectDay={selectDay} rows={workouts} presets={workoutPresets} edit={editWorkout}
          add={addWorkout} remove={remove} deletePreset={remove} favorites={strengthFavorites} removeFavorite={remove} focus={trainingFocus}/>}
        {page === "progress" && <ProgressPage today={today} rows={weights} profile={profile} add={addWeight}
          edit={editWeight} remove={remove} confirm={saveProfile}/>}
        {page === "calendar" && <CalendarPage rows={store.rows} profile={profile} today={today} addFood={addFoodOnDate}/>}
        {page === "settings" && <SettingsPage profile={profile} latest={latest} theme={theme} setTheme={themeChange} auth={auth}
          store={store} providers={providers} save={saveProfile} exportData={exportRecords}
          clearSamples={async () => { await store.discardExamples(); notify("示例已移除，可以开始记录。"); }}
          hasSamples={hasSamples} message={notify}/>}
      </>}
    </main>
    <nav className="bottom-nav" aria-label={t("手机导航")}>{nav.map(({ id, label, icon }) =>
      <a href={`#${id}`} key={id} aria-current={page === id ? "page" : undefined}><Icon name={icon} size={21}/><span>{id === "sleep" && language === "en" ? "Sleep" : t(label)}</span></a>)}</nav>
    {dialog?.kind === "date-picker" && datePickerMode && <MonthDatePicker rows={store.rows} profile={profile} today={today}
      mode={datePickerMode} selected={viewedDay} close={close} select={(day) => { selectDay(day); close(); }}/>}
    {dialog?.kind === "food" && <FoodModal today={today} date={dialog.day} keepDay={dialog.keepDay} initialMeal={dialog.meal} initial={dialog.items}
      entryId={dialog.row?.id} favorites={presets} history={foods.slice(0, 90)} providers={providers} getToken={auth.token} close={close}
      setFavorite={async (food) => {
        if (!food.spec) return;
        const previous = presets.find(({ payload }) => normalize(payload.spec.name) === normalize(food.name));
        await store.save([{ kind: "food_preset", id: previous?.id ?? makeId(),
          payload: { spec: { ...food.spec, name: food.name }, amount: food.amount, unit: food.unit, grams: food.grams } }]);
        notify("已保存常吃食物。");
      }}
      save={async (entries, day, meal) => {
        if (!isDay(day) || day > today || !entries.length || entries.some((entry) => !foodTotals(entry))) throw new Error("请检查日期和营养信息。");
        const old = dialog.row;
        const changes = entries.map((entry, index): Change<"food"> => ({ kind: "food", id: old?.id ?? makeId(),
          payload: { ...entry, day, meal, time: old?.payload.time ?? Date.now() + index }, sample: old?.sample }));
        await store.save(changes);
        close();
        notify(old ? "已更新饮食记录。" : t`已记录 ${entries.length} 项食物。`, old
          ? [old]
          : changes.map(({ kind, id }) => ({ kind, id, payload: null })));
      }}/>}
    {dialog?.kind === "training" && <WorkoutModal today={today} date={dialog.day} initial={dialog.row} presets={workoutPresets} close={close}
      detailed={page === "training"} history={workoutHistory} workouts={workouts} favorites={strengthFavorites}
      onViewHistory={viewExerciseHistory}
      save={async (workout, preset, savedExercises = []) => {
        if (!isDay(workout.day) || workout.day > today) throw new Error("请选择有效的训练日期。");
        const old = dialog.row;
        const id = old?.id ?? makeId();
        const changes: Change[] = [{ kind: "workout", id, payload: workout, sample: old?.sample }];
        const undo: Change[] = [old ?? { kind: "workout", id, payload: null }];
        if (preset) {
          const previous = workoutPresets.find(({ payload }) => normalize(payload.name) === normalize(preset.name));
          const presetId = previous?.id ?? makeId();
          changes.push({ kind: "workout_preset", id: presetId, payload: preset });
          undo.push(previous ?? { kind: "workout_preset", id: presetId, payload: null });
        }
        for (const favorite of new Map(savedExercises.map((item) => [item.exerciseId, item])).values()) {
          const id = favorite.exerciseId;
          const previous = strengthFavorites.find((item) => item.id === id);
          changes.push({ kind: "strength_exercise", id, payload: favorite });
          undo.push(previous ?? { kind: "strength_exercise", id, payload: null });
        }
        await store.save(changes);
        close();
        notify("训练已保存。", undo);
      }}/>}
    {dialog?.kind === "weight" && <WeightModal today={today} date={dialog.day} initial={dialog.row} close={close} save={async (day, kg) => {
      if (!isDay(day) || day > today || !Number.isFinite(kg) || kg < 25 || kg > 500) throw new Error("请检查日期和体重。");
      const before = weights.find(({ id }) => id === day);
      await store.save([{ kind: "weight", id: day, payload: { day, kg }, sample: dialog.row?.sample }]);
      close();
      notify("体重已保存。", [before ?? { kind: "weight", id: day, payload: null }]);
    }}/>}
    {toast && <div className="toast" role="status"><Icon name="info" size={17}/><span>{t(toast.text)}</span>
      {toast.undo && <button type="button" className="text-link" onClick={async () => {
        const undo = toast.undo;
        if (!undo) return;
        try { await store.save(undo); notify("已撤销。"); } catch (error) { notify((error as Error).message); }
      }}>{t("撤销")}</button>}
      <IconButton label={t("关闭提示")} icon="close" onClick={() => setToast(null)}/>
    </div>}
  </div>;
}
