"use client";

import { useEffect, useState } from "react";
import { LOAD_MODES, MUSCLES, MUSCLE_LABELS, makeId, type Exercise, type LoadMode, type Muscle,
  type StrengthDefinition, type StrengthFavorite, type StrengthMove, type StrengthSet, type WeightUnit,
  type Workout, type WorkoutPreset } from "../lib/model";
import { normalize } from "../lib/nutrition";
import { definitionKey, dualWeight, LB_IN_KG, loadNames, setKg, strengthCatalog, toKg, workingSets, workoutStrength,
  type StrengthEntry } from "../lib/strength";
import { useLanguage } from "./language";
import { Button, Field, IconButton } from "./ui";

const MAX_MOVES = 25;
const MAX_MOVE_SETS = 60;
const MAX_SESSION_SETS = 180;

const common: Record<Muscle, string[]> = {
  chest: ["卧推", "上斜哑铃卧推", "夹胸"],
  back: ["高位下拉", "坐姿划船", "引体向上"],
  shoulders: ["肩推", "绳索侧平举", "Y 字上举", "反向飞鸟"],
  legs: ["深蹲", "倒蹬机", "腿弯举", "罗马尼亚硬拉"],
  arms: ["弯举", "三头下压"],
  core: ["卷腹", "悬垂举腿"],
};

type SetDraft = { key: string; weight: string; unit: WeightUnit; reps: string; warmup: boolean; note: string };
type MoveSeed = StrengthDefinition & { sets?: StrengthSet[]; unit?: WeightUnit };
export type StrengthMoveDraft = {
  key: string; source?: StrengthDefinition; name: string; muscle: Muscle; mode: LoadMode | "";
  variant: string; dumbbells: 1 | 2; barWeight: string; barUnit: WeightUnit; unit: WeightUnit;
  sets: SetDraft[]; favorite: boolean;
};

type Copy = (zh: string, en: string) => string;
const validId = (id: string) => /^[A-Za-z0-9_-]{1,80}$/.test(id);
const weightValue = (value: string) => value.trim() ? Number(value) : null;
const validWeight = (weight: number | null) => weight === null || (Number.isFinite(weight) && weight >= 0 && weight <= 2500);
const displayWeight = (number: number) => Math.round(number * 10) / 10;

// Keep the unit and text input for each set until the draft is saved.
function draftSet(unit: WeightUnit, source?: StrengthSet): SetDraft {
  return {
    key: makeId(), unit: source?.unit ?? unit, weight: source?.weight == null ? "" : String(source.weight),
    reps: source ? String(source.reps) : "", warmup: source?.warmup ?? false, note: source?.note ?? "",
  };
}

export function draftStrengthMove(seed?: MoveSeed, muscle: Muscle = "chest"): StrengthMoveDraft {
  const unit = seed?.sets?.at(-1)?.unit ?? seed?.unit ?? "lb";
  return {
    key: makeId(), source: seed, name: seed?.name ?? "", muscle: seed?.muscle ?? muscle, mode: seed?.mode ?? "",
    variant: seed?.variant ?? "", dumbbells: seed?.dumbbells ?? 2, unit,
    barWeight: seed?.bar ? String(seed.bar.weight) : "", barUnit: seed?.bar?.unit ?? unit,
    sets: seed?.sets?.map((set) => draftSet(unit, set)) ?? [draftSet(unit)], favorite: false,
  };
}

function moveDefinition(draft: StrengthMoveDraft, translate: (name: string) => string) {
  const name = draft.name.trim();
  const barWeight = weightValue(draft.barWeight);
  if (!draft.mode || !name || name.length > 70 || draft.variant.trim().length > 70
    || (draft.mode === "plates" && !validWeight(barWeight))) return null;
  const original = draft.source?.name;
  const canonical = original && normalize(name) === normalize(translate(original)) ? original
    : common[draft.muscle].find((choice) => normalize(name) === normalize(translate(choice))) ?? name;
  return {
    name: canonical, muscle: draft.muscle, mode: draft.mode, variant: draft.variant.trim(),
    ...(draft.mode === "dumbbell" ? { dumbbells: draft.dumbbells } : {}),
    ...(draft.mode === "plates" ? { bar: barWeight === null ? null : { weight: barWeight, unit: draft.barUnit } } : {}),
  };
}

// A changed setup resolves to its own identity. Legacy IDs are display keys only.
function moveIdentity(draft: StrengthMoveDraft, definition: Omit<StrengthDefinition, "exerciseId">,
  catalog: StrengthFavorite[]) {
  const key = definitionKey(definition);
  if (draft.source && definitionKey(draft.source) === key && validId(draft.source.exerciseId)) {
    return draft.source.exerciseId;
  }
  return catalog.find((move) => validId(move.exerciseId) && definitionKey(move) === key)?.exerciseId;
}

export function checkStrengthCounts(moves: { sets: unknown[] }[]) {
  return moves.length <= MAX_MOVES && moves.every(({ sets }) => sets.length >= 1 && sets.length <= MAX_MOVE_SETS)
    && moves.reduce((count, move) => count + move.sets.length, 0) <= MAX_SESSION_SETS;
}

export function strengthLimitText(copy: Copy) {
  return copy("每次最多 25 个动作、180 组，每个动作最多 60 组。",
    "A workout can have up to 25 exercises and 180 sets, with up to 60 sets per exercise.");
}

// Older aggregates can have more than 60 sets under one exercise. Keep every set when opening them.
export function legacyStrengthDraft(exercises: Exercise[]) {
  const moves = workoutStrength({ kind: "strength", exercises });
  if (moves.length !== exercises.length) return null;
  const split = moves.flatMap((move) => Array.from({ length: Math.ceil(move.sets.length / MAX_MOVE_SETS) }, (_, index) =>
    ({ ...move, sets: move.sets.slice(index * MAX_MOVE_SETS, (index + 1) * MAX_MOVE_SETS) })));
  return checkStrengthCounts(split) ? split.map((move) => draftStrengthMove(move)) : null;
}

// Validate the saved object and keep older aliases linked without persisting legacy keys.
export function saveStrengthDraft(drafts: StrengthMoveDraft[], catalog: StrengthFavorite[],
  translate: (name: string) => string, copy: Copy): { moves: StrengthMove[]; favorites: StrengthFavorite[] } | { error: string } {
  const moves: StrengthMove[] = [];
  const favorites = new Map<string, StrengthFavorite>();
  const identities = new Map<string, string>();
  if (!checkStrengthCounts(drafts)) return { error: strengthLimitText(copy) };
  for (const draft of drafts) {
    const definition = moveDefinition(draft, translate);
    if (!definition) return { error: copy("请检查动作名称、器械和杆重。", "Check the exercise name, equipment, and bar weight.") };
    const key = definitionKey(definition);
    const exerciseId = moveIdentity(draft, definition, catalog) ?? identities.get(key) ?? draft.key;
    identities.set(key, exerciseId);
    const sets: StrengthSet[] = [];
    for (const set of draft.sets) {
      const weight = draft.mode === "bodyweight" ? null : weightValue(set.weight);
      const reps = Number(set.reps);
      const note = set.note.trim();
      if (!validWeight(weight) || !Number.isInteger(reps) || reps < 1 || reps > 300 || note.length > 120) {
        return { error: copy("每组次数须为 1–300，重量须为 0–2500，备注最多 120 字。",
          "Enter 1–300 reps and a weight of 0–2500 per set. Notes can have up to 120 characters.") };
      }
      sets.push({ weight, unit: set.unit, reps, ...(set.warmup ? { warmup: true } : {}), ...(note ? { note } : {}) });
    }
    moves.push({ exerciseId, ...definition, sets });
    if (draft.favorite) favorites.set(exerciseId, { exerciseId, ...definition, unit: sets.at(-1)?.unit ?? draft.unit });
  }
  return { moves, favorites: [...favorites.values()] };
}

// Allow room for the object overhead in the 30 KB database limit.
export function fitsStrengthRecord(payload: Workout | WorkoutPreset) {
  const details = payload.strengthDetails ?? [];
  const sets = details.reduce((count, move) => count + move.sets.length, 0);
  const overhead = 512 + payload.exercises.length * 48 + details.length * 64 + sets * 40;
  return new TextEncoder().encode(JSON.stringify(payload)).length + overhead <= 30_000;
}

function shownSet(move: StrengthDefinition, set: StrengthSet, copy: Copy) {
  if (move.mode === "bodyweight") return copy("自重", "Bodyweight");
  if (set.weight === null) return copy("重量未记录", "Weight unrecorded");
  const original = dualWeight(set.weight, set.unit);
  if (move.mode === "assisted") return copy(`助力 ${original}`, `${original} assistance`);
  if (move.mode !== "plates") return original;
  const kg = setKg(move, set);
  if (kg === null) return copy(`片重 ${original}`, `${original} plates`);
  const total = dualWeight(displayWeight(set.unit === "lb" ? kg / LB_IN_KG : kg), set.unit);
  return copy(`片重 ${original} · 总重 ${total}`, `${original} plates · ${total} total`);
}

function UnitOptions() {
  return <><option value="lb">lb</option><option value="kg">kg</option></>;
}

function SetEditor({ set, index, mode, barWeight, barUnit, removable, update, remove }: {
  set: SetDraft; index: number; mode: StrengthMoveDraft["mode"]; barWeight: string; barUnit: WeightUnit;
  removable: boolean; update: (set: Partial<SetDraft>) => void; remove: () => void;
}) {
  const { language, t } = useLanguage();
  const copy: Copy = (zh, en) => language === "en" ? en : zh;
  const [showNote, setShowNote] = useState(Boolean(set.note));
  const showWeight = mode !== "bodyweight";
  const weight = weightValue(set.weight);
  const actualBar = weightValue(barWeight);
  const normalizedBar = actualBar !== null && validWeight(actualBar) && weight !== null && validWeight(weight)
    ? displayWeight(weight + toKg(actualBar, barUnit) / (set.unit === "lb" ? LB_IN_KG : 1)) : null;
  const id = `strength-set-${set.key}`;
  return <fieldset className="strength-set">
    <legend>{copy(`第 ${index + 1} 组`, `Set ${index + 1}`)}</legend>
    <div className="strength-set-fields" data-weight={showWeight}>
      {showWeight && <>
        <Field label={mode === "plates" ? copy("片重", "Plates") : mode === "assisted" ? copy("助力", "Assistance") : t("重量")}>
          <input id={`${id}-weight`} type="number" inputMode="decimal" min="0" max="2500" step="any" value={set.weight} placeholder="—"
            onChange={(event) => update({ weight: event.target.value })}/>
        </Field>
        <Field label={t("单位")}><select value={set.unit} onChange={(event) => update({ unit: event.target.value as WeightUnit })}>
          <UnitOptions/>
        </select></Field>
      </>}
      <Field label={copy("次数", "Reps")}>
        <input id={id} type="number" inputMode="numeric" min="1" max="300" required value={set.reps}
          onChange={(event) => update({ reps: event.target.value })}/>
      </Field>
    </div>
    {showWeight && weight !== null && validWeight(weight) && <p className="fine strength-load-preview">
      {dualWeight(weight, set.unit)}
      {mode === "plates" && normalizedBar !== null && <> · {copy("总重", "Total")} {dualWeight(normalizedBar, set.unit)}</>}
    </p>}
    <div className="strength-set-tools">
      <label className="checkbox">
        <input type="checkbox" checked={set.warmup} onChange={(event) => update({ warmup: event.target.checked })}/>
        {copy("热身", "Warm-up")}
      </label>
      <button type="button" className="text-link" aria-expanded={showNote} aria-controls={`${id}-note`}
        onClick={() => setShowNote(!showNote)}>{copy("备注", "Note")}</button>
      <IconButton icon="trash" label={copy(`移除第 ${index + 1} 组`, `Remove set ${index + 1}`)} disabled={!removable} onClick={remove}/>
    </div>
    <div id={`${id}-note`} hidden={!showNote}>
      <Field label={copy("组备注（选填）", "Set note (optional)")}>
        <input maxLength={120} value={set.note} onChange={(event) => update({ note: event.target.value })}/>
      </Field>
    </div>
  </fieldset>;
}

// Only comparable setups can use the "last comparable" label. Unknown legacy loads remain visible as history.
function lastMove(draft: StrengthMoveDraft, history: StrengthEntry[], catalog: StrengthFavorite[],
  translate: (name: string) => string) {
  const definition = moveDefinition(draft, translate);
  if (!definition) return undefined;
  const identity = moveIdentity(draft, definition, catalog);
  const key = definitionKey(definition);
  const entries = history.filter(({ move }) => definitionKey(move) === key
    && (move.exerciseId === identity || (!identity && move.exerciseId === draft.source?.exerciseId)
      || (definition.mode === "unknown" && (!identity || !validId(move.exerciseId)))));
  const comparable = definition.mode !== "unknown" && (definition.mode !== "plates" || Boolean(definition.bar))
    ? entries.find(({ move }) => workingSets(move).some((set) => move.mode === "bodyweight" || setKg(move, set) !== null))
    : undefined;
  const entry = comparable ?? entries[0];
  return entry ? { entry, comparable: Boolean(comparable) } : undefined;
}

function PreviousMove({ previous, onCopy, onHistory, canCopy, draftChanged }: {
  previous: NonNullable<ReturnType<typeof lastMove>>; onCopy: () => void; onHistory: (exerciseId: string) => void;
  canCopy: boolean; draftChanged: boolean;
}) {
  const { language } = useLanguage();
  const copy: Copy = (zh, en) => language === "en" ? en : zh;
  const [confirm, setConfirm] = useState(false);
  const { day, move } = previous.entry;
  function setsSummary(sets: StrengthSet[], start: number) {
    return <ul className="strength-last-sets">{sets.map((set, index) => <li key={start + index}>
      <span>{copy(`第 ${start + index + 1} 组`, `Set ${start + index + 1}`)}</span>
      <strong>{shownSet(move, set, copy)} × {copy(`${set.reps} 次`, `${set.reps} reps`)}</strong>
      {set.warmup && <span>{copy("热身", "Warm-up")}</span>}
      {set.note && <span>{set.note}</span>}
    </li>)}</ul>;
  }
  return <div className="strength-last">
    <p><strong>{previous.comparable ? copy("上次相同口径", "Last comparable session") : copy("最近记录", "Last recorded")}</strong>
      <time dateTime={day}>{day}</time></p>
    {setsSummary(move.sets.slice(0, 4), 0)}
    {move.sets.length > 4 && <details>
      <summary>{copy(`其余 ${move.sets.length - 4} 组`, `${move.sets.length - 4} more sets`)}</summary>
      {setsSummary(move.sets.slice(4), 4)}
    </details>}
    <div className="strength-editor-actions">
      <Button icon="copy" onClick={onCopy} disabled={!canCopy}>{copy("套用上次动作", "Copy previous exercise")}</Button>
      <Button icon="chart" onClick={() => draftChanged ? setConfirm(true) : onHistory(move.exerciseId)}>
        {copy("查看动作历史", "View exercise history")}
      </Button>
    </div>
    {confirm && <div className="strength-history-confirm">
      <p role="status">{copy("打开历史会关闭这次未保存的草稿。", "Opening history closes this unsaved draft.")}</p>
      <div className="strength-editor-actions">
        <Button onClick={() => setConfirm(false)}>{copy("继续编辑", "Keep editing")}</Button>
        <Button onClick={() => onHistory(move.exerciseId)}>{copy("打开历史", "Open history")}</Button>
      </div>
    </div>}
  </div>;
}

function MoveEditor({ move, index, history, catalog, favoriteIds, setCount, draftChanged, update, remove, onViewHistory }: {
  move: StrengthMoveDraft; index: number; history: StrengthEntry[]; catalog: StrengthFavorite[]; favoriteIds: Set<string>;
  setCount: number; draftChanged: boolean; update: (move: StrengthMoveDraft) => void; remove: () => void;
  onViewHistory: (exerciseId: string) => void;
}) {
  const { language, t } = useLanguage();
  const copy: Copy = (zh, en) => language === "en" ? en : zh;
  const [focusSet, setFocusSet] = useState("");
  const previous = lastMove(move, history, catalog, t);
  const capacity = Math.min(MAX_MOVE_SETS, MAX_SESSION_SETS - setCount + move.sets.length);
  const id = `strength-move-${move.key}`;
  const definition = moveDefinition(move, t);
  const identity = definition ? moveIdentity(move, definition, catalog) : undefined;
  const isFavorite = identity && favoriteIds.has(identity);
  const lastSet = move.sets.at(-1);
  const change = (patch: Partial<StrengthMoveDraft>) => update({ ...move, ...patch });

  useEffect(() => {
    if (focusSet) document.getElementById(`strength-set-${focusSet}`)?.focus();
  }, [focusSet]);

  function addSet(source?: SetDraft) {
    if (move.sets.length >= capacity) return;
    const set = source ? { ...source, key: makeId() } : draftSet(lastSet?.unit ?? move.unit);
    change({ sets: [...move.sets, set] });
    setFocusSet(source || move.mode === "bodyweight" ? set.key : `${set.key}-weight`);
  }

  function copyPrevious() {
    if (!previous || previous.entry.move.sets.length > capacity) return;
    update({ ...draftStrengthMove(previous.entry.move), key: move.key, favorite: move.favorite });
  }

  return <article className="strength-move" aria-labelledby={`${id}-heading`}>
    <div className="strength-move-head">
      <h4 id={`${id}-heading`}>{move.name ? t(move.name) : copy(`动作 ${index + 1}`, `Exercise ${index + 1}`)}</h4>
      <IconButton icon="trash" label={copy(`移除动作 ${move.name ? t(move.name) : index + 1}`,
        `Remove exercise ${move.name ? t(move.name) : index + 1}`)} onClick={remove}/>
    </div>
    <div className="strength-move-fields">
      <Field label={t("动作")}>
        <input id={id} maxLength={70} list={`${id}-names`} required value={t(move.name)}
          onChange={(event) => change({ name: event.target.value })}/>
        <datalist id={`${id}-names`}>{common[move.muscle].map((name) => <option key={name} value={t(name)}/>)}</datalist>
      </Field>
      <Field label={t("肌群")}><select value={move.muscle} onChange={(event) => change({ muscle: event.target.value as Muscle })}>
        {MUSCLES.map((muscle) => <option value={muscle} key={muscle}>{t(MUSCLE_LABELS[muscle])}</option>)}
      </select></Field>
      <Field label={copy("器械与重量口径", "Equipment and load")}><select value={move.mode} required
        onChange={(event) => change({ mode: event.target.value as LoadMode })}>
        <option value="" disabled>{copy("选择口径…", "Choose equipment…")}</option>
        {LOAD_MODES.filter((mode) => mode !== "unknown" || move.mode === "unknown" || move.source?.mode === "unknown").map((mode) =>
          <option key={mode} value={mode}>{loadNames[mode][language === "en" ? 1 : 0]}</option>)}
      </select></Field>
      <Field label={copy("变式（选填）", "Variation (optional)")}>
        <input maxLength={70} value={move.variant} onChange={(event) => change({ variant: event.target.value })}
          placeholder={copy("如上斜 30°、宽握", "e.g. 30° incline, wide grip")}/>
      </Field>
    </div>
    {move.mode === "dumbbell" && <div className="strength-setup">
      <Field label={copy("哑铃数量", "Dumbbells")}><select value={move.dumbbells}
        onChange={(event) => change({ dumbbells: event.target.value === "1" ? 1 : 2 })}>
        <option value="1">{copy("1 只", "1 dumbbell")}</option><option value="2">{copy("2 只", "2 dumbbells")}</option>
      </select></Field>
      <p className="fine">{copy("每组填写单只哑铃的重量。", "Enter the weight of one dumbbell per set.")}</p>
    </div>}
    {move.mode === "plates" && <div className="strength-setup">
      <div className="strength-bar-fields">
        <Field label={copy("杆重（选填）", "Bar weight (optional)")}>
          <input type="number" inputMode="decimal" min="0" max="2500" step="any" value={move.barWeight}
            onChange={(event) => change({ barWeight: event.target.value })}/>
        </Field>
        <Field label={copy("杆重单位", "Bar unit")}><select value={move.barUnit}
          onChange={(event) => change({ barUnit: event.target.value as WeightUnit })}><UnitOptions/></select></Field>
      </div>
      <p className="fine">{copy("片重填两侧合计。填写杆重后可看到含杆总重。", "Enter the plate weight from both sides. Add the bar weight to see the total.")}</p>
    </div>}
    {move.mode === "unknown" && <p className="fine">{copy("旧记录的器械或重量口径未知。", "The equipment or load convention for this older entry is unknown.")}</p>}
    {previous && <PreviousMove key={previous.entry.id} previous={previous} onCopy={copyPrevious} canCopy={previous.entry.move.sets.length <= capacity}
      onHistory={onViewHistory} draftChanged={draftChanged}/>}
    <div className="strength-set-list">
      {move.sets.map((set, setIndex) => <SetEditor key={set.key} set={set} mode={move.mode} barWeight={move.barWeight} barUnit={move.barUnit}
        index={setIndex} removable={move.sets.length > 1}
        update={(patch) => change({ sets: move.sets.map((existing) => existing.key === set.key ? { ...existing, ...patch } : existing) })}
        remove={() => change({ sets: move.sets.filter((existing) => existing.key !== set.key) })}/>)}
    </div>
    <div className="strength-editor-actions">
      <Button icon="plus" onClick={() => addSet()} disabled={move.sets.length >= capacity}>{copy("加一组", "Add set")}</Button>
      <Button icon="copy" onClick={() => addSet(lastSet)} disabled={!lastSet || move.sets.length >= capacity}>
        {copy("复制上一组", "Copy last set")}
      </Button>
    </div>
    <label className="checkbox strength-favorite">
      <input type="checkbox" checked={move.favorite} onChange={(event) => change({ favorite: event.target.checked })}/>
      {isFavorite ? copy("更新常用动作", "Update favorite exercise") : copy("保存为常用动作", "Save as favorite exercise")}
    </label>
  </article>;
}

function choiceLabel(choice: StrengthFavorite, language: "zh" | "en", translate: (name: string) => string) {
  const count = choice.dumbbells ?? 2;
  const equipment = loadNames[choice.mode][language === "en" ? 1 : 0];
  return [translate(choice.name), choice.variant, equipment,
    choice.mode === "dumbbell" ? (language === "en" ? `${count} total` : `${count} 只`) : ""].filter(Boolean).join(" · ");
}

// Favorite shortcuts set up the equipment. Repeating a previous exercise copies its exact sets on demand.
export function StrengthEditor({ moves, change, history, catalog, favoriteIds, defaultMuscle, draftChanged, onViewHistory }: {
  moves: StrengthMoveDraft[]; change: (moves: StrengthMoveDraft[]) => void; history: StrengthEntry[];
  catalog: StrengthFavorite[]; favoriteIds: Set<string>; defaultMuscle?: Muscle; draftChanged: boolean;
  onViewHistory: (exerciseId: string) => void;
}) {
  const { language, t } = useLanguage();
  const copy: Copy = (zh, en) => language === "en" ? en : zh;
  const [focusMove, setFocusMove] = useState("");
  const favorites = catalog.filter(({ exerciseId }) => favoriteIds.has(exerciseId));
  const recent = strengthCatalog(history, []).filter(({ exerciseId }) => !favoriteIds.has(exerciseId)).slice(0, 30);
  const setCount = moves.reduce((count, move) => count + move.sets.length, 0);
  const canAdd = moves.length < MAX_MOVES && setCount < MAX_SESSION_SETS;

  useEffect(() => {
    if (focusMove) document.getElementById(`strength-move-${focusMove}`)?.focus();
  }, [focusMove]);

  function add(seed?: MoveSeed) {
    if (!canAdd) return;
    const move = draftStrengthMove(seed, moves.at(-1)?.muscle ?? defaultMuscle);
    change([...moves, move]);
    setFocusMove(move.key);
  }

  return <section className="strength-editor" aria-labelledby="workout-strength-title">
    <div className="strength-editor-title">
      <h3 id="workout-strength-title" className="minor-heading">{copy("逐组记录", "Log individual sets")}</h3>
      {moves.length > 0 && <span className="fine">{copy(`${moves.length} 个动作 · ${setCount} 组`, `${moves.length} exercises · ${setCount} sets`)}</span>}
    </div>
    {moves.map((move, index) => <MoveEditor key={move.key} move={move} index={index} history={history} catalog={catalog}
      favoriteIds={favoriteIds} setCount={setCount} draftChanged={draftChanged} onViewHistory={onViewHistory}
      update={(next) => change(moves.map((existing) => existing.key === move.key ? next : existing))}
      remove={() => change(moves.filter((existing) => existing.key !== move.key))}/>)}
    <div className="strength-editor-picker">
      {(favorites.length > 0 || recent.length > 0) && <Field label={copy("从常用或最近动作添加", "Add from favorites or recent exercises")}>
        <select value="" disabled={!canAdd} onChange={(event) => {
          const seed = [...favorites, ...recent].find(({ exerciseId }) => exerciseId === event.target.value);
          if (seed) add(seed);
        }}>
          <option value="">{copy("选择动作…", "Choose an exercise…")}</option>
          {favorites.length > 0 && <optgroup label={copy("常用动作", "Favorites")}>{favorites.map((choice) =>
            <option key={choice.exerciseId} value={choice.exerciseId}>{choiceLabel(choice, language, t)}</option>)}</optgroup>}
          {recent.length > 0 && <optgroup label={copy("最近动作", "Recent exercises")}>{recent.map((choice) =>
            <option key={choice.exerciseId} value={choice.exerciseId}>{choiceLabel(choice, language, t)}</option>)}</optgroup>}
        </select>
      </Field>}
      <div className="strength-editor-actions">
        <Button icon="plus" onClick={() => add()} disabled={!canAdd}>{t("加一个动作")}</Button>
      </div>
    </div>
    {!canAdd && <p className="fine">{strengthLimitText(copy)}</p>}
  </section>;
}
