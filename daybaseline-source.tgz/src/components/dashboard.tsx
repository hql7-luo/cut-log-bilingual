import { useLanguage } from "./language";
import { ACTIVITIES, ACTIVITY_LABELS, MEALS, MEAL_LABELS, MUSCLE_LABELS, WORKOUT_LABELS, workoutMuscles,
  type Activity, type LogRow, type Meal, type Profile, type Workout } from "../lib/model";
import { foodTotals, MACROS, NUTRIENT_LABEL, number, portionText, sourceLabel, sum, whole } from "../lib/nutrition";
import type { CalendarDayStats } from "../lib/calendar";
import { compactDay } from "../lib/dates";
import { dualWeight, loadNames, workoutStrength } from "../lib/strength";
import { translate, type Language, type Translate } from "../lib/locale";
import { trend } from "../lib/trends";
import { Button, CardHead, Empty, Icon, IconButton, type IconName } from "./ui";
import { WeightPlot } from "./weight-plot";

const mealIcons: Record<Meal, IconName> = { breakfast: "coffee", lunch: "bowl", dinner: "moon", snack: "snack" };
const activityIcons: Record<Activity, IconName> = { rest: "moon", strength: "lift", basketball: "ball", both: "bolt" };

// Keep the daily balance and completeness labels consistent across the overview and calendar.
export const nutritionCopy = {
  zh: {
    balance: "估算热量差", pending: "待比较", budgetLeft: "摄入预算剩余", overBudget: "超出摄入预算",
    complete: "已标记饮食完整。", incomplete: "记完全天饮食后，标记为完整。", empty: "先记录当天的饮食。",
    foodNeedsReview: "请补齐食物的营养数据。", markInOverview: "可在当天总览标记饮食完整。",
    mark: "标记饮食完整", reopen: "取消完整标记", savedTarget: "当天保存的目标", currentTarget: "目标按当前设置计算",
    profile: "检查个人资料以估算消耗", previewBurn: "计划消耗预估", partialBurn: "已知消耗估算",
    confirmWorkout: "补记实际训练时长，或更新活动选择。",
    savedTodayActivity: "摄入目标已保存。活动选择用于更新今日消耗预估。",
    savedPastActivity: "摄入目标已保存。训练消耗按已记录的训练估算。",
  },
  en: {
    balance: "Est. calorie balance", pending: "Pending", budgetLeft: "Intake budget left", overBudget: "Over intake budget",
    complete: "Food log complete.", incomplete: "Mark the log complete when you finish logging food.", empty: "Log food for this date.",
    foodNeedsReview: "Fill in the missing food nutrition values.", markInOverview: "Mark food complete in this date’s overview.",
    mark: "Mark food complete", reopen: "Reopen food log", savedTarget: "Goal saved for this date", currentTarget: "Goal based on current settings",
    profile: "Check your profile to estimate burn", previewBurn: "Planned burn estimate", partialBurn: "Est. known burn",
    confirmWorkout: "Log the workout duration or update the activity selection.",
    savedTodayActivity: "The intake goal is saved. Activity updates today’s burn estimate.",
    savedPastActivity: "The intake goal is saved. Burn uses logged workouts.",
  },
};

export function FoodList({ rows, onEdit, onDelete, onCopy, mealHeading: MealHeading = "h3" }: {
  rows: LogRow<"food">[]; onEdit?: (entry: LogRow<"food">) => void;
  onDelete?: (entry: LogRow<"food">) => void; onCopy?: (meal: Meal, items: LogRow<"food">[]) => void;
  mealHeading?: "h3" | "h4";
}) {
  const { language, t } = useLanguage();
  return <div className="meal-groups">{MEALS.map((meal) => {
    const items = rows.filter((row) => row.payload.meal === meal).sort((a, b) => a.payload.time - b.payload.time);
    if (!items.length) return null;
    const computed = items.flatMap(({ payload }) => foodTotals(payload)?.total ?? []);
    const total = computed.length ? sum(computed) : null;
    return <section className="meal-group" key={meal}>
      <div className="meal-heading">
        <span className={`tile-icon meal-${meal}`}><Icon name={mealIcons[meal]} size={18}/></span>
        <MealHeading>{t(MEAL_LABELS[meal])}</MealHeading>
        <span className="meal-kcal" title={computed.length < items.length ? nutritionCopy[language].foodNeedsReview : undefined}>
          {total ? <>{whole.format(total.kcal)} <small>kcal</small>{computed.length < items.length ? " *" : ""}</> : "—"}
        </span>
        {onCopy && <IconButton icon="copy" label={t`复制${t(MEAL_LABELS[meal])}到今天`} onClick={() => onCopy(meal, items)}/>}
      </div>
      {items.map((row) => {
        const entry = row.payload;
        const total = foodTotals(entry);
        const name = t(entry.name);
        const description = <><strong>{name}</strong>
          <span>{portionText(entry, language)}{entry.estimatedPortion || entry.spec?.source === "estimate" ? ` ${t("· 估算")}` : ""}</span></>;
        return <div className="log-line" key={row.id}>
          {onEdit ? <button type="button" className="log-name" onClick={() => onEdit(row)} aria-label={t`编辑 ${name}`}>
            {description}
          </button> : <div className="log-name">{description}</div>}
          <span className="line-kcal" title={`${t(sourceLabel(entry))}${total?.bounds ? ` · ${whole.format(total.bounds.low.kcal)}–${whole.format(total.bounds.high.kcal)} kcal` : ""}`}>
            {total ? whole.format(total.total.kcal) : "—"}
          </span>
          {onDelete && <IconButton icon="trash" label={t`删除 ${name}`} onClick={() => onDelete(row)}/>}
        </div>;
      })}
    </section>;
  })}</div>;
}

function workoutTitle(workout: Workout, language: Language) {
  const label = translate(language, WORKOUT_LABELS[workout.kind]);
  const groups = workoutMuscles(workout).map((muscle) => translate(language, MUSCLE_LABELS[muscle]));
  return workout.kind === "strength" && groups.length ? `${groups.join(" / ")} · ${label}` : label;
}

export function WorkoutList({ rows, onEdit, onDelete, showDetails = false, showStrengthDetails = false }: {
  rows: LogRow<"workout">[]; onEdit?: (entry: LogRow<"workout">) => void;
  onDelete?: (entry: LogRow<"workout">) => void; showDetails?: boolean; showStrengthDetails?: boolean;
}) {
  const { language, t } = useLanguage();
  return <div className="workout-list">{rows.map((row) => {
    const workout = row.payload;
    const title = workoutTitle(workout, language);
    const subtitle = workout.minutes ? t`${workout.minutes} 分钟` : "";
    const details = showStrengthDetails && workout.strengthDetails !== undefined ? workoutStrength(workout) : [];
    const description = <><strong>{title}</strong>{(subtitle || !showDetails) && <span>{subtitle || t("已记录")}</span>}</>;
    return <div className="workout-entry" key={row.id}>
      <div className="workout-line">
        <span className="tile-icon ink-lime"><Icon name={workout.kind === "strength" ? "lift" : workout.kind === "basketball" ? "ball" : "pulse"} size={18}/></span>
        {onEdit ? <button type="button" className="log-name" onClick={() => onEdit(row)} aria-label={t`编辑 ${title}`}>
          {description}
        </button> : <div className="log-name">{description}</div>}
        {onDelete && <IconButton icon="trash" label={t`删除 ${title}`} onClick={() => onDelete(row)}/>}
      </div>
      {showDetails && !details.length && workout.exercises.length > 0 && <ul className="workout-exercises">
        {workout.exercises.map((exercise, index) => <li key={`${exercise.name}-${index}`}>
          <strong>{t(exercise.name)}</strong>
          <span>{exercise.weight > 0 && `${showStrengthDetails ? dualWeight(exercise.weight, exercise.unit) : `${number.format(exercise.weight)} ${exercise.unit}`} · `}
            {t`${exercise.sets} 组 × ${exercise.reps} 次`}</span>
        </li>)}
      </ul>}
      {details.length > 0 && <div className="workout-set-summary">
        {details.map((move, index) => <div key={move.exerciseId + ":" + index}>
          <strong>{t(move.name)}</strong>
          <small>{[loadNames[move.mode][language === "en" ? 1 : 0], t(move.variant)].filter(Boolean).join(" · ")}</small>
          <ul aria-label={language === "en" ? "Recorded sets" : "已记录的组"}>
            {move.sets.map((set, setIndex) => <li key={setIndex}>
              {set.warmup && <span className="fine">{language === "en" ? "Warm-up" : "热身"} · </span>}
              {move.mode !== "bodyweight" && set.weight !== null && `${dualWeight(set.weight, set.unit)} × `}
              {t`${set.reps} 次`}
              {set.note && <small className="fine"> · {set.note}</small>}
            </li>)}
          </ul>
        </div>)}
      </div>}
      {showDetails && workout.note && <p className="workout-note">{workout.note}</p>}
    </div>;
  })}</div>;
}

export function balanceKind(shortfall: number) {
  if (Math.round(Math.abs(shortfall)) === 0) return "持平";
  return shortfall > 0 ? "缺口" : "盈余";
}

export function dailyBurnLabel(energy: CalendarDayStats["energy"], language: Language, t: Translate, isToday = false) {
  if (energy?.fromSelection) return nutritionCopy[language].previewBurn;
  if (energy?.missingDuration) return nutritionCopy[language].partialBurn;
  return t(isToday ? "今日估算消耗" : "估算消耗");
}

// Only a usable intake can be marked complete. Users can always reopen an existing mark.
export function DailyBalanceStatus({ day, onFoodComplete }: {
  day: CalendarDayStats; onFoodComplete?: (complete: boolean) => void;
}) {
  const { language } = useLanguage();
  const copy = nutritionCopy[language];
  const canComplete = day.kcal !== null && day.uncomputedFood === 0;
  let status = copy.empty;
  if (day.foodComplete) status = copy.complete;
  else if (day.uncomputedFood > 0) status = copy.foodNeedsReview;
  else if (canComplete) status = onFoodComplete ? copy.incomplete : copy.markInOverview;
  return <>
    <div className="inline-actions wrap">
      <p className="fine" role="status">{status}</p>
      {onFoodComplete && (day.foodMarked || canComplete) && <Button onClick={() => onFoodComplete(!day.foodMarked)}>
        {day.foodMarked ? copy.reopen : copy.mark}
      </Button>}
    </div>
    {day.expenditure === null && <a className="text-link" href="#settings">{copy.profile}</a>}
    {day.foodComplete && day.energy?.fromSelection && <p className="fine">{copy.confirmWorkout}</p>}
  </>;
}

// Explain the same training assumptions on the overview and the calendar.
export function TrainingEstimateNotes({ energy, target, expanded = false }: {
  energy: CalendarDayStats["energy"]; target: number; expanded?: boolean;
}) {
  const { language, t } = useLanguage();
  if (!energy) return null;
  const balanceAtTarget = energy.total === null || energy.missingDuration > 0 ? null : energy.total - target;
  const assumed = energy.assumed.map(({ kind, minutes }) => t`${t(ACTIVITY_LABELS[kind])} ${minutes} 分钟`)
    .join(language === "en" ? ", " : "、");
  return <>
    {(energy.baseline !== null || energy.trainingDetails.length > 0) && <details className="energy-breakdown" open={expanded || undefined}>
      <summary>{t("消耗明细")}</summary>
      <dl>
        {energy.baseline !== null && <div><dt>{t("日常消耗")}</dt><dd>{whole.format(energy.baseline)} kcal</dd></div>}
        {energy.trainingDetails.map(({ kind, minutes, kcal, assumed }) => <div key={kind}>
          <dt>{t(WORKOUT_LABELS[kind])} · {assumed && <>{t("暂按")} </>}{t`${minutes} 分钟`}</dt>
          <dd>+{whole.format(kcal)} kcal</dd>
        </div>)}
      </dl>
      {balanceAtTarget !== null && <p className="fine">
        {t`若吃到日目标 ${whole.format(target)} kcal，${t(`估算${balanceKind(balanceAtTarget)}`)} ${whole.format(Math.abs(balanceAtTarget))} kcal。`}
      </p>}
    </details>}
    {assumed && <p className="fine">{t`暂无时长，暂按${assumed}估算。`}</p>}
    {energy.missingDuration > 0 && <p className="fine">{t`${energy.missingDuration} 项训练补填时长后会计入消耗。`}</p>}
  </>;
}

function Budget({ day, rows, isToday, onFoodComplete }: {
  day: CalendarDayStats; rows: LogRow<"food">[]; isToday: boolean; onFoodComplete: (complete: boolean) => void;
}) {
  const { language, t } = useLanguage();
  const copy = nutritionCopy[language];
  const { energy, expenditure, kcal, nutritionTarget: target, shortfall } = day;
  const consumed = day.nutritionIntake;
  const left = consumed ? target.kcal - consumed.kcal : null;
  const overBudget = left !== null && left < 0;
  const estimated = rows.some(({ payload }) => payload.spec?.source === "estimate" || payload.estimatedPortion);
  const range = isToday ? "今日" : "当天";
  const nutritionLabel = t(`${range}营养`);
  const balanceLabel = shortfall === null ? copy.balance : t(`估算${balanceKind(shortfall)}`);
  const expenditureLabel = dailyBurnLabel(energy, language, t, isToday);
  return <section className="card budget-card" aria-label={nutritionLabel} data-over={overBudget}>
    <CardHead title={nutritionLabel}>{estimated && <span className="fine">{t("含估算")}</span>}</CardHead>
    <dl className="energy-summary">
      <div className="energy-primary energy-budget">
        <dt>{overBudget ? copy.overBudget : copy.budgetLeft}</dt>
        {left === null ? <dd className="fine">—</dd> : <dd><strong>{whole.format(Math.abs(left))}</strong><small>kcal</small></dd>}
      </div>
      <div className="energy-primary energy-balance">
        <dt>{balanceLabel}</dt>
        {shortfall === null ? <dd className="fine">{copy.pending}</dd> :
          <dd><strong>{whole.format(Math.abs(shortfall))}</strong><small>kcal</small></dd>}
      </div>
    </dl>
    <dl className="energy-measures">
      <div><dt>{t("已记摄入")}</dt><dd>{kcal === null ? "—" : <>{whole.format(kcal)} <small>kcal</small></>}</dd></div>
      <div><dt>{t("日目标")}</dt><dd aria-label={t("热量目标")}>{whole.format(target.kcal)}</dd></div>
      <div><dt>{expenditureLabel}</dt><dd>{expenditure === null ? "—" : <>{whole.format(expenditure)} <small>kcal</small></>}</dd></div>
    </dl>
    {consumed && <progress className="energy-progress" max={target.kcal || 1} value={Math.min(target.kcal || 1, consumed.kcal)}
      aria-label={t(`${range}热量进度`)}/>}
    <div className="energy-notes">
      <DailyBalanceStatus day={day} onFoodComplete={onFoodComplete}/>
      {(day.targetSaved || !isToday) && <p className="fine">{day.targetSaved ? copy.savedTarget : copy.currentTarget}</p>}
      <TrainingEstimateNotes energy={energy} target={target.kcal}/>
    </div>
    <div className="macros">{MACROS.map((macro) => {
      const delta = consumed ? target[macro] - consumed[macro] : null;
      return <div className={`macro ${macro}`} key={macro}>
        <div className="macro-title"><span/>{t(NUTRIENT_LABEL[macro])}</div>
        <p><strong>{consumed ? number.format(consumed[macro]) : "—"}</strong><span> / {number.format(target[macro])} g</span></p>
        {consumed && <progress max={target[macro] || 1} value={Math.min(target[macro] || 1, consumed[macro])}
          aria-label={isToday ? t`今日${t(NUTRIENT_LABEL[macro])}进度` : t`当天${t(NUTRIENT_LABEL[macro])}进度`}/>}
        {delta !== null && <small>{delta < -0.05 ? t("超出") : t("剩余")} {number.format(Math.abs(delta))} g</small>}
      </div>;
    })}</div>
  </section>;
}

export function Dashboard({ today, profile, dayStats, manualActivity, foods, workouts, weights, onActivity, onFood,
  onWeight, onFoodComplete, onFoodEdit, onFoodDelete, onWorkoutEdit, onWorkoutDelete }: {
  today: string; profile: Profile; dayStats: CalendarDayStats; manualActivity: boolean;
  foods: LogRow<"food">[]; workouts: LogRow<"workout">[]; weights: LogRow<"weight">[];
  onActivity: (activity: Activity | null) => void; onFood: () => void; onWeight: () => void; onFoodComplete: (complete: boolean) => void;
  onFoodEdit: (row: LogRow<"food">) => void; onFoodDelete: (row: LogRow<"food">) => void;
  onWorkoutEdit: (row: LogRow<"workout">) => void; onWorkoutDelete: (row: LogRow<"workout">) => void;
}) {
  const { language, t } = useLanguage();
  // Anchor every card, including the weight trend, to the displayed day.
  const { day } = dayStats;
  const isToday = day === today;
  const stats = trend(weights.map(({ payload }) => payload), day, profile);
  const dailyFoods = foods.filter(({ payload }) => payload.day === day);
  const dailyWorkouts = workouts.filter(({ payload }) => payload.day === day).sort((a, b) => b.payload.time - a.payload.time);
  const showWeight = isToday || Boolean(stats.latest);
  const copy = nutritionCopy[language];
  const activityNote = dayStats.targetSaved ? (isToday ? copy.savedTodayActivity : copy.savedPastActivity) :
    t(isToday ? "活动选择影响摄入目标和预估，已记训练始终计入消耗。" : "活动选择影响当天摄入目标。训练消耗按已记录的训练估算。");

  return <div className="dashboard-grid">
    <div className="dashboard-column">
      <Budget day={dayStats} rows={dailyFoods} isToday={isToday} onFoodComplete={onFoodComplete}/>
      <section className="card meals-card">
        <CardHead title={t(isToday ? "今日饮食" : "当天饮食")} icon="food"><a className="text-link" href="#food">{t("饮食历史")}</a></CardHead>
        {dailyFoods.length ? <FoodList rows={dailyFoods} onEdit={onFoodEdit} onDelete={onFoodDelete}/> :
          <Empty icon="bowl" title={t(isToday ? "今天还没有饮食记录。" : "当天没有饮食记录。")}
            action={<Button onClick={onFood} icon="plus">{t("添加食物")}</Button>}/>}
      </section>
    </div>
    <div className="dashboard-column">
      <section className="card activity-card">
        <CardHead title={t(isToday ? "今天的活动" : "当天活动")} icon="pulse"/>
        <div className="activity-grid">{ACTIVITIES.map((value) => <button key={value} type="button" className="activity-option"
          aria-pressed={value === dayStats.activity} onClick={() => onActivity(value)}>
          <Icon name={activityIcons[value]} size={19}/><span>{t(ACTIVITY_LABELS[value])}</span>
          <small>{whole.format(profile.calories[value])} kcal</small>
        </button>)}</div>
        <p className="activity-note">{activityNote}</p>
        {manualActivity && <button type="button" className="text-link" onClick={() => onActivity(null)}>{t("改为跟随训练记录")}</button>}
      </section>
      <section className="card weight-card">
        <CardHead title={t("体重趋势")} icon="scale"><button type="button" className="text-link" onClick={onWeight}>{t("记录体重")}</button></CardHead>
        <div className="weight-highlight">
          <div><strong>{showWeight ? number.format(stats.current) : "—"}</strong>{showWeight && <> <span>kg</span></>}</div>
          <span className="weight-caption">{stats.latest ? t`${compactDay(stats.latest.day)} 实测` :
            t(isToday ? "设置体重" : "截至当天暂无体重记录")}</span>
        </div>
        <WeightPlot rows={stats.sorted} today={day} days={30}/>
        <div className="weight-card-footer">
          <span>{stats.recent ? t`7 日均重 ${number.format(stats.recent.kg)} kg` : t`目标 ${number.format(profile.goalWeight)} kg`}</span>
          <a className="text-link" href="#progress">{t("查看进度")}</a>
        </div>
      </section>
      <section className="card today-workouts">
        <CardHead title={t(isToday ? "今日训练" : "当天训练")} icon="lift"><a className="text-link" href="#training">{t("训练记录")}</a></CardHead>
        {dailyWorkouts.length ? <WorkoutList rows={dailyWorkouts} onEdit={onWorkoutEdit} onDelete={onWorkoutDelete}/> :
          <p className="muted inner-text">{t(isToday ? "今天还没有训练记录。" : "当天没有训练记录。")}</p>}
      </section>
    </div>
  </div>;
}
