"use client";

import { useLanguage } from "./language";
import { useMemo, useState } from "react";
import { calendarDays } from "../lib/calendar";
import { compactDay, isDay, shiftDay } from "../lib/dates";
import { MUSCLES, MUSCLE_LABELS, WORKOUT_KINDS, WORKOUT_LABELS, workoutMuscles, type Exercise, type LogRow,
  type Muscle, type StrengthFavorite, type StrengthMove, type Workout, type WorkoutKind, type WorkoutPreset } from "../lib/model";
import { dualWeight, strengthCatalog, type StrengthEntry } from "../lib/strength";
import { weeklyWorkouts } from "../lib/trends";
import { WorkoutList } from "./dashboard";
import { checkStrengthCounts, draftStrengthMove, fitsStrengthRecord, legacyStrengthDraft, saveStrengthDraft,
  StrengthEditor, strengthLimitText, type StrengthMoveDraft } from "./strength-editor";
import { StrengthInsights } from "./strength-insights";
import { Button, CardHead, Empty, ErrorText, Field, Icon, IconButton, Modal } from "./ui";

// Keep source records intact until the user changes the exercise details.
type StrengthWorkoutDraft = {
  legacy: Exercise[];
  saved?: StrengthMove[];
  moves: StrengthMoveDraft[];
  edited: boolean;
};

function workoutDraft(source?: Pick<Workout, "exercises" | "strengthDetails">, detailed = true): StrengthWorkoutDraft {
  return {
    legacy: source?.exercises ?? [], saved: source?.strengthDetails, edited: false,
    moves: detailed ? source?.strengthDetails?.map((move) => draftStrengthMove(move)) ?? [] : [],
  };
}

export function WorkoutModal({ today, date, initial, presets, detailed, history, favorites, workouts, save, close, onViewHistory }: {
  today: string; date?: string; initial?: LogRow<"workout">; presets: LogRow<"workout_preset">[];
  detailed: boolean; history: StrengthEntry[]; favorites: LogRow<"strength_exercise">[]; workouts?: LogRow<"workout">[];
  save: (workout: Workout, preset?: WorkoutPreset, favorites?: StrengthFavorite[]) => Promise<void>;
  close: () => void; onViewHistory: (exerciseId: string) => void;
}) {
  const { language, t } = useLanguage();
  const copy = (zh: string, en: string) => language === "en" ? en : zh;
  const existing = initial?.payload;
  const [kind, setKind] = useState<WorkoutKind>(existing?.kind ?? "strength");
  const [day, setDay] = useState(existing?.day ?? date ?? today);
  const [minute, setMinute] = useState(existing?.minutes ? String(existing.minutes) : "");
  const [note, setNote] = useState(existing?.note ?? "");
  const [strength, setStrength] = useState(() => workoutDraft(existing, detailed));
  const [muscles, setMuscles] = useState<Muscle[]>(existing?.muscles ?? []);
  const [template, setTemplate] = useState(false);
  const [templateName, setTemplateName] = useState("");
  const [presetApplied, setPresetApplied] = useState(false);
  const [copiedDay, setCopiedDay] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const catalog = useMemo(() => detailed ? strengthCatalog(history, favorites) : [], [detailed, history, favorites]);
  const favoriteIds = useMemo(() => new Set(favorites.map(({ payload }) => payload.exerciseId)), [favorites]);
  const past = useMemo(() => detailed ? history.filter((entry) => entry.workoutId !== initial?.id
    && (entry.day < day || (entry.day === day && (!existing || entry.time < existing.time)))) : [],
    [day, detailed, existing, history, initial?.id]);
  const priorWorkout = useMemo(() => {
    if (!detailed || initial || !isDay(day)) return undefined;
    const source = workouts?.filter(({ payload }) => payload.kind === "strength" && payload.day <= day)
      .sort((a, b) => b.payload.day.localeCompare(a.payload.day) || b.payload.time - a.payload.time)[0]?.payload;
    if (source) return { ...source, fromHistory: false };
    const prior = past[0];
    if (!prior) return undefined;
    return {
      day: prior.day, exercises: [], muscles: [], fromHistory: true,
      strengthDetails: past.filter(({ workoutId }) => workoutId === prior.workoutId).map(({ move }) => move),
    };
  }, [day, detailed, initial, past, workouts]);
  const activeMoves = strength.edited ? strength.moves : strength.saved ?? [];
  const showLegacy = !strength.saved && !strength.edited && strength.legacy.length > 0;
  const quickKeepsStrength = !detailed && ((strength.saved?.length ?? 0) > 0 || strength.legacy.length > 0);
  const draftChanged = strength.edited || template || presetApplied || copiedDay !== ""
    || kind !== (existing?.kind ?? "strength") || day !== (existing?.day ?? date ?? today)
    || minute !== (existing?.minutes ? String(existing.minutes) : "") || note !== (existing?.note ?? "")
    || muscles.join(",") !== (existing?.muscles ?? []).join(",");

  function usePreset(preset: WorkoutPreset) {
    setKind(preset.kind);
    setMinute(preset.minutes ? String(preset.minutes) : "");
    setNote(preset.note);
    setStrength(workoutDraft(preset));
    setMuscles(preset.muscles ?? []);
    setPresetApplied(true);
    setCopiedDay("");
    setError("");
  }

  function copyPreviousSession() {
    if (!priorWorkout) return;
    if (priorWorkout.strengthDetails && !checkStrengthCounts(priorWorkout.strengthDetails)) {
      setError(strengthLimitText(copy));
      return;
    }
    const copied = workoutDraft(priorWorkout);
    setStrength({ ...copied, edited: priorWorkout.fromHistory });
    setMuscles((before) => [...new Set([...before, ...(priorWorkout.muscles ?? [])])]);
    setCopiedDay(priorWorkout.day);
    setError("");
  }

  function detailLegacy() {
    const moves = legacyStrengthDraft(strength.legacy);
    if (!moves) {
      setError(copy("无法按组展开这条旧记录。请检查动作数量和旧组数。", "This older summary could not be opened as sets. Check the exercise and set counts."));
      return;
    }
    setStrength({ legacy: [], moves, edited: true });
    setError("");
  }

  function changeMoves(moves: StrengthMoveDraft[]) {
    if (!moves.length && strength.moves.length > 0 && !muscles.length) {
      const related = [...(strength.saved ?? []), ...strength.moves].map(({ muscle }) => muscle);
      setMuscles([...new Set(related)]);
    }
    setStrength({ ...strength, moves, edited: true });
    setError("");
  }

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (busy) return;
    setError("");
    if (!isDay(day) || day > today) { setError("请选择今天或过去的日期。"); return; }
    if (kind === "strength" && !activeMoves.length && !strength.legacy.length && !muscles.length) {
      setError("请选择肌群或添加一个动作。");
      return;
    }
    if (detailed && template && !templateName.trim()) { setError("给模板填一个名称。"); return; }
    let strengthDetails = strength.saved;
    if (kind !== "strength" && (strength.saved || strength.edited)) strengthDetails = [];
    let savedFavorites: StrengthFavorite[] = [];
    if (kind === "strength" && detailed && strength.edited) {
      const result = saveStrengthDraft(strength.moves, catalog, t, copy);
      if ("error" in result) { setError(result.error); return; }
      strengthDetails = result.moves;
      savedFavorites = result.favorites;
    }
    const details = {
      kind, exercises: kind === "strength" ? strength.legacy : [],
      minutes: minute ? Number(minute) : null, note: note.trim(),
      ...(kind === "strength" && muscles.length ? { muscles } : {}),
      ...(strengthDetails !== undefined ? { strengthDetails } : {}),
    };
    const workout = { ...details, day, time: existing?.time ?? Date.now() };
    const preset = detailed && template ? { ...details, name: templateName.trim() } : undefined;
    if (strengthDetails?.length && ((strength.edited || !initial) && !fitsStrengthRecord(workout)
      || (preset && !fitsStrengthRecord(preset)))) {
      setError(copy("逐组记录超过了单次容量。请缩短组备注或减少组数。", "This workout is too large. Shorten the set notes or remove some sets."));
      return;
    }
    setBusy(true);
    try { await save(workout, preset, savedFavorites.length ? savedFavorites : undefined); }
    catch (failure) { setError((failure as Error).message); }
    finally { setBusy(false); }
  }

  return <Modal title={initial ? t("编辑训练") : t("记录训练")} close={close} wide={detailed} footer={
    <Button type="submit" form="workout-form" variant="primary" icon="check" disabled={busy}>{busy ? t("正在保存…") : t("保存训练")}</Button>
  }>
    <form id="workout-form" className="form-stack" onSubmit={submit}>
      {detailed && presets.length > 0 && !initial && <Field label={t("套用训练模板")}><select value="" onChange={(event) => {
        const preset = presets.find(({ id }) => id === event.target.value);
        if (preset) usePreset(preset.payload);
      }}><option value="">{t("选择模板…")}</option>{presets.map(({ id, payload }) => <option key={id} value={id}>{t(payload.name)}</option>)}</select></Field>}
      <div className="form-grid workout-date-fields">
        <Field label={t("日期")}><input type="date" required max={today} value={day} onChange={(event) => setDay(event.target.value)}/></Field>
        <Field label={t("时长（分钟，选填）")}><input type="number" inputMode="numeric" min="1" max="600" value={minute}
          onChange={(event) => setMinute(event.target.value)} placeholder="45" aria-describedby="workout-duration-help"/></Field>
      </div>
      <p className="fine" id="workout-duration-help">{t("消耗按训练时长估算。时长请扣除长时间等场或休息。")}</p>
      <div className="segments wrap" role="group" aria-label={t("训练类型")}>{WORKOUT_KINDS.map((value) =>
        <button key={value} type="button" aria-pressed={kind === value} disabled={quickKeepsStrength && value !== "strength"}
          onClick={() => setKind(value)}>{t(WORKOUT_LABELS[value])}</button>)}</div>
      {kind === "strength" && <>
        <div className="field">
          <span>{t("训练肌群")}</span>
          <div className="segments wrap" role="group" aria-label={t("训练肌群")}>
            {MUSCLES.map((muscle) => <button key={muscle} type="button" aria-pressed={muscles.includes(muscle)}
              onClick={() => setMuscles((before) => before.includes(muscle) ? before.filter((value) => value !== muscle) : [...before, muscle])}>
              {t(MUSCLE_LABELS[muscle])}
            </button>)}
          </div>
        </div>
        {detailed && priorWorkout && !copiedDay && !activeMoves.length && !strength.legacy.length &&
          <div className="strength-copy-session">
            <Button icon="copy" onClick={copyPreviousSession}>{copy("复制上次力量训练", "Copy last strength session")}</Button>
            <time className="fine" dateTime={priorWorkout.day}>{priorWorkout.day}</time>
          </div>}
        {copiedDay && <p className="fine" role="status">{copy(`已将 ${copiedDay} 的力量训练复制到草稿。`, `Copied the ${copiedDay} strength session into this draft.`)}</p>}
        {showLegacy && <div className="strength-legacy">
          <h3 className="minor-heading">{copy("旧版动作汇总", "Legacy exercise summary")}</h3>
          <p className="fine">{copy("旧记录的器械或重量口径未知。", "The equipment or load convention for these older entries is unknown.")}</p>
          <ul className="strength-last-sets">{strength.legacy.map((move, index) => <li key={index}>
            <strong>{t(move.name)}</strong><span>{move.weight > 0 ? dualWeight(move.weight, move.unit) : copy("重量未记录", "Weight unrecorded")}</span>
            <span>{t`${move.sets} 组 × ${move.reps} 次`}</span>
          </li>)}</ul>
          {detailed && <div className="strength-editor-actions">
            <Button icon="edit" onClick={detailLegacy}>{copy("按组编辑", "Edit individual sets")}</Button>
          </div>}
        </div>}
        {!detailed && !!strength.saved?.length && <p className="fine">
          {copy(`已记录 ${strength.saved.length} 个动作。可在训练页编辑逐组数据。`,
            `${strength.saved.length} exercises logged. Edit individual sets on the Training page.`)}
        </p>}
        {detailed && !showLegacy && <StrengthEditor moves={strength.moves} change={changeMoves} history={past} catalog={catalog}
          favoriteIds={favoriteIds} defaultMuscle={muscles[0]} draftChanged={draftChanged} onViewHistory={onViewHistory}/>}
      </>}
      <Field label={t("训练备注（选填）")}><textarea rows={2} maxLength={500} value={note} onChange={(event) => setNote(event.target.value)}
        placeholder={t("例如坡度 10%，或今天最后一组的感觉")}/></Field>
      {detailed && <label className="checkbox"><input type="checkbox" checked={template} onChange={(event) => setTemplate(event.target.checked)}/> {t("保存为训练模板")}</label>}
      {detailed && template && <Field label={t("模板名称")}><input value={templateName} required maxLength={65} placeholder={t("背部训练")}
        onChange={(event) => setTemplateName(event.target.value)}/></Field>}
      <ErrorText>{error}</ErrorText>
    </form>
  </Modal>;
}

// Fit training types in a compact date cell and show full details once selected.
function trainingTag(workout: Workout) {
  if (workout.kind === "basketball") return "篮球";
  if (workout.kind !== "strength") return "有氧";
  const muscles = workoutMuscles(workout);
  return muscles.length === 1 ? MUSCLE_LABELS[muscles[0]] : "力量";
}

export function TrainingPage({ today, day, selectDay, rows, presets, edit, remove, deletePreset, add, favorites, removeFavorite, focus }: {
  today: string; day: string; selectDay: (day: string) => void; rows: LogRow<"workout">[]; presets: LogRow<"workout_preset">[];
  edit: (row: LogRow<"workout">) => void; remove: (row: LogRow<"workout">) => void;
  deletePreset: (row: LogRow<"workout_preset">) => void; add: (day: string) => void;
  favorites: LogRow<"strength_exercise">[]; removeFavorite: (row: LogRow<"strength_exercise">) => void; focus?: string;
}) {
  const { language, t } = useLanguage();
  const ordered = useMemo(() => [...rows].sort((a, b) => b.payload.day.localeCompare(a.payload.day) || b.payload.time - a.payload.time), [rows]);
  const recentStart = shiftDay(today, -6);
  const yesterday = shiftDay(today, -1);
  const dailyRows = ordered.filter(({ payload }) => payload.day === day);
  const recent = new Map<string, Set<string>>();
  for (const { payload } of ordered) {
    if (payload.day < recentStart || payload.day > today) continue;
    const tags = recent.get(payload.day) ?? new Set<string>();
    tags.add(trainingTag(payload));
    recent.set(payload.day, tags);
  }
  const dateLabel = (date: string) => date === today ? t("今天") : date === yesterday ? t("昨天") : compactDay(date);
  const dateSeparator = language === "en" ? ", " : "，";
  const stats = weeklyWorkouts(rows.map(({ payload }) => payload), today);

  return <div className="subpage-grid">
    <div className="dashboard-column">
      <section className="card padded">
        <CardHead title={t("最近 7 天")} icon="calendar">
          <input className="sleep-date" type="date" max={today} value={day}
            aria-label={language === "en" ? "Training date" : "训练日期"}
            onChange={(event) => { if (event.target.value && event.target.value <= today) selectDay(event.target.value); }}/>
        </CardHead>
        <div className="calendar-grid training-dates" role="group" aria-label={t("最近 7 天训练")}>
          {calendarDays(recentStart, today).map((date) => {
            const tags = [...(recent.get(date) ?? [])];
            const shown = tags.length > 2 ? [tags[0], `+${tags.length - 1}`] : tags;
            return <button key={date} type="button" className={`calendar-day${tags.length ? " recorded" : ""}`}
              aria-pressed={date === day} aria-current={date === today ? "date" : undefined}
              aria-label={[dateLabel(date), date, tags.length ? tags.map((tag) => t(tag)).join(language === "en" ? ", " : "、") : t("未记训练")].join(dateSeparator)}
              onClick={() => selectDay(date)}>
              <strong>{date === yesterday && language === "en" ? "Yday" : dateLabel(date)}</strong>
              {shown.length ? shown.map((tag) => <span key={tag}>{tag === "篮球" && language === "en" ? "Hoops" : t(tag)}</span>) : <span>—</span>}
            </button>;
          })}
        </div>
        <section className="training-day-records" aria-labelledby="training-day-heading">
          <h3 id="training-day-heading">{t`${dateLabel(day)}的训练`}</h3>
          {dailyRows.length ? <WorkoutList rows={dailyRows} onEdit={edit} onDelete={remove} showDetails showStrengthDetails/> :
            <Empty icon="lift" title={t("当天没有训练记录。")} action={<Button icon="plus" onClick={() => add(day)}>{t("添加当天训练")}</Button>}/>}
        </section>
      </section>
      <section className="card padded">
        <CardHead title={t("本周训练")} icon="lift"><span className="fine">{compactDay(stats.start)} – {compactDay(stats.end)}</span></CardHead>
        <div className="training-stats">
          <div><span>{t("力量训练")}</span><strong>{stats.strength} <small>{t("/ 4–5 天")}</small></strong><progress aria-label={t("本周力量天数")} max={5} value={Math.min(5, stats.strength)}/></div>
          <div><span>{t("篮球")}</span><strong>{stats.basketball} <small>{t("/ 2 天")}</small></strong><progress aria-label={t("本周篮球天数")} max={2} value={Math.min(2, stats.basketball)}/></div>
          <div><span>{t("腿部")}</span><strong className="leg-status">{stats.muscles.legs.size ? t("已训练") : t("待训练")}</strong><small>{t("每周至少 1 天")}</small></div>
        </div>
        <details className="training-muscles">
          <summary>{t("各肌群训练天数")}</summary>
          <div className="muscle-grid">{MUSCLES.map((muscle) => <div key={muscle}>
            <span>{t(MUSCLE_LABELS[muscle])}</span><strong>{stats.muscles[muscle].size} <small>{t("天")}</small></strong>
          </div>)}</div>
        </details>
      </section>
    </div>
    <div className="dashboard-column">
      <StrengthInsights rows={rows} today={today} focus={focus} favorites={favorites}/>
      <section className="card padded">
        <CardHead title={t("训练模板")} icon="star"/>
        {presets.length ? presets.map((preset) => <div className="history-row" key={preset.id}>
          <span>{t(preset.payload.name)}</span><IconButton icon="trash" label={t`删除模板 ${t(preset.payload.name)}`} onClick={() => deletePreset(preset)}/>
        </div>) : <p className="muted">{t("记录训练时可保存常做动作，之后一键套用。")}</p>}
      </section>
      {favorites.length > 0 && <section className="card padded">
        <CardHead title={language === "en" ? "Favorite exercises" : "常用动作"} icon="star"/>
        {favorites.map((favorite) => <div className="history-row" key={favorite.id}>
          <span>{[t(favorite.payload.name), favorite.payload.variant].filter(Boolean).join(" · ")}</span>
          <IconButton icon="trash" label={language === "en" ? `Remove ${t(favorite.payload.name)} from favorites` : `移除常用动作 ${favorite.payload.name}`}
            onClick={() => removeFavorite(favorite)}/>
        </div>)}
      </section>}
    </div>
  </div>;
}
