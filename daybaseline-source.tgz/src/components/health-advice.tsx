"use client";

import { useMemo, useState, type ReactNode } from "react";
import { HEALTH_WINDOWS, focusHealth, healthSummary, type HealthSummary, type HealthWindow } from "../lib/health";
import { number, whole } from "../lib/nutrition";
import { sleepDuration } from "../lib/sleep";
import type { Profile, Row } from "../lib/model";
import type { SleepView } from "../lib/use-sleep";
import { useLanguage } from "./language";
import { CardHead, Icon } from "./ui";

const actions: Record<HealthSummary["priority"], [string, string]> = {
  "intake-review": ["均重下降偏快，可比训练也多次回落。先回看这段的记录和估算缺口，再重新评估摄入目标。",
    "Average weight fell faster than planned and comparable sets declined repeatedly. Review the logs and estimated deficit before revisiting your intake goal."],
  "weight-fast": ["近两段均重下降都快于你的目标。先回看饮食是否记全，并继续按相近条件称重。",
    "Average weight fell faster than your goal in two comparisons. Check that your meals are fully logged and keep weighing under similar conditions."],
  recovery: ["近一周睡眠偏短，力量训练也排得密。下一次训练前可以留出一个轻量日，并给今晚预留睡眠时间。",
    "Sleep ran short during a week with frequent strength sessions. Consider a light day before your next session and leave time for sleep tonight."],
  "sleep-goal": ["睡眠时长低于你设的目标。可以先按起床时间往前安排入睡，留足睡眠时间。",
    "Sleep was shorter than your own goal. Work back from your wake time to leave room for the sleep you planned."],
  "sleep-shorter": ["有记录的睡眠时长比前一段短。下一晚可以先给睡眠留出和往常一样的时间。",
    "Logged sleep was shorter than your earlier records. Set aside your usual amount of time for sleep on the next night."],
  "strength-down": ["同一动作的可比工作组重复回落。下次先沿用同一器械和设定，把负重与次数都记下来。",
    "Comparable working sets declined more than once. At your next session, use the same setup and record both load and reps."],
  protein: ["完整饮食记录里的蛋白质低于对应目标。下一餐可以先安排一份常吃的蛋白质食物。",
    "Protein was below your goal on the complete food logs reviewed. Plan one familiar protein food for your next meal."],
  "weight-slow": ["近两段均重变化都慢于你的目标。接下来一周先把饮食记全，并按相近条件称重。",
    "Average weight changed more slowly than your goal in two comparisons. Finish logging meals and weigh under similar conditions over the next week."],
  "wake-time": ["多晚记录的起床时间相差较大。试着选一个接近平时、也能坚持的起床时间。",
    "Your wake time differed across several nights. Pick a wake time close to your usual routine that you can keep."],
  "confirm-food": ["还有食物的营养待确认。先检查份量或补上营养数据，再查看全天摄入。",
    "Some foods still need nutrition details. Check the portion or fill in the nutrition before reviewing full-day intake."],
  "finish-food": ["吃完最后一餐后，补齐加餐和饮料，再标记当天饮食完成。",
    "After the last meal, add any snacks and drinks, then mark the food log complete."],
  "strength-details": ["已有力量训练记录。下次顺手记下一个常做动作的工作组，方便以后对比。",
    "You have a strength session logged. Next time, note the working sets for one regular exercise so you can compare them later."],
  "record-food": ["从下一餐开始把食物和份量记下来，最后一餐后标记当天完成。",
    "Start with your next meal and log what you ate and how much. Mark the day complete after the last meal."],
  "record-weight": ["下次在相近的时间和条件下称重，再用多次记录来看变化。",
    "At your next weigh-in, use a similar time and conditions so several readings can show a trend."],
  continue: ["继续用相同的方式记录，下一次复盘可以直接对照这段数据。",
    "Keep logging the same way so you can compare this period with your next check-in."],
};

function positiveText(summary: HealthSummary, en: boolean) {
  const { positive, training, food, sleep } = summary;
  switch (positive) {
    case "strength-up": {
      const name = training.patterns.find(({ direction }) => direction === "up")!.name;
      return en ? `${name} improved in repeated comparable working sets.` : `${name} 的可比工作组有多次进步。`;
    }
    case "weight-goal": return en ? "Average weight is moving within your goal pace across two comparisons." : "连续两段均重变化都在你设的速度范围内。";
    case "cut-strength": return en ? "Weight is trending at your planned pace, and comparable sets have held steady." :
      "均重按目标速度变化，可比工作组表现保持稳定。";
    case "wake-improved": return en ? `Wake-time variation narrowed by ${sleep.reducedWakeSpread} minutes in the later half of the month.` :
      `近半月的起床时间波动比前半月缩小了 ${sleep.reducedWakeSpread} 分钟。`;
    case "sleep-goal": return summary.window === 1 ? (en ? "This night met your sleep goal." : "这一晚达到了你的睡眠目标。") :
      (en ? `You met your sleep goal on ${sleep.goal!.met} of ${sleep.count} logged nights.` : `${sleep.count} 晚已记录睡眠中，有 ${sleep.goal!.met} 晚达到你的目标。`);
    case "protein-goal": return summary.window === 1 ? (en ? "The complete food log met your protein goal." : "这天完整记录的蛋白质达到了你的目标。") :
      (en ? `Protein met your goal on ${food.proteinMet} of ${food.proteinCompared} comparable food days.` : `${food.proteinCompared} 个可比较的饮食日中，有 ${food.proteinMet} 天达到蛋白质目标。`);
    case "food-complete": return en ? `${food.complete} food ${food.complete === 1 ? "day is" : "days are"} marked complete with usable nutrition.` :
      `有 ${food.complete} 天的饮食已标记完成，营养也可以计算。`;
    case "strength-recorded": return en ? `You logged ${training.workingSets} strength working ${training.workingSets === 1 ? "set" : "sets"}.` :
      `这段记录了 ${training.workingSets} 组力量工作组。`;
    default: return null;
  }
}

function dateRange(start: string, end: string) {
  return start === end ? end : `${start} – ${end}`;
}

function Metric({ label, value, note }: { label: string; value: ReactNode; note?: ReactNode }) {
  return <div><dt>{label}</dt><dd>{value}{note && <small>{note}</small>}</dd></div>;
}

function numberAndUnit(value: number | null, unit: string, integral = false) {
  return value === null ? "—" : `${(integral ? whole : number).format(value)} ${unit}`;
}

function FoodEvidence({ summary, en }: { summary: HealthSummary; en: boolean }) {
  const { food, window } = summary;
  const daily = window === 1;
  const nutrients = [
    { key: "kcal", unit: "kcal", label: en ? "Energy" : "热量" },
    { key: "protein", unit: "g", label: en ? "Protein" : "蛋白质" },
    { key: "carbs", unit: "g", label: en ? "Carbs" : "碳水" },
    { key: "fat", unit: "g", label: en ? "Fat" : "脂肪" },
  ] as const;
  const basis = food.coverage ? (daily
    ? food.complete ? (en ? "Marked complete · nutrition calculated" : "饮食已标记完成，营养可计算") : (en ? "Logged items only · incomplete day" : "仅含已计算的食物，全天记录未齐")
    : food.complete ? (en ? `Daily average across ${food.coverage} complete days` : `${food.coverage} 个完整饮食日的日均摄入`)
      : (en ? `Daily average of logged items across ${food.coverage} partial days` : `${food.coverage} 天的已记摄入日均值，记录不完整`))
    : (en ? "No intake could be calculated for this period." : "这段暂无可计算的摄入记录。");
  const energy = food.estimatedBalance;
  const signedEnergy = energy === null ? null : Math.round(energy);
  const energyMode = signedEnergy === null || signedEnergy === 0 ? (en ? "balance" : "平衡") :
    signedEnergy > 0 ? (en ? "deficit" : "赤字") : (en ? "surplus" : "盈余");
  const energyLabel = en ? `Estimated ${daily ? "" : "daily "}${energyMode}` : `估算${daily ? "" : "日均"}热量${energyMode}`;
  let energyReason = en ? "Requires a complete food log and energy estimates based on recorded workout times." :
    "需要饮食标记完成且营养可算，训练需要记录时长。";
  if (daily && food.selected.foodComplete) {
    if (food.selected.expenditure === null) energyReason = en ? "Add age in settings to estimate energy use." : "在设置中填写年龄后可估算消耗。";
    else if (food.selected.energy?.fromSelection || food.selected.energy?.missingDuration) {
      energyReason = en ? "Log workout durations to use them in the energy estimate." : "记录实际训练时长后可比较热量平衡。";
    }
  }
  return <section className="health-evidence">
    <h3><Icon name="food" size={16}/>{en ? "Food and energy" : "饮食与热量"}</h3>
    <p>{basis}</p>
    {!daily && <p className="health-detail-note">{en ? `${food.recorded}/${window} days with calculable intake · ${food.marked} marked complete` :
      `${food.recorded}/${window} 天有可计算摄入 · ${food.marked} 天已标记完成`}</p>}
    <dl className="health-evidence-metrics">
      {nutrients.map(({ key, unit, label }) => <Metric key={key} label={label}
        value={numberAndUnit(food.intake?.[key] ?? null, unit, key === "kcal")}
        note={food.target && (en ? `${food.selected.targetSaved || !daily ? "Saved" : "Current"} goal ${numberAndUnit(food.target[key], unit, key === "kcal")}` :
          `${food.selected.targetSaved || !daily ? "已保存" : "当前"}目标 ${numberAndUnit(food.target[key], unit, key === "kcal")}`)}/>)}
      <Metric label={energyLabel} value={signedEnergy === null ? "—" : numberAndUnit(Math.abs(signedEnergy), "kcal", true)}
        note={en ? `${food.comparable}/${window} comparable days` : `${food.comparable}/${window} 天可比较`}/>
      {food.proteinCompared > 0 && <Metric label={en ? "Protein goal met" : "蛋白质达标"}
        value={en ? `${food.proteinMet}/${food.proteinCompared} days` : `${food.proteinMet}/${food.proteinCompared} 天`}
        note={en ? "Complete logs with saved goals" : "使用完整饮食日的已保存目标"}/>}
    </dl>
    {food.uncomputedEntries > 0 && <p className="health-detail-note">{en ? `${food.uncomputedEntries} food entries need nutrition details.` :
      `${food.uncomputedEntries} 条食物记录的营养待确认。`}</p>}
    {food.estimatedEntries > 0 && <p className="health-detail-note">{en ? "Some logged portions or nutrition values are estimates." : "部分食物的份量或营养为估算值。"}</p>}
    <p className="health-detail-note">{energy === null ? energyReason : en ? "Energy use is estimated from baseline activity and logged workout durations." : "消耗按基础活动和已记录的训练时长估算。"}</p>
  </section>;
}

function WeightEvidence({ summary, profile, en }: { summary: HealthSummary; profile: Profile; en: boolean }) {
  const { weight, window } = summary;
  const { earlier, recent, rate } = weight.comparison;
  const rounded = rate === null ? null : Math.round(rate * 100) / 100;
  const paceFormat = (value: number) => numberAndUnit(value, en ? "kg/week" : "kg/周");
  const pace = rounded === null ? "—" : rounded === 0 ? paceFormat(0) : rounded > 0 ?
    `${en ? "Down" : "下降"} ${paceFormat(rounded)}` : `${en ? "Up" : "上升"} ${paceFormat(-rounded)}`;
  const windowText = ({ start, end, count, average }: typeof recent) => `${dateRange(start, end)} · ${numberAndUnit(average, "kg")} · ${en ? `${count} weigh-ins` : `${count} 次`}`;
  return <section className="health-evidence">
    <h3><Icon name="scale" size={16}/>{en ? "Weight and goal" : "体重与目标"}</h3>
    <dl className="health-evidence-metrics">
      <Metric label={en ? "Latest weigh-in" : "最近一次称重"} value={numberAndUnit(weight.latest?.kg ?? null, "kg")} note={weight.latest?.day}/>
      <Metric label={window === 1 ? (en ? "Weight on this date" : "当日体重") : (en ? "Period average" : "这段平均体重")}
        value={numberAndUnit(weight.current.average, "kg")} note={en ? `${weight.current.count}/${window} days with weigh-ins` : `${weight.current.count}/${window} 天有称重`}/>
      <Metric label={en ? "Weight goal" : "目标体重"} value={numberAndUnit(profile.goalWeight, "kg")} note={profile.goalDay}/>
      <Metric label={en ? "Rate of change" : "均重变化速度"} value={pace}
        note={en ? `Goal ${profile.paceMin}–${profile.paceMax} kg/week loss` : `目标每周下降 ${profile.paceMin}–${profile.paceMax} kg`}/>
    </dl>
    {rate !== null ? <p className="health-detail-note">{windowText(earlier)}<br/>{windowText(recent)}</p> : <p className="health-detail-note">{window === 30 ?
      (en ? "A monthly comparison needs 14 weigh-ins with at least 5 in each half." : "30 天趋势需要至少 14 天称重，且前后半段各至少 5 天。") :
      (en ? "A trend needs at least 4 weigh-ins in each of two consecutive weeks." : "趋势需要相邻两周各至少 4 天称重。")}</p>}
    {weight.patternWindows.length > 0 && <p className="health-detail-note">{en ? "Repeated pace uses three consecutive weeks" : "重复趋势依据连续三周称重"}
      {weight.patternWindows.map((period) => <span className="health-evidence-line" key={period.start}>{windowText(period)}</span>)}</p>}
  </section>;
}

function StrengthEvidence({ summary, en }: { summary: HealthSummary; en: boolean }) {
  const { training, window } = summary;
  const directionNames = { up: en ? "Improved" : "进步", down: en ? "Repeated decline" : "重复回落", steady: en ? "Steady" : "相近" };
  return <section className="health-evidence">
    <h3><Icon name="lift" size={16}/>{en ? "Strength training" : "力量训练"}</h3>
    <dl className="health-evidence-metrics">
      <Metric label={en ? "Strength days" : "力量训练日"} value={training.days || "—"}
        note={training.days ? (en ? `${training.days}/${window} days with logs` : `${training.days}/${window} 天有记录`) : (en ? "No strength logs" : "暂无力量训练记录")}/>
      <Metric label={en ? "Working sets logged" : "已记录工作组"} value={training.workingSets ?? "—"}
        note={training.sessions > 0 && (en ? `${training.detailedSessions}/${training.sessions} sessions include sets` : `${training.detailedSessions}/${training.sessions} 次训练有组数明细`)}/>
      {training.volume !== null && <Metric label={en ? "Known loaded volume" : "可计算的负重训练量"}
        value={numberAndUnit(training.volume, en ? "kg × reps" : "kg × 次")}
        note={en ? `${training.volumeEntries} exercise entries` : `${training.volumeEntries} 条动作记录`}/>}
    </dl>
    {training.legacySets && <p className="health-detail-note">{en ? "The set count includes legacy entries with unspecified equipment." : "已记组数包含器械口径未知的旧训练记录。"}</p>}
    {training.patterns.length > 0 ? <ul className="health-patterns">{training.patterns.map(({ name, mode, dates, direction, example }, i) => {
      const { delta, metric } = example.difference;
      const isReps = metric === "reps";
      const change = !isReps && mode === "assisted" && delta !== null ? -delta : delta;
      const basis = isReps ? (mode === "bodyweight" ? (en ? "Bodyweight reps" : "自重次数") : (en ? "Reps at the same load" : "同重量次数")) :
        mode === "assisted" ? (en ? "Assistance at the same reps" : "同次数的辅助重量") : (en ? "Load at the same reps" : "同次数负重");
      return <li key={`${name}:${i}`}><strong>{name}</strong> · {directionNames[direction]}
        <small>{dateRange(dates[0], dates.at(-1)!)} · {en ? `${dates.length} training days` : `${dates.length} 个训练日`}</small>
        {change !== null && <small>{example.earlier} → {example.day} · {basis} {change > 0 ? "+" : ""}{numberAndUnit(change, isReps ? (en ? "reps" : "次") : "kg")}</small>}
      </li>;
    })}</ul> : <p className="health-detail-note">{en ? "A strength pattern needs working sets from the same exercise and setup on at least three dates." :
      "至少三个日期记录同动作、同设定的可比工作组，才能判断力量表现是否出现趋势。"}</p>}
  </section>;
}

function SleepEvidence({ summary, status, en }: { summary: HealthSummary; status: SleepView["status"]; en: boolean }) {
  const { sleep, window } = summary;
  const daily = window === 1;
  const duration = (minutes: number | null) => minutes === null ? "—" : sleepDuration(Math.round(minutes), en);
  const coverage = (count: number) => en ? `${count}/${window} nights` : `${count}/${window} 晚`;
  const timing = (value: typeof sleep.wake) => value ? value.typical : "—";
  const stages = [
    { key: "core", label: en ? "Core" : "核心" }, { key: "deep", label: en ? "Deep" : "深睡" },
    { key: "rem", label: "REM" }, { key: "awake", label: en ? "Awake" : "清醒" },
  ] as const;
  const compared = [
    { label: en ? "Sleep duration" : "睡眠时长", metric: sleep.duration, unit: en ? "min" : "分" },
    { label: en ? "Resting heart rate" : "静息心率", metric: sleep.resting, unit: "bpm" },
    { label: "HRV", metric: sleep.hrv, unit: "ms" },
  ];
  const hasComparison = compared.some(({ metric }) => metric.comparison.delta !== null);
  return <section className="health-evidence">
    <h3><Icon name="moon" size={16}/>{en ? "Sleep and timing" : "睡眠与作息"}</h3>
    {status === "error" && <p className="health-detail-note">{en ? "Sleep sync is unavailable. Previously loaded nights are shown when available." :
      "睡眠同步暂不可用，有已读取的夜间记录时会在这里显示。"}</p>}
    {!sleep.count && status !== "error" && <p className="health-detail-note">{status === "loading" ?
      (en ? "Reading sleep records…" : "正在读取睡眠记录…") : (en ? "No personal sleep records for this period yet." : "这段暂无睡眠记录。")}</p>}
    <dl className="health-evidence-metrics">
      <Metric label={daily ? (en ? "Sleep duration" : "睡眠时长") : (en ? "Average duration" : "平均睡眠时长")}
        value={duration(sleep.duration.value)} note={coverage(sleep.count)}/>
      <Metric label={daily ? (en ? "Asleep / wake" : "入睡 / 起床") : (en ? "Typical asleep / wake" : "常见入睡 / 起床")}
        value={sleep.count ? `${timing(sleep.bedtime)} / ${timing(sleep.wake)}` : "—"}
        note={!daily && sleep.wake && sleep.count > 1 && (en ? `Wake-time range ${duration(sleep.wake.spread)}` : `起床时间跨度 ${duration(sleep.wake.spread)}`)}/>
      {sleep.goal && <Metric label={en ? "Sleep goal" : "睡眠目标"} value={duration(sleep.goal.minutes)}
        note={sleep.count > 0 && (en ? `Met on ${sleep.goal.met}/${sleep.count} logged nights` : `${sleep.goal.met}/${sleep.count} 晚达到目标`)}/>}
      <Metric label={en ? "Resting heart rate" : "静息心率"} value={numberAndUnit(sleep.resting.value, "bpm")} note={coverage(sleep.resting.count)}/>
      <Metric label="HRV" value={numberAndUnit(sleep.hrv.value, "ms")} note={coverage(sleep.hrv.count)}/>
    </dl>
    <p className="health-detail-note">{en ? `Apple Watch stage estimates${daily ? "" : " · averages of available nights"}` :
      `Apple Watch 阶段估算${daily ? "" : " · 按各项有数据的晚数取均值"}`}</p>
    <dl className="health-evidence-metrics">{stages.map(({ key, label }) => <Metric key={key} label={label}
      value={duration(sleep.stages[key].value)} note={coverage(sleep.stages[key].count)}/>)}</dl>
    {hasComparison && <div className="health-sleep-change"><strong>{en ? "Compared with your earlier records" : "对照自己的较早记录"}</strong>
      {compared.filter(({ metric }) => metric.comparison.delta !== null).map(({ label, metric, unit }) => {
        const { earlier, recent, delta } = metric.comparison;
        const rounded = Math.round(delta! * 10) / 10;
        return <p key={label}><strong>{label}</strong> {rounded > 0 ? "+" : ""}{numberAndUnit(rounded, unit)}
          <small>{dateRange(earlier.start, earlier.end)} ({earlier.count}) → {dateRange(recent.start, recent.end)} ({recent.count})</small></p>;
      })}
    </div>}
    {(sleep.resting.count > 0 && sleep.resting.comparison.delta === null || sleep.hrv.count > 0 && sleep.hrv.comparison.delta === null) &&
      <p className="health-detail-note">{en ? "Personal comparisons need enough nights for each measure." : "静息心率和 HRV 各自有足够的记录晚数才显示个人对照。"}</p>}
  </section>;
}

export function HealthAdvice({ view, rows, profile, day, today, showMuse = true }: {
  view: SleepView; rows: Row[]; profile: Profile; day: string; today: string; showMuse?: boolean;
}) {
  const { language } = useLanguage();
  const en = language === "en";
  const [selection, setSelection] = useState<{ window: HealthWindow; day: string } | null>(null);
  const summaries = useMemo(() => HEALTH_WINDOWS.map((window) => healthSummary({ rows, profile, nights: view.nights, day, today, window,
    demoSleep: view.status === "demo", sleepCurrent: view.status !== "error" })), [rows, profile, view.nights, view.status, day, today]);
  const focus = focusHealth(summaries[0], summaries[1], summaries[2]);
  const summary = (selection?.day === day ? summaries.find(({ window }) => window === selection.window) : undefined) ?? focus;
  const window = summary.window;
  const positive = positiveText(summary, en);
  const muse = showMuse && view.reports.find((report) => report.kind === "daily" && report.day === summary.end);
  return <section className="card padded health-advice">
    <CardHead title={en ? "Health advice" : "健康建议"} icon="sparkle"/>
    <div className="health-priority" aria-live="polite">
      <div className="health-priority-heading"><strong>{en ? "Your next step" : "先做这一件事"}</strong>
        {window !== 1 && <small>{en ? `Last ${window} days` : `过去 ${window} 天`}</small>}
      </div>
      <p>{actions[summary.priority][en ? 1 : 0]}</p>
      {positive && <p className="health-positive"><Icon name="check" size={16}/>{positive}</p>}
    </div>
    {summary.example && <p className="health-detail-note">{en ? "Based on sample data" : "以上基于示例记录"}</p>}
    <details className="health-disclosure">
      <summary><Icon name="down" size={16}/>{en ? "Review the evidence" : "查看记录依据"}</summary>
      <div className="health-controls">
        <div className="health-period" role="group" aria-label={en ? "Advice window" : "建议的时间范围"}>
          {HEALTH_WINDOWS.map((days) => <button key={days} type="button" aria-pressed={window === days}
            onClick={() => setSelection({ window: days, day })}>{en ? `${days} ${days === 1 ? "day" : "days"}` : `${days} 天`}</button>)}
        </div>
        <p className="health-detail-note">{dateRange(summary.start, summary.end)}</p>
      </div>
      <div className="health-evidence-grid">
        <FoodEvidence summary={summary} en={en}/>
        <WeightEvidence summary={summary} profile={profile} en={en}/>
        <StrengthEvidence summary={summary} en={en}/>
        <SleepEvidence summary={summary} status={view.status} en={en}/>
      </div>
      {muse && <div className="muse-advice health-muse"><span>{en ? "Muse · synced nightly advice" : "Muse · 同步的当晚建议"}</span><p>{muse.advice}</p></div>}
      <p className="health-detail-note health-source">{en ? "DayBaseline generates these suggestions in your browser from your records and goals." :
        "日衡在浏览器中根据你的记录和目标生成建议。"}</p>
    </details>
  </section>;
}
