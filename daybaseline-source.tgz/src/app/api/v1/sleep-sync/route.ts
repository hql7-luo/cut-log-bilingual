import { agentBody, agentResponse } from "../../../../server/agent-api.ts";
import { CLOUD_ENABLED, SUPABASE_KEY, SUPABASE_URL } from "../../../../lib/public-config.ts";

// Keep the service-role key out of this endpoint. The RPC checks the sleep scope and account.
export function POST(request: Request) {
  return agentResponse(async () => {
    if (!CLOUD_ENABLED || process.env.FITNESS_AGENT_ENABLED !== "1") {
      return { status: 503, data: { error: "sleep_sync_disabled" } };
    }
    const header = request.headers.get("authorization") ?? "";
    const token = /^Bearer (sleep_[a-f0-9]{64})$/i.exec(header)?.[1];
    if (!token) return { status: 401, data: { error: "invalid_token" } };
    const payload: unknown = await agentBody(request);
    const response = await fetch(SUPABASE_URL + "/rest/v1/rpc/daybaseline_sync_sleep", {
      method: "POST",
      headers: { apikey: SUPABASE_KEY, "Content-Type": "application/json" },
      body: JSON.stringify({ p_token: token, p_payload: payload }),
      cache: "no-store",
      redirect: "error",
      signal: AbortSignal.timeout(10_000),
    });
    if (!response.ok) return { status: 503, data: { error: "sleep_sync_unavailable" } };
    const result = await response.json();
    switch (result?.status) {
      case 200:
        return { status: 200, data: { nights_saved: result.nights_saved, reports_saved: result.reports_saved } };
      case 401: case 403: case 422: case 429:
        return { status: result.status, data: { error: String(result.error) } };
      default:
        return { status: 503, data: { error: "sleep_sync_unavailable" } };
    }
  });
}
